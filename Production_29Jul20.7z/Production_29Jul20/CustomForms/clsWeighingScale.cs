using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;
using System.Linq;

namespace Production
{
    class clsWeighingScale : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        public const string formTypeEx = "WEIGHINGSCALE";
        const string formMenuUID = "WEIGHINGSCALE";
        public const string objType = "WEIGHINGSCALE";
        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_BarCode";
        const string matrixPrimaryColumnUID = "V_7";

        public const string headerTable = "@WEIGHINGSCALE";
        public const string rowTable = "@WEIGHINGSCALE1";

        const string CFL_JC = "CFL_JC";
        const string CFL_BAR = "CFL_BAR";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_REC = "CFL_REC";
        const string CFL_MAC = "CFL_MAC";
        const string CFL_UNIT = "CFL_UNIT";


        public const string docDateUDF = "U_DocDate";
        const string jbDocNumUID = "JBNo";
        const string jbDocNumUDF = "U_JBNo";
        public const string jbDocEntryUDF = "U_JBEn";
        const string jbDocDateUDF = "U_JBDate";
        const string productCodeUID = "PrdCode";
        const string productCodeUDF = "U_PrdCode";
        const string productNameUDF = "U_PrdName";
        const string poQtyUDF = "U_POQty";
        const string poQtyUID = "POQty";
        const string poBalQtyUDF = "U_POBalQty";

        const string whsCodeUDF = "U_WhsCode";
        const string packUnitHeaderUDF = "U_PackUn";

        //const string itDocNumUID = "ITNo";
        //const string itDocNumUDF = "U_ITNo";
        //const string itDocEntryUDF = "U_ITEn";


        const string conversionRateUDF = "U_ConvRate";
        const string packUnitUDF = "U_PackUn";
        const string batchUDF = "U_Batch";

        const string shiftUID = "Shift";
        public const string shiftUDF = "U_Shift";

        const string totQtyUDF = "U_TotQty";
        const string totGrWtUDF = "U_TotGrWt";
        const string totTareWtUDF = "U_TotTareWt";
        const string totNetWtDF = "U_TotNetWt";

        const string matrixBarCodeUID = "V_7";
        public const string matrixBarCodeUDF = "U_BarCode";
        const string matrixGrossWtUID = "V_8";
        public const string matrixGrossWtUDF = "U_GrWt";
        const string matrixTareWtUID = "V_5";
        public const string matrixCheckUDF = "U_Chk";
        public const string matrixTareWtUDF = "U_TareWt";
        public const string matrixCoreSrNoUDF = "U_CoreSrNo";
        //public const string matrixPackQtyUDF = "U_PackQty";
        const string matrixPackQtyUID = "V_3";
        public const string matrixQtyUDF = "U_Qty";
        const string matrixQtyUID = "V_16";
        public const string matrixOpenPackQtyUDF = "U_OPackQty";

        public const string matrixPackUnitUDF = "U_PackUnit";
        const string matrixPackUnitUID = "V_2";
        public const string matrixStkQtyUDF = "U_StkQty";
        public const string matrixUOMBaseQtyUDF = "U_UOMBQty";
        //public const string matrixBatchUDF = "U_Batch";

        const string matrixNetWtUID = "";
        public const string matrixNetWtUDF = "U_NetWt";

        const string receiptDateUDF = "U_RecDate";
        const string receiptDateUID = "RecDate";

        //const string matrixReceiptNoUID = "RecNo";
        public const string matrixReceiptNoUDF = "U_RecNo";
        public const string matrixReceiptEntryUDF = "U_RecEn";

        const string machineCodeUDF = "U_MacCode";
        const string machineCodeUID = "MacCode";
        const string machineNameUDF = "U_MacName";

        const string buttonCreateReceiptUID = "btnRec";
        const string buttonCreateQCUID = "btnQC";
        const string buttonCreateITUID = "btnIT";

        const string unApprovedWhsCode = "QC-Unapp";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Button
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Machine.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(shiftUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select shift.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select ItemCode.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    double dblPlannedQty = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(poQtyUDF, 0).ToString());

                                    double dblPlannedBalQty = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(poBalQtyUDF, 0).ToString());
                                    double dblComplQty = dblPlannedQty - dblPlannedBalQty;

                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        if (dblPlannedBalQty == 0)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Balance quantity can't be zero.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string packUnit = "";
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (i == 0)
                                        {
                                            packUnit = oDbDataSource.GetValue(matrixPackUnitUDF, i).Trim();
                                        }
                                        if (oDbDataSource.GetValue(matrixBarCodeUDF, i).Trim() == string.Empty)
                                        {
                                            continue;
                                        }
                                        if (oDbDataSource.GetValue(matrixPackUnitUDF, i).Trim() == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select pack UOM for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string quantity = oDbDataSource.GetValue(matrixQtyUDF, i).Trim();
                                        double dblQuantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                                        if (dblQuantity == 0)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please enter quantity for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        //quantity = oDbDataSource.GetValue(matrixPackQtyUDF, i).Trim();
                                        //dblQuantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                                        //if (dblQuantity == 0)
                                        //{
                                        //    BubbleEvent = false;
                                        //    oApplication.StatusBar.SetText("Please enter pack quantity for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        //    return;
                                        //}
                                        if (oDbDataSource.GetValue(matrixBarCodeUDF, i).ToString() == string.Empty)
                                        {
                                            oDbDataSource.RemoveRecord(i);
                                        }
                                    }
                                    if (oDbDataSource.Size == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix.LoadFromDataSource();

                                    #region Duplicate BarCode Validation 

                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                                    List<string> list = new List<string>();
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        list.Add(oDbDataSource.GetValue(matrixBarCodeUDF, i));
                                    }

                                    var query = list.GroupBy(x => x)
                                      .Where(g => g.Count() > 1)
                                      .Select(y => y.Key)
                                      .ToList();
                                    if (query.Count > 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Duplicates BarCode ." + query[0].ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    #endregion

                                    double dblTotalQuantity = 0;
                                    string valMessage = "";
                                    if (packUnit.ToLower() == "kgs")
                                    {
                                        dblTotalQuantity = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(totNetWtDF, 0).ToString());
                                        valMessage = "net weight ";
                                    }
                                    else
                                    {
                                        dblTotalQuantity = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(totQtyUDF, 0).ToString());
                                    }
                                    double dblPlannedQtyPlus10Per = dblPlannedQty + ((10 * dblPlannedQty) / 100);
                                    dblPlannedQtyPlus10Per = dblPlannedQtyPlus10Per - dblComplQty;
                                    if (dblTotalQuantity > dblPlannedQtyPlus10Per)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Total " + valMessage + " quantity is greater than planned balance quantity with (+10%).", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    //if (packUnit.ToLower() == "kgs")
                                    //{

                                    //}
                                    //else
                                    //{
                                    //    double dblTotalNetWt = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(totNetWtDF, 0).ToString());
                                    //    double dblPlannedQtyPlus10Per = dblPlannedQty + ((10 * dblPlannedQty) / 100);
                                    //    dblPlannedQtyPlus10Per = dblPlannedQtyPlus10Per - dblComplQty;
                                    //    if (dblTotalNetWt > dblPlannedQtyPlus10Per)
                                    //    {
                                    //        BubbleEvent = false;
                                    //        oApplication.StatusBar.SetText("Total net weight quantity is greater than planned balance quantity with (+10%).", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //        return;
                                    //    }
                                    //}
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Create QC
                            else if (pVal.ItemUID == buttonCreateQCUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (!(oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_VIEW_MODE))
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();
                                //string itEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(itDocEntryUDF, 0).Trim();
                                string receiptEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(matrixReceiptEntryUDF, 0).Trim();
                                if (receiptEntry == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please create receipt.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string qcDocEntry = objclsComman.SelectRecord("SELECT \"DocEntry\" FROM \"" + clsWeighingScaleQC.headerTable + "\" WHERE \"U_BaseEn\" = '" + docEntry + "'");
                                clsWeighingScaleQC obj = new clsWeighingScaleQC();
                                obj.LoadForm(clsWeighingScaleQC.formMenuUID);
                                oForm = oApplication.Forms.ActiveForm;
                                if (qcDocEntry != string.Empty)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                                    oEdit.String = qcDocEntry;
                                    oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                else
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("BaseNo").Specific;
                                    oEdit.String = docNum;
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("BaseEn").Specific;
                                    oEdit.String = docEntry;

                                    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT * FROM \"" + headerTable + "\" WHERE \"DocEntry\" = '" + docEntry + "' ");
                                    if (!oRs.EoF)
                                    {
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQC.headerTable);
                                        string date = oRs.Fields.Item(receiptDateUDF).Value.ToString();
                                        if (date != string.Empty)
                                        {
                                            DateTime dt = DateTime.Parse(oRs.Fields.Item(receiptDateUDF).Value.ToString());
                                            oDbDataSource.SetValue(receiptDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(dt));
                                        }
                                        //oDbDataSource.SetValue(receiptNoUDF, 0, oRs.Fields.Item(receiptNoUDF).Value);
                                        //oDbDataSource.SetValue(receiptEntryUDF, 0, oRs.Fields.Item(receiptEntryUDF).Value);
                                        oDbDataSource.SetValue(jbDocNumUDF, 0, oRs.Fields.Item(jbDocNumUDF).Value);
                                        oDbDataSource.SetValue(jbDocEntryUDF, 0, oRs.Fields.Item(jbDocEntryUDF).Value);
                                        date = oRs.Fields.Item(jbDocDateUDF).Value.ToString();
                                        if (date != string.Empty)
                                        {
                                            DateTime dt = DateTime.Parse(oRs.Fields.Item(jbDocDateUDF).Value.ToString());
                                            oDbDataSource.SetValue(jbDocDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(dt));
                                        }
                                        oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(machineCodeUDF).Value);
                                        oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(machineNameUDF).Value);
                                        oDbDataSource.SetValue(productCodeUDF, 0, oRs.Fields.Item(productCodeUDF).Value);
                                        oDbDataSource.SetValue(productNameUDF, 0, oRs.Fields.Item(productNameUDF).Value);
                                        oDbDataSource.SetValue(packUnitUDF, 0, oRs.Fields.Item(packUnitUDF).Value);
                                        oDbDataSource.SetValue(conversionRateUDF, 0, oRs.Fields.Item(conversionRateUDF).Value);
                                    }
                                    objclsComman.ReleaseObject(oRs);

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQC.rowTable);
                                    oDbDataSource.Clear();
                                    oRs = objclsComman.returnRecord("SELECT * FROM \"" + rowTable + "\" WHERE \"DocEntry\" = '" + docEntry + "' ");
                                    int row = 0;
                                    while (!oRs.EoF)
                                    {
                                        oDbDataSource.InsertRecord(oDbDataSource.Size);
                                        oDbDataSource.SetValue(matrixBarCodeUDF, row, oRs.Fields.Item(matrixBarCodeUDF).Value);
                                        oDbDataSource.SetValue(matrixGrossWtUDF, row, oRs.Fields.Item(matrixGrossWtUDF).Value);
                                        oDbDataSource.SetValue(matrixCoreSrNoUDF, row, oRs.Fields.Item(matrixCoreSrNoUDF).Value);
                                        oDbDataSource.SetValue(matrixTareWtUDF, row, oRs.Fields.Item(matrixTareWtUDF).Value);
                                        oDbDataSource.SetValue(matrixNetWtUDF, row, oRs.Fields.Item(matrixNetWtUDF).Value);
                                        //oDbDataSource.SetValue(matrixPackQtyUDF, row, oRs.Fields.Item(matrixPackQtyUDF).Value);
                                        oDbDataSource.SetValue(matrixPackUnitUDF, row, oRs.Fields.Item(matrixPackUnitUDF).Value);
                                        oDbDataSource.SetValue(matrixStkQtyUDF, row, oRs.Fields.Item(matrixStkQtyUDF).Value);
                                        oDbDataSource.SetValue("U_QCEn", row, "0");


                                        oRs.MoveNext();
                                        row++;
                                    }
                                    oMatrix.LoadFromDataSource();
                                    objclsComman.ReleaseObject(oRs);

                                }
                            }
                            #endregion

                            #region Create Inventory Transfer
                            else if (pVal.ItemUID == buttonCreateITUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                //string itEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(itDocEntryUDF, 0).Trim();
                                string receiptEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(matrixReceiptEntryUDF, 0).Trim();
                                if (receiptEntry == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select receipt entry.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                //if (itEntry != string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Inventory transfer is already created.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                CreateIT(docEntry);
                            }
                            #endregion

                            #region Create Receipt From Production
                            else if (pVal.ItemUID == buttonCreateReceiptUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (!(oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_VIEW_MODE))
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //for (int i = 0; i < oDbDataSource.Size; i++)
                                //{
                                //    string chk = oDbDataSource.GetValue(matrixCheckUDF, i);
                                //    if (chk == "Y")
                                //    {
                                //        if (string.IsNullOrEmpty(oDbDataSource.GetValue(matrixBatchUDF, i).Trim()))
                                //        {
                                //            oApplication.StatusBar.SetText("Batch no is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                //            return;
                                //        }
                                //    }
                                //}
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                CreateReceiptFromProduction_PartialAuto(docEntry);
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == jbDocNumUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string prdCode = oDbDataSource.GetValue(productCodeUDF, 0).Trim();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add(CommonFields.Status); //Condition Alias             
                                temp.Add("R"); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);
                                //oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\" ");
                                //sbQuery.Append(" FROM \"OWOR\" T0 ");
                                //sbQuery.Append(" WHERE  \"" + CommonFields.Status + "\" = 'R' ");

                                //sbQuery.Append(" WHERE  ");
                                //sbQuery.Append(" NOT EXISTS( ");
                                //sbQuery.Append(" SELECT 1 FROM \"" + headerTable + "\" IT0 WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + jbDocEntryUDF + "\")");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_JC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oProductionOrders), sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                            if (pVal.ItemUID == productCodeUID)
                            {

                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                //temp = new ArrayList();
                                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                //temp.Add(CommonFields.Code); //Condition Alias             
                                //temp.Add(machineCode); //Condition Value
                                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                //alCondVal.Add(temp);
                                string query = "Select \"U_PrdCode\" FROM \"" + clsMachineMaster.rowTable + "\" WHERE \"Code\" = '" + machineCode + "'";
                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_ITEM, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oItems), query, CommonFields.ItemCode, alCondVal);
                            }
                            if (pVal.ColUID == matrixPackUnitUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                //temp = new ArrayList();
                                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                //temp.Add(CommonFields.Code); //Condition Alias             
                                //temp.Add(machineCode); //Condition Value
                                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                //alCondVal.Add(temp);
                                string prdCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();
                                string ugpEntry = objclsComman.SelectRecord("SELECT \"UgpEntry\" FROM OITM WHERE \"ItemCode\" = '" + prdCode + "'");
                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT T1.\"UomCode\" FROM UGP1  T0 INNER JOIN OUOM T1 ON T0.\"UomEntry\" = T1.\"UomEntry\" ");
                                sbQuery.Append(" WHERE T0.\"UgpEntry\" ='" + ugpEntry + "'  ");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_UNIT, "10000199", sbQuery.ToString(), CommonFields.UomCode, alCondVal);
                            }
                            //else if (pVal.ItemUID == receiptNoUID)
                            //{
                            //    oForm = oApplication.Forms.Item(pVal.FormUID);
                            //    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            //    string jbDocEntry = oDbDataSource.GetValue(jbDocEntryUDF, 0).Trim();
                            //    jbDocEntry = jbDocEntry == string.Empty ? "999999" : jbDocEntry;
                            //    ArrayList alCondVal = new ArrayList();
                            //    ArrayList temp = new ArrayList();
                            //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            //    string query = "Select T0.\"DocEntry\" FROM \"OIGN\" T0 INNER JOIN \"IGN1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" WHERE T1.\"BaseEntry\" = '" + jbDocEntry + "'";
                            //    objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry), query, CommonFields.DocEntry, alCondVal);
                            //}

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_JC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(jbDocNumUDF, 0, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                string jbDocEntry = oDataTable.GetValue(CommonFields.DocEntry, 0).ToString();
                                oDbDataSource.SetValue(jbDocEntryUDF, 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                oDbDataSource.SetValue(jbDocDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(machineCodeUDF, 0).ToString());
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());

                                double dblPlannedQty = double.Parse(oDataTable.GetValue(CommonFields.PlannedQty, 0).ToString());
                                double dblCmpltQty = double.Parse(oDataTable.GetValue(CommonFields.CmpltQty, 0).ToString());
                                oDbDataSource.SetValue(poQtyUDF, 0, dblPlannedQty.ToString());

                                string prevWeighingPackUnit = objclsComman.SelectRecord("SELECT MAX(T1.\"" + matrixPackUnitUDF + "\") FROM \"" + headerTable + "\" T0 INNER JOIN \"" + rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" WHERE T0.\"" + jbDocEntryUDF + "\" = '" + jbDocEntry + "' AND T0.\"" + CommonFields.Canceled + "\" = 'N' ");
                                string prevWeighingQty = "0";
                                if (prevWeighingPackUnit.ToLower() == "kgs")
                                {
                                    prevWeighingQty = objclsComman.SelectRecord("SELECT SUM(\"" + totNetWtDF + "\") FROM \"" + headerTable + "\" WHERE \"" + jbDocEntryUDF + "\" = '" + jbDocEntry + "' AND \"" + CommonFields.Canceled + "\" = 'N' ");
                                }
                                else
                                {
                                    prevWeighingQty = objclsComman.SelectRecord("SELECT SUM(T1.\"" + matrixStkQtyUDF + "\") FROM \"" + headerTable + "\" T0 INNER JOIN \"" + rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\"   WHERE T0.\"" + jbDocEntryUDF + "\" = '" + jbDocEntry + "' AND T0.\"" + CommonFields.Canceled + "\" = 'N' ");
                                }
                                double dblPrevWeighingQty = prevWeighingQty == string.Empty ? 0 : double.Parse(prevWeighingQty);
                                dblPlannedQty = dblPlannedQty - dblPrevWeighingQty;
                                oDbDataSource.SetValue(poBalQtyUDF, 0, dblPlannedQty.ToString());

                                string soSeriesName = objclsComman.SelectRecord("SELECT T1.\"SeriesName\" FROM ORDR T0 INNER JOIN NNM1 T1 ON T0.\"" + CommonFields.Series + "\" = T1.\"" + CommonFields.Series + "\" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + oDataTable.GetValue("OriginAbs", 0).ToString() + "'");
                                oDbDataSource.SetValue(batchUDF, 0, soSeriesName + " - " + oDataTable.GetValue("OriginNum", 0).ToString());

                                oDbDataSource.SetValue(whsCodeUDF, 0, oDataTable.GetValue(CommonFields.Warehouse, 0).ToString());
                                oDbDataSource.SetValue(packUnitHeaderUDF, 0, oDataTable.GetValue("Uom", 0).ToString());

                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                string itemName = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemName + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");
                                oDbDataSource.SetValue(productNameUDF, 0, itemName);

                                sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.Code + "\",T0.\"" + CommonFields.Name + "\" ");
                                //sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                //sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                //sbQuery.Append(" WHERE \"" + productCodeUDF + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");
                                sbQuery.Append(" SELECT T0.\"" + CommonFields.Name + "\" ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.Code + "\" = '" + oDataTable.GetValue(machineCodeUDF, 0).ToString() + "'");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    //oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                }
                                objclsComman.ReleaseObject(oRs);
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_UNIT)
                            {
                                string prdCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();
                                string ugpEntry = objclsComman.SelectRecord("SELECT \"UgpEntry\" FROM OITM WHERE \"ItemCode\" = '" + prdCode + "'");
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixPackUnitUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.UomCode, 0).ToString());

                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT \"BaseQty\" FROM UGP1  T0 INNER JOIN OUOM T1 ON T0.\"UomEntry\" = T1.\"UomEntry\" ");
                                sbQuery.Append(" WHERE T0.\"UgpEntry\" ='" + ugpEntry + "' AND T0.\"UomEntry\" = '" + oDataTable.GetValue(CommonFields.UomEntry, 0).ToString() + "' ");

                                string baseQty = objclsComman.SelectRecord(sbQuery.ToString());
                                string packQty = "0"; //oDbDataSource.GetValue(matrixPackQtyUDF, pVal.Row - 1);

                                baseQty = baseQty.Trim() == string.Empty ? "0" : baseQty.Trim();
                                packQty = packQty.Trim() == string.Empty ? "0" : packQty.Trim();

                                oDbDataSource.SetValue(matrixUOMBaseQtyUDF, pVal.Row - 1, baseQty);
                                double dblBaseQty = double.Parse(baseQty);
                                double dblPackQty = double.Parse(packQty);

                                oDbDataSource.SetValue(matrixStkQtyUDF, pVal.Row - 1, Convert.ToString(dblBaseQty * dblPackQty));

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixPackUnitUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_BAR)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixPrimaryUDF, pVal.Row - 1, oDataTable.GetValue("BcdCode", 0).ToString());
                                //oDbDataSource.SetValue(jobEnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                //string itemDesc = objclsComman.SelectRecord("SELECT Dscription FROM RDR1 WHERE DocEntry = '" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "'");
                                //oDbDataSource.SetValue(jobDescUDF, pVal.Row - 1, itemDesc);

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixPrimaryColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_KEY_DOWN
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string jbDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(jbDocEntryUDF, 0).Trim();
                            string productCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();

                            if (pVal.ColUID == matrixBarCodeUID)
                            {
                                if (pVal.CharPressed == 9)
                                {
                                    clsVariables.BaseFormUID = oForm.UniqueID;
                                    clsVariables.BaseFormTypeEx = oForm.TypeEx;

                                    clsBarCodeSelection objclsBarCodeSelection = new clsBarCodeSelection();
                                    objclsBarCodeSelection.LoadForm(pVal.Row.ToString(), jbDocEntry, productCode, "");
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixGrossWtUID || pVal.ColUID == matrixTareWtUID)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string packUnit = oDbDataSource.GetValue(matrixPackUnitUDF, pVal.Row - 1).ToString();
                                    string grossWt = oDbDataSource.GetValue(matrixGrossWtUDF, pVal.Row - 1).ToString();
                                    string tareWt = oDbDataSource.GetValue(matrixTareWtUDF, pVal.Row - 1).ToString();

                                    double dblNetWt = double.Parse(grossWt) - double.Parse(tareWt);
                                    oDbDataSource.SetValue(matrixNetWtUDF, pVal.Row - 1, dblNetWt.ToString());
                                    if (packUnit.Trim().ToLower() == "kgs")
                                    {
                                        oDbDataSource.SetValue(matrixQtyUDF, pVal.Row - 1, dblNetWt.ToString());
                                    }
                                    oMatrix.LoadFromDataSource();

                                    double dblGrossWt = 0;
                                    double dblTareWt = 0;

                                    double dblQty = 0;
                                    double dblTotalQty = 0;
                                    double dblTotalGrossWt = 0;
                                    double dblTotalTareWt = 0;
                                    double dblTotalNetWt = 0;

                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        dblQty = double.Parse(oDbDataSource.GetValue(matrixQtyUDF, i).ToString());
                                        dblGrossWt = double.Parse(oDbDataSource.GetValue(matrixGrossWtUDF, i).ToString());
                                        dblTareWt = double.Parse(oDbDataSource.GetValue(matrixTareWtUDF, i).ToString());
                                        dblNetWt = double.Parse(oDbDataSource.GetValue(matrixNetWtUDF, i).ToString());

                                        dblTotalQty = dblTotalQty + dblQty;
                                        dblTotalGrossWt = dblTotalGrossWt + dblGrossWt;
                                        dblTotalTareWt = dblTotalTareWt + dblTareWt;
                                        dblTotalNetWt = dblTotalNetWt + dblNetWt;
                                    }
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totQtyUDF, 0, dblTotalQty.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totGrWtUDF, 0, dblTotalGrossWt.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totTareWtUDF, 0, dblTotalTareWt.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totNetWtDF, 0, dblTotalNetWt.ToString());
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                    }
                                }
                                else if (pVal.ColUID == matrixQtyUID)
                                {
                                    string productCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string baseQty = oDbDataSource.GetValue(matrixUOMBaseQtyUDF, pVal.Row - 1).ToString();
                                    string packQty = oDbDataSource.GetValue(matrixQtyUDF, pVal.Row - 1).ToString();
                                    string grossWt = objclsComman.SelectRecord("SELECT \"U_Gr_Wt\" FROM OITM WHERE \"ItemCode\" = '" + productCode + "'");
                                    string tareWt = objclsComman.SelectRecord("SELECT \"U_TareWgt\" FROM OITM WHERE \"ItemCode\" = '" + productCode + "'");
                                    grossWt = grossWt == string.Empty ? "0" : grossWt;
                                    tareWt = tareWt == string.Empty ? "0" : tareWt;

                                    baseQty = baseQty == string.Empty ? "0" : baseQty;
                                    packQty = packQty == string.Empty ? "0" : packQty;

                                    double dblStkQty = double.Parse(baseQty) * double.Parse(packQty);
                                    oDbDataSource.SetValue(matrixStkQtyUDF, pVal.Row - 1, dblStkQty.ToString());

                                    double dblGrossWt = double.Parse(grossWt) * double.Parse(packQty);
                                    double dblTareWt = double.Parse(tareWt) * double.Parse(packQty);
                                    double dblNetWt = dblGrossWt - dblTareWt;
                                    oDbDataSource.SetValue(matrixNetWtUDF, pVal.Row - 1, dblNetWt.ToString());
                                    oDbDataSource.SetValue(matrixGrossWtUDF, pVal.Row - 1, dblGrossWt.ToString());
                                    oDbDataSource.SetValue(matrixTareWtUDF, pVal.Row - 1, dblTareWt.ToString());
                                    //oDbDataSource.SetValue(matrixNetWtUDF, pVal.Row - 1, dblNetWt.ToString());

                                    oMatrix.LoadFromDataSource();

                                    double dblQty = 0;
                                    double dblTotalQty = 0;
                                    double dblTotalGrossWt = 0;
                                    double dblTotalTareWt = 0;
                                    double dblTotalNetWt = 0;

                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        dblQty = double.Parse(oDbDataSource.GetValue(matrixQtyUDF, i).ToString());
                                        dblGrossWt = double.Parse(oDbDataSource.GetValue(matrixGrossWtUDF, i).ToString());
                                        dblTareWt = double.Parse(oDbDataSource.GetValue(matrixTareWtUDF, i).ToString());
                                        dblNetWt = double.Parse(oDbDataSource.GetValue(matrixNetWtUDF, i).ToString());

                                        dblTotalQty = dblTotalQty + dblQty;
                                        dblTotalGrossWt = dblTotalGrossWt + dblGrossWt;
                                        dblTotalTareWt = dblTotalTareWt + dblTareWt;
                                        dblTotalNetWt = dblTotalNetWt + dblNetWt;
                                    }
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totQtyUDF, 0, dblTotalQty.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totGrWtUDF, 0, dblTotalGrossWt.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totTareWtUDF, 0, dblTotalTareWt.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totNetWtDF, 0, dblTotalNetWt.ToString());
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                    }
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.CancelRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0).Trim();
                        if (status == "C")
                        {
                            oApplication.StatusBar.SetText("You can't cancel close record", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            BubbleEvent = false;
                            return;
                        }

                        string isExist = objclsComman.SelectRecord("SELECT 1 FROM \"" + rowTable + "\" WHERE \"" + CommonFields.DocEntry + "\" = '" + docEntry + "' AND  IFNULL(\"" + matrixReceiptEntryUDF + "\",'') !='' ");
                        if (isExist == "1")
                        {
                            oApplication.StatusBar.SetText("Receipt Entry is posted for some rows. So you can't cancel document", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            BubbleEvent = false;
                            return;
                        }
                        int i = oApplication.MessageBox("Do you really want to cancel record?", 1, "Yes", "No");
                        if (i == 2)
                        {
                            BubbleEvent = false;
                            return;
                        }
                        else
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T1 ");
                            sbQuery.Append(" SET T1.\"U_IsUsed\" = 'N' ");
                            sbQuery.Append(" FROM \"" + clsBarCodeAssignment.headerTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN \"" + clsBarCodeAssignment.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T2 ON T0.\"" + jbDocEntryUDF + "\" = T2.\"" + jbDocEntryUDF + "\" AND T0.\"" + productCodeUDF + "\" = T2.\"" + productCodeUDF + "\"   ");
                            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T3 ON  T2.\"" + CommonFields.DocEntry + "\" = T3.\"" + CommonFields.DocEntry + "\"   ");
                            sbQuery.Append(" AND  T1.\"" + matrixBarCodeUDF + "\" = T3.\"" + matrixBarCodeUDF + "\"    ");
                            sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + docEntry + "'  ");
                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND IFNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                            //objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixOpenPackQtyUDF + "\" = \"" + matrixPackQtyUDF + "\" FROM \"" + rowTable + "\" T0 WHERE  \"DocEntry\" ='" + docEntry + "' AND  IFNULL(\"" + matrixReceiptEntryUDF + "\",'')=''");

                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T1 ");
                            sbQuery.Append(" SET T1.\"U_IsUsed\" = 'Y' ");
                            sbQuery.Append(" FROM \"" + clsBarCodeAssignment.headerTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN \"" + clsBarCodeAssignment.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T2 ON T0.\"" + jbDocEntryUDF + "\" = T2.\"" + jbDocEntryUDF + "\" AND T0.\"" + productCodeUDF + "\" = T2.\"" + productCodeUDF + "\"   ");
                            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T3 ON  T2.\"" + CommonFields.DocEntry + "\" = T3.\"" + CommonFields.DocEntry + "\"   ");
                            sbQuery.Append(" AND  T1.\"" + matrixBarCodeUDF + "\" = T3.\"" + matrixBarCodeUDF + "\"    ");
                            sbQuery.Append(" WHERE T2.\"" + CommonFields.DocEntry + "\" = '" + docEntry + "'  ");
                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND ISNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                            //objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixOpenPackQtyUDF + "\" = \"" + matrixPackQtyUDF + "\" FROM \"" + rowTable + "\" T0 WHERE  \"DocEntry\" ='" + docEntry + "' AND  ISNULL(\"" + matrixReceiptEntryUDF + "\",'')=''");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0).Trim();
                        string isIssued = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_IsIssued", 0).Trim();

                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        DisableRow(oMatrix, isIssued);

                        if (isIssued == "Y")
                        {
                            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                            {
                                //for (int j = 2; j < oMatrix.Columns.Count; j++)
                                //{
                                oMatrix.CommonSetting.SetCellEditable(i, 2, true);
                                //}
                            }
                        }
                        if (status == "C")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                            oForm.Items.Item(buttonCreateReceiptUID).Enabled = true;
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        }


                        //DisableControls(BusinessObjectInfo.FormUID);
                        //string receiptDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0);
                        //if (receiptDocEntry != string.Empty)
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        //    oItem = oForm.Items.Item(buttonCreateQCUID);
                        //    oItem.Enable();
                        //    DisableControls(oForm.UniqueID);
                        //}
                        //else
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        //    oMatrix.FlushToDataSource();
                        //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                        //    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                        //    oMatrix.LoadFromDataSource();
                        //    EnableControls(oForm.UniqueID);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.UDFForm), true);

                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    //oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixShiftUID, 1);
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(shiftUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SHIFTMASTER\"");
                }
                else
                {
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                }

                EnableControls(oForm.UniqueID);

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.SetRowEditable(1, true);

                oItem = oForm.Items.Item("DocNum");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Series");
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(CommonFields.Status);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(CommonFields.Canceled);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(machineCodeUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(productCodeUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(jbDocNumUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(poQtyUID);
                oItem.EnableinAddMode();

                //oItem = oForm.Items.Item(itDocNumUID);
                //oItem.EnableinFindMode();

                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ConvRate", 0, "1");
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }



        private void CreateIT(string DocEntry)
        {

            SAPbobsCOM.StockTransfer oDoc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);
            oDoc.DocDate = DateTime.Now;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T0.\"" + whsCodeUDF + "\",T0.\"" + productCodeUDF + "\" ");
                sbQuery.Append(" ,T0.\"" + matrixReceiptEntryUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\" ");
                sbQuery.Append(" ,SUM(T1.\"" + matrixStkQtyUDF + "\") " + matrixStkQtyUDF + " ");
                sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"" + productCodeUDF + "\" = T2.\"" + CommonFields.ItemCode + "\" ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' ");
                sbQuery.Append(" GROUP BY T0.\"" + whsCodeUDF + "\",T0.\"" + productCodeUDF + "\" ");
                sbQuery.Append(" ,T0.\"" + matrixReceiptEntryUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\" ");

                oRs = objclsComman.returnRecord(sbQuery.ToString());
                string itemCode = oRs.Fields.Item(productCodeUDF).Value.ToString();
                string receiptDocEntry = oRs.Fields.Item(matrixReceiptEntryUDF).Value.ToString();
                string stockQuantity = oRs.Fields.Item(matrixStkQtyUDF).Value.ToString() == string.Empty ? "0" : oRs.Fields.Item(matrixStkQtyUDF).Value.ToString();
                double dblStockQuantity = double.Parse(stockQuantity);
                if (dblStockQuantity == 0)
                {
                    oApplication.StatusBar.SetText("Stock quantity can't be zero", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                int i = oApplication.MessageBox("Do you really want to Create Inventory Transfer", 1, "Yes", "No");
                if (i == 2)
                {
                    return;
                }
                oDoc.FromWarehouse = oRs.Fields.Item(whsCodeUDF).Value.ToString();
                oDoc.ToWarehouse = unApprovedWhsCode;

                oDoc.Lines.ItemCode = oRs.Fields.Item(productCodeUDF).Value.ToString();
                oDoc.Lines.WarehouseCode = unApprovedWhsCode;
                oDoc.Lines.Quantity = dblStockQuantity;
                if (oRs.Fields.Item(CommonFields.ManBtchNum).Value.ToString() == "Y")
                {
                    oDoc.Lines.SetCurrentLine(0);
                    oDoc.Lines.BatchNumbers.BatchNumber = objclsComman.SelectRecord(objclsComman.GetBatchNoQuery(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)));
                    oDoc.Lines.BatchNumbers.Quantity = dblStockQuantity;
                    //oDoc.Lines.BatchNumbers.BaseLineNumber = 0;
                    oDoc.Lines.BatchNumbers.Add();
                }

                int retVal = oDoc.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Create Inventory Transfer Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    //objclsComman.SelectRecord("UPDATE T0 SET \"" + itDocEntryUDF + "\" = '" + newDocEntry + "',\"" + itDocNumUDF + "\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "'");
                    //oApplication.StatusBar.SetText("Inventory Order Transfer " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    //objclsComman.RefreshRecord();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create IT catch exception :" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
            }
        }

        private void CreateReceiptFromProduction_PartialAuto(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "receiptDT";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT 1  ");
            sbQuery.Append(" FROM OIGE T0 ");
            sbQuery.Append(" WHERE T0.\"" + clsIssueForProduction.weighingScaleDocEntryUDF + "\" = '" + DocEntry + "'");
            string isExists = objclsComman.SelectRecord(sbQuery.ToString());
            if (isExists != "1")
            {
                oApplication.StatusBar.SetText("Please create issue first", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return;
            }
            sbQuery.Length = 0;

            sbQuery.Append(" SELECT T0.\"DocEntry\",T0.\"U_DocDate\", T0.\"U_JBEn\", T0.\"U_JBNo\",T0.\"U_PrdCode\",T0.\"U_Batch\",MAX(T0.\"U_Shift\") AS \"U_Shift\" ");
            sbQuery.Append(" ,SUM(T1.\"" + matrixQtyUDF + "\" * T1.\"" + matrixUOMBaseQtyUDF + "\"  ) AS \"" + matrixQtyUDF + "\"  ");
            sbQuery.Append(" ,SUM(T1.\"" + matrixNetWtUDF + "\")  AS \""+ matrixNetWtUDF + "\" ");

            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
            }
            sbQuery.Append(" GROUP BY T0.\"DocEntry\",T0.\"U_DocDate\", T0.\"U_JBEn\", T0.\"U_JBNo\",T0.\"U_PrdCode\",T0.\"U_Batch\"");
            //sbQuery.Append(" , T0.\"" + totNetWtDF + "\"  ");

            try
            {

                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }
            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);

            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());

                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create receipt from production. ", 1, "Ok", "", "");
                    return;
                }
                oDataTable.ExecuteQuery(sbQuery.ToString());

                int k = oApplication.MessageBox("Do you really want to create receipt from production?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                clsVariables.BaseOrderNo = oRs.Fields.Item(jbDocNumUDF).Value.ToString();
                clsVariables.BaseEntry = oRs.Fields.Item("DocEntry").Value.ToString();
                clsVariables.BaseObjectType = objType;
                clsVariables.BaseBatch = oRs.Fields.Item(batchUDF).Value.ToString();
                clsVariables.BaseShift = oRs.Fields.Item(shiftUDF).Value.ToString();
                clsVariables.BaseDocDate = oRs.Fields.Item(docDateUDF).Value.ToString();
                clsVariables.BaseTotalNetWt = oRs.Fields.Item(matrixNetWtUDF).Value.ToString();

                List<clsItemEntity> list = new List<clsItemEntity>();

                int i = 0;
                while (!oRs.EoF)
                {
                    double quantity = double.Parse(oRs.Fields.Item(matrixQtyUDF).Value.ToString());

                    list.Add(new clsItemEntity() { ItemCode = oRs.Fields.Item("U_PrdCode").Value.ToString(), Qty = quantity.ToString() });
                    i++;
                    oRs.MoveNext();
                }
                clsVariables.ItemList = list;
                clsVariables.boolNewFormOpen = true;


                objclsComman.ReleaseObject(oRs);
                oApplication.ActivateMenuItem("4370");
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
                objclsComman.ReleaseObject(oDataTable);
            }
        }


        private void CreateReceiptFromProduction(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string receiptEn = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(matrixReceiptEntryUDF, 0).Trim();
            if (receiptEn != string.Empty)
            {
                oApplication.StatusBar.SetText("Receipt From production is already created", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return;
            }
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "receiptDT";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"U_DocDate\", T0.\"U_JBEn\",T0.\"U_PrdCode\",T1.\"U_PackQty\",T1.\"U_StkQty\",T0.\"" + shiftUDF + "\",");
            sbQuery.Append(" T2.\"" + CommonFields.ManBtchNum + "\",T0.\"" + batchUDF + "\",T1.\"" + matrixBarCodeUDF + "\" ");
            //sbQuery.Append(" ,(SELECT SUM(A.\"U_PackQty\") FROM \"" + rowTable + "\" A WHERE A.\"DocEntry\" = T0.\"DocEntry\") Quantity  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
            }

            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                int k = oApplication.MessageBox("Do you really want to create receipt from production?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();
                SAPbobsCOM.Documents receipt = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);

                try
                {
                    receipt.DocDate = DateTime.Parse(oDataTable.GetValue(docDateUDF, 0).ToString());
                    string branch = objclsComman.SelectRecord("SELECT \"BPLid\" FROM OWHS WHERE \"WhsCode\" = '" + unApprovedWhsCode + "'");
                    receipt.BPL_IDAssignedToInvoice = int.Parse(branch);

                    int row = 0;
                    for (int j = 0; j < oDataTable.Rows.Count; j++)
                    {
                        if (row > 0)
                        {
                            receipt.Lines.Add();
                        }
                        receipt.Lines.BaseType = 202;
                        receipt.Lines.BaseEntry = Int32.Parse(oDataTable.GetValue(jbDocEntryUDF, 0).ToString());
                        receipt.Lines.Quantity = double.Parse(oDataTable.GetValue(matrixStkQtyUDF, j).ToString());
                        receipt.Lines.WarehouseCode = unApprovedWhsCode;
                        receipt.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntComplete;
                        string manBatch = oDataTable.GetValue(CommonFields.ManBtchNum, j).ToString();
                        if (manBatch == "Y")
                        {
                            //receipt.Lines.BatchNumbers.ManufacturerSerialNumber = oDataTable.GetValue(shiftUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            receipt.Lines.BatchNumbers.InternalSerialNumber = oDataTable.GetValue(matrixBarCodeUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            receipt.Lines.BatchNumbers.BatchNumber = oDataTable.GetValue(batchUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            receipt.Lines.BatchNumbers.Quantity = double.Parse(oDataTable.GetValue(matrixStkQtyUDF, j).ToString());
                            receipt.Lines.BatchNumbers.Add();
                        }
                        receipt.Lines.SetCurrentLine(row);
                        row++;
                    }
                    int retVal = receipt.Add();
                    if (retVal != 0)
                    {
                        oApplication.StatusBar.SetText("Create Receipt From Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        sbMessage.Append(oCompany.GetLastErrorDescription());
                        sbMessage.Append(Environment.NewLine);
                    }
                    else
                    {
                        string PODocEntry = oCompany.GetNewObjectKey();
                        string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + PODocEntry + "'");
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET \"" + matrixReceiptEntryUDF + "\" = '" + PODocEntry + "',\"" + matrixReceiptNoUDF + "\" = '" + PODocNum + "' ");
                        sbQuery.Append(" FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"" + matrixCheckUDF + "\" = 'Y' ");
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            sbQuery.Append(" AND IFNULL(T0.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
                        }
                        else
                        {
                            sbQuery.Append(" AND ISNULL(T0.\"" + matrixReceiptEntryUDF + "\",'') = '' ");
                        }
                        objclsComman.SelectRecord(sbQuery.ToString());
                        oApplication.StatusBar.SetText("Receipt from production Order " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }

                }
                catch (Exception ex)
                {
                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                    oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                finally
                {

                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void DisableRow(SAPbouiCOM.Matrix oMatrix, string isIssued)
        {
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                if (isIssued == "Y")
                {
                    oMatrix.CommonSetting.SetRowEditable(i + 1, false);
                }
                else
                {
                    if (oDbDataSource.GetValue(matrixReceiptEntryUDF, i) == string.Empty)
                    {
                        oMatrix.CommonSetting.SetRowEditable(i + 1, true);
                    }
                    else
                    {
                        oMatrix.CommonSetting.SetRowEditable(i + 1, false);
                    }
                }
            }
        }

        #endregion
    }
}
