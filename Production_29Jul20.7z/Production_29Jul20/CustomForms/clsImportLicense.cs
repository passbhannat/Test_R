using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using Production.Classes;
using General.Classes;

namespace Production
{
    class clsImportLicense : Connection
    {
        #region Variables

        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        const string formMenuUID = "IMPORT_LICENSE";
        const string formTypEx = "IMPORT_LICENSE";
        const string formTitle = "Import License";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Update 
                            if (pVal.ItemUID == "btnImport")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string date = ((SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific).Value;
                                if (date == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select date", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string currentDate = DateTime.Now.ToShortDateString() + DateTime.Now.ToShortTimeString() + DateTime.Now.Ticks.ToString();
                                var password1 = AccountHelper.EncodePassword(currentDate, salt);
                                var password2 = AccountHelper.EncodePassword(date, salt);

                                string query = "UPDATE \"@DBCONFIG\" SET \"U_Date\" = '" + date + "',\"U_Password1\" = '" + password1 + "',\"U_Password2\" = '" + password2 + "' ";
                                objclsComman.SelectRecord(query);
                                oApplication.StatusBar.SetText("Operation completed successfully.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                            }

                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }


                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        #endregion

        #region Method

        //private void LoadForm(string MenuID)
        //{
        //    if (MenuID == formMenuUID)
        //    {
        //        clsVariables.boolCFLSelected = false;
        //        objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
        //        oForm = oApplication.Forms.ActiveForm;
        //        oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
        //        oForm.DataSources.UserDataSources.Item("Close").Value = "N";
        //        oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
        //        oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);

        //        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
        //        if (oMatrix.VisualRowCount == 0)
        //        {
        //            oMatrix.AddRow(1, 1);
        //        }
        //        oMatrix.CommonSetting.EnableArrowKey = true;
        //        ArrayList alCondVal = new ArrayList();
        //        ArrayList temp = new ArrayList();

        //        #region Customer Code

        //        temp = new ArrayList();
        //        temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
        //        temp.Add("CardType"); //Condition Alias             
        //        temp.Add("C"); //Condition Value
        //        temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
        //        alCondVal.Add(temp);

        //        objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDF, "2", "", "", alCondVal);
        //        objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDT, "2", "", "", alCondVal);

        //        #endregion
        //    }
        //    oForm = oApplication.Forms.ActiveForm;

        //    EnableControls(oForm.UniqueID);

        //    #region Series And DocNum

        //    try
        //    {
        //        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
        //        oEdit.String = "t";

        //        objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

        //        #region Set DocNum
        //        string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
        //        if (defaultseries == string.Empty)
        //        {
        //            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
        //            oCombo.Select(0, BoSearchKey.psk_Index);
        //            defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
        //        }
        //        string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
        //        oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

        //        #endregion

        //    }
        //    catch { }
        //    #endregion

        //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
        //    if (oMatrix.VisualRowCount == 0)
        //    {
        //        oMatrix.AddRow(1, 1);
        //    }


        //    oItem = oForm.Items.Item("DocNum");
        //    oItem.EnableinFindMode();

        //    oItem = oForm.Items.Item("Series");
        //    oItem.EnableinAddMode();

        //    oForm.Select();
        //}

        #region LoadForm

        public void LoadForm(string MenuID)
        {

            try
            {
                if (MenuID == formTypEx)
                {
                    string FormID;
                    if (objclsComman.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsComman.LoadXML(MenuID, "", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);

            }

        }


        #endregion

        #endregion
    }
}
