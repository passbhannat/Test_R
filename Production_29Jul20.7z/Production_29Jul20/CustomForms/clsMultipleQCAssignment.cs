using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsMultipleQCAssignment : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string formTypeEx = "MULTIQCASSIGN";
        const string formMenuUID = "MULTIQCASSIGN";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";

        const string jbDocEntryUDF = "U_JBEn";
        const string productCodeUDF = "U_PrdCode";

        const string wsQCEntryUDF = "WSQCEn";
        const string qcEntryUDF = "QCEn";

        const string buttonSelect = "btnSelect";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonSelect)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                ArrayList alBarCode = new ArrayList();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y" && oDT.GetValue("BarCode", i) != string.Empty)
                                    {
                                        alBarCode.Add(oDT.GetValue("LineId", i));
                                    }
                                }
                                if (alBarCode.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }


                                string lineID = String.Join(",", alBarCode.ToArray());

                                string qcDocEntry = oForm.DataSources.UserDataSources.Item(qcEntryUDF).ValueEx;
                                //string qcStatus = oForm.DataSources.UserDataSources.Item().ValueEx;

                                string weighingScaleQCDocEntry = oForm.DataSources.UserDataSources.Item(wsQCEntryUDF).ValueEx;

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" FROM \"" + clsWeighingScaleQCParameter.headerTable + "\"");
                                sbQuery.Append(" WHERE \"DocEntry\" = '" + qcDocEntry + "'  ");
                                string qcStatus = objclsComman.SelectRecord(sbQuery.ToString());

                                sbQuery.Length = 0;
                                sbQuery.Append(" UPDATE T0 ");
                                sbQuery.Append(" SET T0.\"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + qcDocEntry + "', \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = '" + qcStatus + "'");
                                sbQuery.Append(" FROM \"" + clsWeighingScaleQC.rowTable + "\" T0 ");
                                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + weighingScaleQCDocEntry + "' ");
                                sbQuery.Append(" AND T0.\"LineId\" IN ( " + lineID + " )  ");
                                objclsComman.SelectRecord(sbQuery.ToString());

                                

                                //sbQuery.Length = 0;

                                //sbQuery.Append(" UPDATE \"" + clsWeighingScaleQC.rowTable + "\" ");
                                //sbQuery.Append(" SET \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = '" + qcStatus + "'");
                                //sbQuery.Append(" WHERE \"DocEntry\" = '" + weighingScaleQCDocEntry + "' ");
                                //objclsComman.SelectRecord(sbQuery.ToString());
                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                clsVariables.BaseForm.Select();
                                objclsComman.RefreshRecord();
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string wsQCDocEntry, string qcEntry)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;

            oForm.DataSources.UserDataSources.Add(wsQCEntryUDF, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(wsQCEntryUDF).Specific;
            oEdit.DataBind.SetBound(true, "", wsQCEntryUDF);
            oEdit.String = wsQCDocEntry;

            oForm.DataSources.UserDataSources.Add(qcEntryUDF, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(qcEntryUDF).Specific;
            oEdit.DataBind.SetBound(true, "", qcEntryUDF);
            oEdit.String = qcEntry;
            FillGrid(wsQCDocEntry, qcEntry);
        }

        public void FillGrid(string wsQCDocEntry, string qcEntry)
        {
            oForm = oApplication.Forms.ActiveForm;

            sbQuery.Length = 0;
            sbQuery.Append(" SELECT 'N' \"Select\" ,\"LineId\"  ,\"U_BarCode\" AS \"BarCode\" ");
            sbQuery.Append(" FROM \"" + clsWeighingScaleQC.headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + clsWeighingScaleQC.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
            sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + wsQCDocEntry + "'  ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + clsWeighingScaleQC.matrixQCEntryUDF + "\",'0') = '0' ");
                sbQuery.Append(" AND IFNULL(T1.\"" + clsWeighingScaleQC.matrixReceiptNoUDF + "\",'0') != '0' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + clsWeighingScaleQC.matrixQCEntryUDF + "\",'0') = '0' ");
                sbQuery.Append(" AND ISNULL(T1.\"" + clsWeighingScaleQC.matrixReceiptNoUDF + "\",'0') != '0' ");
            }
            //    NOT EXISTS ( ");
            //sbQuery.Append(" SELECT 1  ");
            //sbQuery.Append(" FROM \"" + clsBarCodeAssignment.rowTable + "\" IT0 WHERE T1.\"U_BarCode\" = IT0.\"U_BarCode\")");

            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
            }
            oGrid.Columns.Item(0).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

        #endregion
    }
}
