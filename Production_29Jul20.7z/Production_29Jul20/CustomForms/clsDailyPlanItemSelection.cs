using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;
using System.Linq;

namespace Production
{
    class clsDailyPlanItemSelection : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;
        System.Threading.Thread oThread;

        const string formTypeEx = "DAILYPLANITEM";
        const string formMenuUID = "DAILYPLANITEM";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string rowNoUID = "RowNo";
        const string machineCodeUID = "MacCode";
        const string soDocEntryUID = "OCDocEntry";
        const string soItemCodeUID = "OCItemCode";
        const string processUID = "Process";


        const string buttonChoose = "btnChoose";
        const string buttonGetPlanQty = "btnGetPQty";
        const string buttonGetSFG = "btnSFG";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonChoose)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsBOMEntity> list = new List<clsBOMEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Chk", i) == "Y")
                                    {
                                        list.Add(new clsBOMEntity()
                                        {
                                            SOItemCode = oDT.GetValue("SOItemCode", i),
                                            ItemCode = oDT.GetValue("ItemCode", i),
                                            Qty = oDT.GetValue("SOQuantity", i).ToString(),
                                            PlanQty = oDT.GetValue("PlanQty", i).ToString(),
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (list.Count > 1)
                                {
                                    oApplication.StatusBar.SetText("Please select only 1 row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).Value.ToString();
                                string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).Value.ToString();
                                double planQty = double.Parse(list[0].PlanQty);
                                if (planQty == 0)
                                {
                                    oApplication.StatusBar.SetText("Plan Quantity is already completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("mtx").Specific;
                                oBaseMatrix.FlushToDataSource();

                                string itemCode = list[0].ItemCode;

                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT T0.\"" + clsMachineMaster.ProcessUDF + "\",T1.* ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.Code + "\" = '" + machineCode + "' ");
                                sbQuery.Append(" AND T1.\"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" = '" + itemCode + "' ");
                                SAPbobsCOM.Recordset oRsMachine = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRsMachine.RecordCount == 0)
                                {
                                    oApplication.StatusBar.SetText("Item is not linked with machine master", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                string process = oRsMachine.Fields.Item(clsMachineMaster.ProcessUDF).Value;
                                oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsDailyPlan.rowTable);
                                oDBDataSource.SetValue(clsDailyPlan.matrixProductCodeColumnUDF, rowNo - 1, itemCode);

                                oDBDataSource.SetValue(clsDailyPlan.matrixAdviceQuantityColumnUDF, rowNo - 1, list[0].Qty);
                                oDBDataSource.SetValue(clsDailyPlan.matrixQuantityColumnUDF, rowNo - 1, list[0].PlanQty);
                                oDBDataSource.SetValue(clsDailyPlan.matrixPackQtyColumnUDF, rowNo - 1, list[0].PlanQty);
                                oDBDataSource.SetValue(clsDailyPlan.matrixSFGOCQtyColumnUDF, rowNo - 1, list[0].PlanQty);
                                oDBDataSource.SetValue(clsDailyPlan.matrixBaseQtyColumnUDF, rowNo - 1, list[0].PlanQty);

                                if (process.ToLower() == "bag making")
                                {
                                    oDBDataSource.SetValue(clsDailyPlan.matrixCapacityColumnUDF, rowNo - 1, oRsMachine.Fields.Item("U_MacSpeed").Value);
                                }
                                else
                                {
                                    oDBDataSource.SetValue(clsDailyPlan.matrixCapacityColumnUDF, rowNo - 1, oRsMachine.Fields.Item("U_Cap").Value);
                                }
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT  T0.\"" + CommonFields.WhsCode + "\", T0.\"" + CommonFields.Price + "\"");
                                sbQuery.Append(" ,T0.\"NumPerMsr\",T0.\"" + CommonFields.UomCode + "\" ");
                                sbQuery.Append(" ,T1.\"" + clsDailyPlan.pcsPerWeightUDF + "\",T1.\"OnHand\",T1.\"InvntryUom\",T1.\"ItemName\" ");
                                sbQuery.Append(" FROM \"" + CommonTables.SalesOrderRowTable + "\" T0 ");
                                sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T1 ON T0.\"" + CommonFields.ItemCode + "\" = T1.\"" + CommonFields.ItemCode + "\" ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' ");
                                sbQuery.Append(" AND T0.\"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    //oDBDataSource.SetValue(clsDailyPlan.matrixWhsCodeColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.WhsCode).Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixProductNameColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.ItemName).Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixSORateColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.Price).Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixPerPCWtColumnUDF, rowNo - 1, oRs.Fields.Item("IWeight1").Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixNumPerMsColumnUDF, rowNo - 1, oRs.Fields.Item("NumPerMsr").Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixPackUnitColumnUDF, rowNo - 1, oRs.Fields.Item("UomCode").Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixStockQtyColumnUDF, rowNo - 1, oRs.Fields.Item("OnHand").Value);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixStockUnitColumnUDF, rowNo - 1, oRs.Fields.Item("InvntryUom").Value);
                                }
                                else
                                {
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT  ");
                                    sbQuery.Append(" T1.\"" + CommonFields.InvntryUom + "\" AS \"UomCode\",T1.\"ItemName\" ");
                                    sbQuery.Append(" ,T1.\"" + clsDailyPlan.pcsPerWeightUDF + "\",T1.\"OnHand\",T1.\"InvntryUom\" ");
                                    sbQuery.Append(" FROM  \"" + CommonTables.ItemMasterData + "\" T1  ");
                                    sbQuery.Append(" WHERE T1.\"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");
                                    oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    if (oRs.RecordCount > 0)
                                    {
                                        //oDBDataSource.SetValue(clsDailyPlan.matrixWhsCodeColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.WhsCode).Value);
                                        //oDBDataSource.SetValue(clsDailyPlan.matrixSORateColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.Price).Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixProductNameColumnUDF, rowNo - 1, oRs.Fields.Item("ItemName").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixPerPCWtColumnUDF, rowNo - 1, oRs.Fields.Item("IWeight1").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixNumPerMsColumnUDF, rowNo - 1, "1");
                                        oDBDataSource.SetValue(clsDailyPlan.matrixPackUnitColumnUDF, rowNo - 1, oRs.Fields.Item("UomCode").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixStockQtyColumnUDF, rowNo - 1, oRs.Fields.Item("OnHand").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixStockUnitColumnUDF, rowNo - 1, oRs.Fields.Item("InvntryUom").Value);
                                    }
                                }
                                oBaseMatrix.LoadFromDataSource();
                                objclsComman.ReleaseObject(oRsMachine);
                                objclsComman.ReleaseObject(oRs);

                                if (oBaseForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oBaseForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region Get SFG
                            else if (pVal.ItemUID == buttonGetSFG)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                int k = oApplication.MessageBox("Do you really want to continue?", 1, "Yes", "No", "");
                                if (k == 1)
                                {
                                    string process = oForm.DataSources.UserDataSources.Item(processUID).ValueEx;
                                    string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).ValueEx;
                                    string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).ValueEx;
                                    string soItemCode = oForm.DataSources.UserDataSources.Item(soItemCodeUID).ValueEx;

                                    if (process.ToLower() == "bag making")
                                    {
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" Select 'N' AS \"Chk\",\"ItemCode\" AS \"SOItemCode\", T1.\"Quantity\" AS \"SOQuantity\",\"ItemCode\",\"Dscription\" AS \"ItemName\"");
                                        //sbQuery.Append(" , (T1.\"" + CommonFields.NumPerMsr + "\"  * T1.\"Quantity\") ");
                                        sbQuery.Append(" , T1.\"Quantity\" ");
                                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                                        {
                                            sbQuery.Append(" - IFNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                        }
                                        else
                                        {
                                            sbQuery.Append(" - ISNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                        }
                                        sbQuery.Append(" FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" = T1.\"ItemCode\"),0) ");
                                        sbQuery.Append("  AS \"PlanQty\" ");
                                        sbQuery.Append(" FROM \"" + CommonTables.SalesOrderHeaderTable + "\" T0 ");
                                        sbQuery.Append(" INNER JOIN \"" + CommonTables.SalesOrderHeaderTable + "\" T1 ON T0.\"DocEntry\" =T1.\"DocEntry\"");
                                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + soDocEntry + "' ");
                                        sbQuery.Append(" AND T1.\"ItemCode\" = '" + soItemCode + "' ");
                                        FillGrid(sbQuery.ToString());

                                    }
                                    else
                                    {
                                        oThread = new System.Threading.Thread(new System.Threading.ThreadStart(GetSFGItems));
                                        oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                        oThread.Start();
                                    }
                                }
                            }
                            #endregion

                            #region Get Plan Qty
                            if (pVal.ItemUID == buttonGetPlanQty)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsItemEntity> list = new List<clsItemEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Chk", i) == "Y")
                                    {
                                        list.Add(new clsItemEntity()
                                        {
                                            LineId = i.ToString(),
                                            ItemCode = oDT.GetValue("ItemCode", i),
                                            Qty = oDT.GetValue("Quantity", i).ToString(),
                                            SFGQty = oDT.GetValue("SFGQty", i).ToString()
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (list.Count > 1)
                                {
                                    oApplication.StatusBar.SetText("Please select only 1 row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).Value.ToString();
                                string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).Value.ToString();
                                string soItemCode = oForm.DataSources.UserDataSources.Item(soItemCodeUID).Value.ToString();

                                string itemCode = list[0].ItemCode;
                                string soQty = list[0].Qty;
                                string sfgBOMeaderQuantity = list[0].SFGQty;

                                string fgBOMeaderQuantity = objclsComman.SelectRecord("SELECT \"" + clsBOMMaster.quantityUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" Where \"" + clsBOMMaster.productCodeUDF + "\" = '" + soItemCode + "'  ");
                                //string sfgBOMeaderQuantity = objclsComman.SelectRecord("SELECT \"" + clsBOMMaster.quantityUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" Where \"" + clsBOMMaster.productCodeUDF + "\" = '" + itemCode + "' AND \"" + clsBOMMaster.machineCodeUDF + "\" = '" + machineCode + "' ");

                                sbQuery.Length = 0;
                                double dblSOQty = double.Parse(soQty);
                                double dblFGBOMHeaderQuantity = fgBOMeaderQuantity == string.Empty ? 0 : double.Parse(fgBOMeaderQuantity);
                                double dblSFGBOMHeaderQuantity = sfgBOMeaderQuantity == string.Empty ? 0 : double.Parse(sfgBOMeaderQuantity);

                                double dblPart1 = (dblSFGBOMHeaderQuantity / dblFGBOMHeaderQuantity) * dblSOQty;
                                double dblPart2 = ((dblSFGBOMHeaderQuantity / dblFGBOMHeaderQuantity) * dblSOQty);// * (dblScrapRate / 100);

                                oDT.SetValue("PlanQty", int.Parse(list[0].LineId), Convert.ToString(dblPart1 + dblPart2));
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string rowNo, string soDocEntry, string machineCode, string itemCode, string process)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add(rowNoUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(rowNoUID).Specific;
            oEdit.DataBind.SetBound(true, "", rowNoUID);
            oEdit.String = rowNo;

            oForm.DataSources.UserDataSources.Add(soDocEntryUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(soDocEntryUID).Specific;
            oEdit.DataBind.SetBound(true, "", soDocEntryUID);
            oEdit.String = soDocEntry;

            oForm.DataSources.UserDataSources.Add(machineCodeUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(machineCodeUID).Specific;
            oEdit.DataBind.SetBound(true, "", machineCodeUID);
            oEdit.String = machineCode;

            oForm.DataSources.UserDataSources.Add(processUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(processUID).Specific;
            oEdit.DataBind.SetBound(true, "", processUID);
            oEdit.String = process;

            oForm.DataSources.UserDataSources.Add(soItemCodeUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(soItemCodeUID).Specific;
            oEdit.DataBind.SetBound(true, "", soItemCodeUID);
            oEdit.String = itemCode;
        }

        public void FillGrid(string query)
        {
            oForm = oApplication.Forms.ActiveForm;
            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, query);
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
            }
            oGrid.Columns.Item("Chk").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
            oApplication.StatusBar.SetText("Data loaded successfully",SAPbouiCOM.BoMessageTime.bmt_Short,SAPbouiCOM.BoStatusBarMessageType.smt_Success);
        }

        private void GetSFGItems()
        {
            oForm = oApplication.Forms.ActiveForm;
            string process = oForm.DataSources.UserDataSources.Item(processUID).ValueEx;
            string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).ValueEx;
            string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).ValueEx;
            string soItemCode = oForm.DataSources.UserDataSources.Item(soItemCodeUID).ValueEx;

            List<clsItemEntity> sfList = new List<clsItemEntity>();
            clsVariables.BOMList = new List<clsBOMEntity>();

            sbQuery.Length = 0;
            sbQuery.Append(" Select \"ItemCode\",\"Quantity\" FROM \"" + CommonTables.SalesOrderRowTable + "\" ");
            sbQuery.Append("  WHERE \"DocEntry\" = '" + soDocEntry + "' AND  \"ItemCode\" = '" + soItemCode + "' ");

            SAPbobsCOM.Recordset oRsSO = objclsComman.returnRecord(sbQuery.ToString());
            while (!oRsSO.EoF)
            {
                string fgItemCode = oRsSO.Fields.Item("ItemCode").Value;
                string Quantity = oRsSO.Fields.Item("Quantity").Value.ToString();
                string NumPerMsr = objclsComman.SelectRecord("SELECT \"" + CommonFields.NumPerMsr + "\" FROM RDR1 WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' AND \"" + CommonFields.ItemCode + "\" = '" + fgItemCode + "'");

                Quantity = Convert.ToString(double.Parse(Quantity) * double.Parse(NumPerMsr));
                List<clsBOMEntity> itemParamterList = new List<clsBOMEntity>();
                List<clsBOMEntity> sfgItemList = new List<clsBOMEntity>();

                itemParamterList.Add(new clsBOMEntity
                {
                    SOItemCode = fgItemCode,
                    SOQuantity = Quantity,
                    ItemCode = fgItemCode,
                    Process = process,
                    SFGItemCode = fgItemCode,
                    SFGQty = Quantity
                });

                oApplication.StatusBar.SetText("Please wait...data loading", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                GetSFGItemsFromCustomBOM_DataTable(oForm, itemParamterList);
                oRsSO.MoveNext();
            }

            
            var list = clsVariables.BOMList.Where(p => p.Process == process && p.MachineCode == machineCode).ToList();
            clsVariables.BOMList = null;
            list = list.GroupBy(x => x.SFGItemCode).Select(x => x.First()).ToList();

            sbQuery.Length = 0;
            bool itemExist = false;
            for (int i = 0; i < list.Count; i++)
            {

                string itemCode = list[i].SFGItemCode;
                soItemCode = list[i].SOItemCode;
                string soQuantity = list[i].SOQuantity;

                string baseQty = objclsComman.SelectRecord("SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" ='" + itemCode + "' ");
                decimal dblBaseQty = baseQty == string.Empty ? 0 : decimal.Parse(baseQty);
                decimal dblPlanQty = Math.Round(decimal.Parse(list[i].SFGQty), 3) - dblBaseQty;
                if (dblPlanQty != 0)
                {
                    if (i > 0 && sbQuery.Length > 0)
                    {
                        sbQuery.Append(" UNION ALL ");
                    }
                    sbQuery.Append(" Select 'N' AS \"Chk\",'" + soItemCode + "'AS \"SOItemCode\"," + soQuantity + " AS\"SOQuantity\",T0.\"ItemCode\",\"ItemName\",'" + dblPlanQty.ToString() + "' AS \"PlanQty\" ");
                    sbQuery.Append(" FROM \"" + CommonTables.ItemMasterData + "\" T0 ");
                    sbQuery.Append("  WHERE \"" + CommonFields.ItemCode + "\" IN ('" + itemCode + "')");
                    itemExist = true;
                }
            }
            if (itemExist == false)
            {
                oApplication.StatusBar.SetText("No SFG Items", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return;
            }
            FillGrid(sbQuery.ToString());
        }


        private void GetSFGItemsFromCustomBOM_DataTable(SAPbouiCOM.Form oForm, List<clsBOMEntity> itemParameterList)
        {
            List<clsBOMEntity> sfgItemList = new List<clsBOMEntity>();
            StringBuilder sbQuery = new StringBuilder();
            string machineDatatableUID = "mac";
            string itemsDataTableUID = "item";
            try
            {

                try
                {
                    oForm.DataSources.DataTables.Add(machineDatatableUID);
                }
                catch
                {
                }
                try
                {
                    oForm.DataSources.DataTables.Add(itemsDataTableUID);
                }
                catch { }
                SAPbouiCOM.DataTable oDataTable_Machine = oForm.DataSources.DataTables.Item(machineDatatableUID);
                SAPbouiCOM.DataTable oDataTable_Item = oForm.DataSources.DataTables.Item(itemsDataTableUID);

                for (int i = 0; i < itemParameterList.Count; i++)
                {
                    sbQuery.Length = 0;
                    string soItemCode = itemParameterList[i].SOItemCode;
                    string soQuantity = itemParameterList[i].SOQuantity;

                    string itemCode = itemParameterList[i].SFGItemCode;
                    string quantity = itemParameterList[i].SFGQty;
                    string machineCode = itemParameterList[i].MachineCode;

                    if (clsVariables.BOMList.Count == 0)
                    {
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T0.\"" + clsBOMMaster.productCodeUDF + "\" AS \"Father\" ");
                        sbQuery.Append(",T0.\"" + clsBOMMaster.quantityUDF + "\" As \"FGQty\" ");
                        sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                        sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' ");
                        sbQuery.Append(" GROUP BY  ");
                        sbQuery.Append(" T0.\"" + clsBOMMaster.productCodeUDF + "\"   ");
                        sbQuery.Append(",T0.\"" + clsBOMMaster.quantityUDF + "\" ");

                        oDataTable_Item.ExecuteQuery(sbQuery.ToString());

                        #region Load FG BOM with All Machines respect to item

                        for (int j = 0; j < oDataTable_Item.Rows.Count; j++)
                        {
                            string father = itemCode;
                            string sfgItem = itemCode;
                            string sfgQuantity = oDataTable_Item.GetValue("FGQty", j).ToString(); //oRs.Fields.Item("FGQty").Value.ToString();
                            string bomHeaderQty = sfgQuantity;//oRs.Fields.Item("FGQty").Value.ToString();
                            string process = "";

                            sbQuery.Length = 0;
                            sbQuery.Append(" SELECT  \"" + clsBOMMaster.machineCodeUDF + "\", \"" + clsBOMMaster.ProcessUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" WHERE \"" + clsBOMMaster.productCodeUDF + "\" ='" + sfgItem + "' ");

                            oDataTable_Machine.ExecuteQuery(sbQuery.ToString());
                            //SAPMain.logger.DebugFormat("1 . Load FG BOM with All Machines respect to item: " + sbQuery.ToString());

                            for (int k = 0; k < oDataTable_Machine.Rows.Count; k++)
                            {
                                machineCode = oDataTable_Machine.GetValue(clsBOMMaster.machineCodeUDF, k).ToString(); //oRs.Fields.Item("FGQty").Value.ToString();
                                if (machineCode == string.Empty)
                                {
                                    continue;
                                }
                                process = oDataTable_Machine.GetValue(clsBOMMaster.ProcessUDF, k).ToString(); //oRs.Fields.Item("FGQty").Value.ToString();
                                double qty = double.Parse(quantity) * (double.Parse(sfgQuantity) / double.Parse(bomHeaderQty));
                                clsVariables.BOMList.Add(new clsBOMEntity
                                {
                                    SOItemCode = soItemCode,
                                    SOQuantity = soQuantity,
                                    ItemCode = father,
                                    BOMQty = bomHeaderQty,
                                    SFGItemCode = sfgItem,
                                    SFGQty = qty.ToString(),
                                    MachineCode = machineCode,
                                    Process = process,
                                });
                            }
                        }
                        #endregion
                    }

                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.\"" + CommonFields.Code + "\" AS \"Code\" ,T0.\"" + clsBOMMaster.productCodeUDF + "\" AS \"Father\",T0.\"" + clsBOMMaster.machineCodeUDF + "\" AS \"MachineCode\" ,T0.\"" + clsBOMMaster.ProcessUDF + "\" AS \"Process\"");
                    sbQuery.Append(" ,T0.\"" + clsBOMMaster.quantityUDF + "\" As \"FGQty\"  ");
                    sbQuery.Append(" ,T1.\"" + clsBOMMaster.matrixProductCodeColumnUDF + "\" As \"SFGItem\"  ");
                    sbQuery.Append(" ,T1.\"" + clsBOMMaster.matrixQuantityColumnUDF + "\" As \"SFGQty\"  ");

                    sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN  \"" + clsBOMMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                    sbQuery.Append(" INNER JOIN  \"" + CommonTables.ItemMasterData + "\" T2 ON T1.\"" + clsBOMMaster.matrixProductCodeColumnUDF + "\" = T2.\"" + CommonFields.ItemCode + "\" ");
                    sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' ");
                    sbQuery.Append(" AND T2.\"U_TreeType\" = 'P' ");
                    oDataTable_Item.ExecuteQuery(sbQuery.ToString());
                    //SAPMain.logger.DebugFormat("2. Get BOM Data : " + sbQuery.ToString());

                    #region If there is no SFG of item then add in Item List
                    if (oDataTable_Item.Rows.Count == 0)
                    {
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T0.\"" + clsBOMMaster.productCodeUDF + "\" AS \"Father\" ");
                        sbQuery.Append(",T0.\"" + clsBOMMaster.quantityUDF + "\" As \"FGQty\" ");
                        sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                        sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' ");
                        sbQuery.Append(" GROUP BY  ");
                        sbQuery.Append(" T0.\"" + clsBOMMaster.productCodeUDF + "\"   ");
                        sbQuery.Append(",T0.\"" + clsBOMMaster.quantityUDF + "\"  ");

                        oDataTable_Item.ExecuteQuery(sbQuery.ToString());
                        //SAPMain.logger.DebugFormat("3. If there is no SFG of item then add in Item List : " + sbQuery.ToString());

                        for (int j = 0; j < oDataTable_Item.Rows.Count; j++)
                        {
                            string father = itemCode;
                            string sfgItem = itemCode;
                            string sfgQuantity = oDataTable_Item.GetValue("FGQty", j).ToString();
                            string bomHeaderQty = sfgQuantity;
                            string process = "";
                            sbQuery.Length = 0;
                            sbQuery.Append("SELECT  \"" + clsBOMMaster.machineCodeUDF + "\", \"" + clsBOMMaster.ProcessUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" WHERE \"" + clsBOMMaster.productCodeUDF + "\" ='" + sfgItem + "' ");
                            oDataTable_Machine.ExecuteQuery(sbQuery.ToString());
                            for (int k = 0; k < oDataTable_Machine.Rows.Count; k++)
                            {
                                machineCode = oDataTable_Machine.GetValue(clsBOMMaster.machineCodeUDF, k).ToString();
                                if (machineCode == string.Empty)
                                {
                                    continue;
                                }
                                process = oDataTable_Machine.GetValue(clsBOMMaster.ProcessUDF, k).ToString();
                                double qty = double.Parse(quantity) * (double.Parse(sfgQuantity) / double.Parse(bomHeaderQty));
                                clsVariables.BOMList.Add(new clsBOMEntity
                                {
                                    SOItemCode = soItemCode,
                                    SOQuantity = soQuantity,
                                    ItemCode = father,
                                    BOMQty = bomHeaderQty,
                                    SFGItemCode = sfgItem,
                                    SFGQty = qty.ToString(),
                                    MachineCode = machineCode,
                                    Process = process,
                                });
                            }
                        }
                    }
                    #endregion

                    #region
                    else
                    {
                        for (int j = 0; j < oDataTable_Item.Rows.Count; j++)
                        {
                            string code = oDataTable_Item.GetValue("Code", j).ToString();
                            string father = oDataTable_Item.GetValue("Father", j).ToString();// oRs.Fields.Item("Father").Value.ToString();

                            string sfgItem = oDataTable_Item.GetValue("SFGItem", j).ToString(); //oRs.Fields.Item("SFGItem").Value.ToString();
                            string sfgQuantity = oDataTable_Item.GetValue("SFGQty", j).ToString();// oRs.Fields.Item("SFGQty").Value.ToString();
                            string bomHeaderQty = oDataTable_Item.GetValue("FGQty", j).ToString();// oRs.Fields.Item("FGQty").Value.ToString();
                            if (sfgItem == string.Empty)
                            {
                                continue;
                            }
                            bomHeaderQty = bomHeaderQty == "0" ? "1" : bomHeaderQty;
                            string process = "";
                            sbQuery.Length = 0;
                            sbQuery.Append("SELECT  \"" + clsBOMMaster.machineCodeUDF + "\", \"" + clsBOMMaster.ProcessUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" WHERE \"" + clsBOMMaster.productCodeUDF + "\" ='" + sfgItem + "' ");
                            oDataTable_Machine.ExecuteQuery(sbQuery.ToString());
                            //SAPMain.logger.DebugFormat("4. SFG Data with machine code : " + sbQuery.ToString());

                            for (int k = 0; k < oDataTable_Machine.Rows.Count; k++)
                            {
                                machineCode = oDataTable_Machine.GetValue(clsBOMMaster.machineCodeUDF, k).ToString();
                                if (machineCode == string.Empty)
                                {
                                    continue;
                                }
                                process = oDataTable_Machine.GetValue(clsBOMMaster.ProcessUDF, k).ToString();
                                double qty = double.Parse(quantity) * (double.Parse(sfgQuantity) / double.Parse(bomHeaderQty));
                                sfgItemList.Add(new clsBOMEntity
                                {
                                    SOItemCode = soItemCode,
                                    SOQuantity = soQuantity,
                                    ItemCode = father,
                                    BOMQty = bomHeaderQty,
                                    SFGItemCode = sfgItem,
                                    SFGQty = qty.ToString(),
                                    MachineCode = machineCode,
                                    Process = process,
                                });
                            }

                        }
                    }
                    #endregion
                }

                if (sfgItemList.Count > 0)
                {
                    if (clsVariables.BOMList == null)
                    {
                        clsVariables.BOMList = new List<clsBOMEntity>();
                    }
                    clsVariables.BOMList.AddRange(sfgItemList);
                    GetSFGItemsFromCustomBOM_DataTable(oForm, sfgItemList);
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("GetSFGItemsFromCustomBOM_DataTable:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
