using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsBarCodeAssignment : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "BARCODEASSIGN";
        const string formMenuUID = "BARCODEASSIGN";
        const string objType = "BARCODEASSIGN";
        const string matrixUID = "mtx";

        public const string headerTable = "@BARCODEASSIGN";
        public const string rowTable = "@BARCODEASSIGN1";

        const string CFL_JC = "CFL_JC";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_REC = "CFL_REC";

        const string buttonShowBarCode = "btnShow";
        const string buttonShowMultipleBarCode = "btnMBar";

        const string fromBarCodeNoUDF = "U_FrBar";
        const string toBarCodeNoUDF = "U_ToBar";
        const string noOfBarCodeUDF = "U_NoofBar";
        const string noOfBarCodeUID = "NoofBar";

        public const string matrixBarCodeColumnUDF = "U_BarCode";

        const string matrixPrimaryColumnUDF = "U_BarCode";
        const string matrixCheckColumnUDF = "U_Chk";

        const string jobNoUDF = "U_JBNo";
        const string jobNoUID = "JBNo";
        const string jobEntryUDF = "U_JBEn";
        const string jobDateUDF = "U_JBDate";
        const string jobDateUID = "JBDate";
        const string productCodeUID = "PrdCode";
        const string productCodeUDF = "U_PrdCode";
        const string productNameUDF = "U_PrdName";
        const string machineCodeUDF = "U_MacCode";
        const string machineNameUDF = "U_MacName";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Show BarCode
                            else if (pVal.ItemUID == buttonShowBarCode)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                string fromBarCodeNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(fromBarCodeNoUDF, 0).Trim();
                                string toBarCodeNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(toBarCodeNoUDF, 0).Trim();
                                if (fromBarCodeNo == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please enter From BarCode No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                if (toBarCodeNo == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please enter To BarCode No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                int k = oApplication.MessageBox("Do you really want to show barcodes", 1, "Yes", "No");
                                if (k == 1)
                                {
                                    //oForm.Freeze(true);
                                    try
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oMatrix.Clear();
                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                        oDbDataSource.Clear();
                                        Int32 iFromBarCodeNo = Int32.Parse(fromBarCodeNo);
                                        Int32 iToBarCodeNo = Int32.Parse(toBarCodeNo);
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT \"" + matrixBarCodeColumnUDF + "\" ");
                                        sbQuery.Append(" FROM \"" + clsBarCodeGeneration.headerTable + "\" T0 ");
                                        sbQuery.Append(" INNER JOIN \"" + clsBarCodeGeneration.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                                        sbQuery.Append(" WHERE T1.\"" + matrixBarCodeColumnUDF + "\" >= " + iFromBarCodeNo + " ");
                                        sbQuery.Append(" AND T1.\"" + matrixBarCodeColumnUDF + "\" <= " + iToBarCodeNo + " ");
                                        sbQuery.Append(" AND NOT EXISTS ( ");
                                        sbQuery.Append(" SELECT 1  ");
                                        sbQuery.Append(" FROM \"" + rowTable + "\" IT0 WHERE T1.\"" + matrixBarCodeColumnUDF + "\" = IT0.\"" + matrixBarCodeColumnUDF + "\")");

                                        SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                        int rowNo = 0;
                                        while (!oRs.EoF)
                                        {
                                            oDbDataSource.InsertRecord(rowNo);
                                            oDbDataSource.SetValue(matrixBarCodeColumnUDF, rowNo, oRs.Fields.Item(matrixBarCodeColumnUDF).Value.ToString());
                                            oDbDataSource.SetValue(CommonFields.LineId, rowNo, (rowNo + 1).ToString());
                                            rowNo++;
                                            oRs.MoveNext();
                                        }
                                        oMatrix.LoadFromDataSource();
                                    }
                                    finally
                                    {
                                        oForm.Freeze(false);
                                    }
                                }
                            }
                            #endregion

                            #region Multiple BarCode
                            else if (pVal.ItemUID == buttonShowMultipleBarCode)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string jbDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(jobEntryUDF, 0).ToString();
                                string productCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).ToString();

                                clsVariables.BaseFormUID = oForm.UniqueID;
                                clsMultipleBarCodeSelection objclsBarCodeSelection = new clsMultipleBarCodeSelection();
                                objclsBarCodeSelection.LoadForm(jbDocEntry, productCode);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixUID)
                            {
                                //if (pVal.ColUID == matrixRecNoColumnUID)
                                //{
                                //    oForm = oApplication.Forms.Item(pVal.FormUID);
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //    string jobEntry = oDbDataSource.GetValue(jobEntryUDF, 0).Trim();
                                //    ArrayList alCondVal = new ArrayList();
                                //    ArrayList temp = new ArrayList();
                                //    string receiptRowTable = "IGN1";
                                //    //temp = new ArrayList();
                                //    //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                //    //temp.Add(CommonFields.ItemCode); //Condition Alias             
                                //    //temp.Add(machineCode); //Condition Value
                                //    //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                //    //alCondVal.Add(temp);
                                //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //    string query = "Select \"BaseEntry\" FROM \"" + receiptRowTable + "\" WHERE \"DocEntry\" = '" + jobEntry + "'";
                                //    objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry), query, CommonFields.DocEntry, alCondVal);
                                //}
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_JC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(jobNoUDF, 0, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(jobEntryUDF, 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, objclsComman.SelectRecord(objclsComman.GetItemName(oDataTable.GetValue(CommonFields.ItemCode, 0).ToString())));
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(machineCodeUDF, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(machineNameUDF, 0).ToString());

                                //sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.Code + "\",T0.\"" + CommonFields.Name + "\" ");
                                //sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                //sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                //sbQuery.Append(" WHERE \"" + productCodeUDF + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //if (oRs.RecordCount > 0)
                                //{
                                //    oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                //    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                //}
                                //objclsComman.ReleaseObject(oRs);
                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                oDbDataSource.SetValue(jobDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(docDate));
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                //oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(productCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_REC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                //oDbDataSource.SetValue(matrixRecNoColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                //oDbDataSource.SetValue(matrixRecEntryColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                oMatrix.LoadFromDataSource();

                                //oMatrix.Columns.Item(matrixRecNoColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                }
                            }
                            else if (pVal.ItemUID == noOfBarCodeUID)
                            {
                                string noOfBarCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(noOfBarCodeUDF, 0).Trim();
                                string fromBarCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(fromBarCodeNoUDF, 0).Trim();

                                int iNoOfBarCode = noOfBarCode == string.Empty ? 0 : int.Parse(noOfBarCode);
                                Int32 iFromNoOfBarCode = fromBarCode == string.Empty ? 0 : Int32.Parse(fromBarCode);
                                Int32 iToOfBarCode = iFromNoOfBarCode + iNoOfBarCode - 1;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(toBarCodeNoUDF, 0, iToOfBarCode.ToString());

                                //if (pVal.ColUID == matrixGrossWtUID || pVal.ColUID == matrixTareWtUID)
                                //{
                                //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                //    oMatrix.FlushToDataSource();
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                                //    oMatrix.LoadFromDataSource();
                                //}
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixCheckColumnUDF + "\",'N')='N' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  ISNULL(\"" + matrixCheckColumnUDF + "\",'N')='N' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        string todayDate = objclsComman.ConvertDateToSAPDateFormat(DateTime.Now);
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET T0.\"U_Issued\" = 'Y',T0.\"U_IssDate\" = '" + todayDate + "',T0.\"U_IssBy\" = '" + oCompany.UserSignature.ToString() + "' ");
                        sbQuery.Append(" FROM \"" + clsBarCodeGeneration.rowTable + "\" T0 ");
                        sbQuery.Append(" INNER JOIN  \"" + rowTable + "\" T1 ON T0.\"" + matrixBarCodeColumnUDF + "\" = T1.\"" + matrixBarCodeColumnUDF + "\" ");
                        sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "'  ");

                        objclsComman.SelectRecord(sbQuery.ToString());
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0);
                        if (status == "C")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                            DisableControls(oForm.UniqueID);
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                            oMatrix.LoadFromDataSource();
                            EnableControls(oForm.UniqueID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            clsVariables.boolCFLSelected = false;
            if (MenuID == formMenuUID)
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
            }
            oForm = oApplication.Forms.ActiveForm;
            EnableControls(oForm.UniqueID);

            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                #endregion

            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocNum");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("DocEntry");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("Series");
            oItem.EnableinAddMode();

            oItem = oForm.Items.Item(jobNoUID);
            oItem.EnableinAddMode();

            oItem = oForm.Items.Item(jobDateUID);
            oItem.EnableinAddMode();

            oItem = oForm.Items.Item(productCodeUID);
            oItem.EnableinAddMode();

            //string barCodeNo = AutoBarCodeNo();
            //oForm.DataSources.DBDataSources.Item(headerTable).SetValue(fromBarCodeNoUDF, 0, barCodeNo);
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }

        private string AutoBarCodeNo()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT MAX(CAST(\"" + toBarCodeNoUDF + "\" AS INT)) FROM \"" + headerTable + "\" ");
            string barCodeNo = objclsComman.SelectRecord(sbQuery.ToString());
            barCodeNo = barCodeNo == string.Empty ? "1" : Convert.ToString(Int32.Parse(barCodeNo) + 1);
            return barCodeNo;
        }

        private bool isBarCodeAlreadyAdded(string barCode)
        {
            string query = "SELECT 1 FROM \"" + rowTable + "\" WHERE \"" + matrixBarCodeColumnUDF + "\" = '" + barCode + "'";
            query = objclsComman.SelectRecord(query);
            if (query == "1")
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}
