using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;
using System.Linq;

namespace Production
{
    class clsDailyPlan : Connection
    {
        #region Variables 

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "DAILYPLAN";
        public const string formMenuUID = "DAILYPLAN";
        public const string objType = "DAILYPLAN";
        const string matrixUID = "mtx";
        public const string headerTable = "@DAILYPLAN";
        public const string rowTable = "@DAILYPLAN1";
        public const string archiveRowTable = "@DAILYPLAN2";

        const string matrixPrimaryColumnUDF = "U_AdvNo";
        public const string matrixProductCodeColumnUDF = "U_PrdCode";
        const string matrixProductCodeColumnUID = "V_6";
        public const string matrixProductNameColumnUDF = "U_PrdName";

        //const string matrixWhsCodeColumnUDF = "U_WhsCode";
        //public const string matrixWhsCodeColumnUID = "V_29";

        public const string matrixAdviceQuantityColumnUDF = "U_SOQty";
        public const string matrixAdviceQuantityColumnUID = "V_36";

        public const string matrixQuantityColumnUDF = "U_Qty";
        public const string matrixQuantityColumnUID = "V_35";

        public const string matrixSORateColumnUDF = "U_SORate";

        const string machineHeaderTable = "@MACHINEMASTER";
        const string machineRowTable = "@MACHINEMASTER1";

        const string salesOrderHeaderTable = "ORDR";
        const string salesOrderRowTable = "RDR1";

        public const string Budgted_Scrap_RateUDF = "U_Budgted_Scrap_Rate";
        const string fatherDocEntryUDF = "U_FathDocE";
        const string fatherDocNumUDF = "U_FathDocN";
        const string fatherObjectUDF = "U_FathObj";

        const string CFL_MAC = "CFL_MAC";
        const string CFL_SO = "CFL_SO";
        const string CFL_MITEM = "CFL_MITEM";
        const string CFL_RWHS = "CFL_RWHS";
        const string CFL_RBAT = "CFL_RBAT";

        const string machineCodeUID = "MacCode";
        const string machineCodeUDF = "U_MacCode";
        const string machineNameUDF = "U_MacName";
        const string machineCodeLinkedButtonUID = "22";

        const string planDateUDF = "U_DocDate";

        const string matrixMachineNameColumnUDF = "U_MacName";
        public const string matrixCapacityColumnUDF = "U_Cap";
        public const string pcsPerWeightUDF = "IWeight1";
        public const string matrixPerPCWtColumnUDF = "U_PerPCWt";
        const string matrixWtKgColumnUDF = "U_WtKg";
        const string matrixNoHrsColumnUDF = "U_NoHrs";
        const string matrixNoHrsHMColumnUDF = "U_NoHrsHM";
        const string matrixNoDayColumnUDF = "U_NoDay";

        public const string matrixSFGOCQtyColumnUDF = "U_SFGOCQty";
        public const string matrixPackQtyColumnUDF = "U_PackQty";
        public const string matrixPackUnitColumnUDF = "U_PackUnit";
        public const string matrixStockQtyColumnUDF = "U_StkQty";
        public const string matrixBaseQtyColumnUDF = "U_BaseQty";

        public const string matrixStockUnitColumnUDF = "U_StkUnit";
        const string matrixStartDateColumnUDF = "U_StDate";
        const string matrixStartTimeColumnUDF = "U_StTime";
        const string matrixBreakTimeColumnUDF = "U_Break";
        const string matrixBreakDayColumnUDF = "U_BreakDay";

        const string matrixEndDateColumnUDF = "U_EnDate";
        const string matrixEndTimeColumnUDF = "U_EnTime";

        public const string matrixNumPerMsColumnUDF = "U_NumPerMs";

        public const string matrixBPONoUDF = "U_BPONo";
        public const string matrixBPOEnUDF = "U_BPOEn";

        const string matrixAdviceNoColumnUID = "V_16";
        public const string matrixAdviceNoColumnUDF = "U_AdvNo";
        public const string matrixAdviceDocEntryColumnUDF = "U_AdvEn";
        public const string matrixAdviceItemCodeColumnUDF = "U_AdvItem";
        public const string matrixAdviceDateColumnUDF = "U_AdvDate";

        public const string matrixPONoColumnUDF = "U_PONo";
        public const string matrixPOEnColumnUDF = "U_POEn";

        const string matrixCompletedQuantityColumnUDF = "U_CompQty";
        const string matrixRejectedQuantityColumnUDF = "U_RejQty";

        public const string matrixRewindReceiptNoColumnUDF = "U_RewRecNo";
        public const string matrixRewindReceiptEnColumnUDF = "U_RewRecEn";
        public const string matrixRewindIssueNoColumnUDF = "U_RewIssNo";
        public const string matrixRewindIssueEnColumnUDF = "U_RewIssEn";
        const string matrixRewindBatchColumnUDF = "U_RewBatch";
        const string matrixRewindBatchColumnUID = "V_28";
        const string matrixRewindWhsCodeColumnUDF = "U_RewWhs";
        const string matrixRewindWhsCodeColumnUID = "V_31";

        const string matrixRewindShiftColumnUDF = "U_RewShift";
        const string matrixRewindShiftColumnUID = "V_30";

        const string matrixCheckColumnUDF = "U_Chk";

        const string buttonCreateProductionOrder = "btnCP";
        const string buttonRefreshPriority = "btnRef";
        const string buttonRefreshPlan = "btnRPlan";
        const string buttonRefreshTime = "btnRTime";

        const string buttonCreateRewindIssue = "btnRewI";
        const string buttonCreateRewindReceipt = "btnRewR";

        const string buttonShowSFG = "btnSFG";

        const int ROW_BACKGROUND_GRAY = 15724527;
        const int ROW_NORMAL_WHITE = 16777215;

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        double qty = double.Parse(oDbDataSource.GetValue(matrixQuantityColumnUDF, i).ToString());
                                        double baseQty = double.Parse(oDbDataSource.GetValue(matrixBaseQtyColumnUDF, i).ToString());
                                        if (qty > baseQty)
                                        {
                                            oApplication.StatusBar.SetText("Quantity can't be greater than Base Quantity for Row: " + (i + 1).ToString() + ".", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            BubbleEvent = false;
                                            return;
                                        }
                                    }
                                    //if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    //{
                                    //    string planNo = AutoPlanNo();
                                    //    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(planNoUDF, 0, planNo);
                                    //}
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Create Production Order
                            else if (pVal.ItemUID == buttonCreateProductionOrder)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                Create_ProdcutionOrder_Special(docEntry);
                            }
                            #endregion

                            #region Create Rewind Issue
                            else if (pVal.ItemUID == buttonCreateRewindIssue)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                int lineId = objclsComman.GetSelectedRowNo(oMatrix);
                                if (lineId == -1)
                                {
                                    oApplication.StatusBar.SetText("Please select row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                Create_GoodsIssue_Reject_PartialAuto(docEntry, lineId.ToString());
                            }
                            #endregion

                            #region Create Rewind Receipt
                            else if (pVal.ItemUID == buttonCreateRewindReceipt)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                int lineId = objclsComman.GetSelectedRowNo(oMatrix);
                                if (lineId == -1)
                                {
                                    oApplication.StatusBar.SetText("Please select row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                Create_GoodsReceipt_Reject_PartialAuto(docEntry, lineId.ToString());
                            }
                            #endregion

                            #region Show SFG
                            else if (pVal.ItemUID == buttonShowSFG)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();

                                clsVariables.BaseFormUID = oForm.UniqueID;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                int lineId = objclsComman.GetSelectedRowNo(oMatrix);
                                if (lineId == -1)
                                {
                                    oApplication.StatusBar.SetText("Please select row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                //string productionOrderEntry = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(matrixPOEnColumnUDF, lineId - 1).Trim();
                                //if (productionOrderEntry == string.Empty)
                                //{
                                //    oApplication.StatusBar.SetText("Please create production order first.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                //    return;
                                //}
                                string productCode = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(matrixProductCodeColumnUDF, lineId - 1).Trim();
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(objclsComman.GetSFGQuery(productCode));
                                if (oRs.RecordCount == 0)
                                {
                                    oApplication.StatusBar.SetText("There is no SFG for selected product.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                clsDailyPlanSFG obj = new clsDailyPlanSFG();
                                obj.LoadForm(clsDailyPlanSFG.formTypeEx);
                                obj.SetFormValues(productCode, docEntry, lineId.ToString());

                            }
                            #endregion

                            #region Refresh Priority
                            else if (pVal.ItemUID == buttonRefreshPriority)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                objclsComman.RefreshRecord();
                            }
                            #endregion

                            #region Refresh Plan
                            else if (pVal.ItemUID == buttonRefreshPlan)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                try
                                {
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        string poDocEntry = oDbDataSource.GetValue(matrixPOEnColumnUDF, i);
                                        if (poDocEntry == string.Empty)
                                        {
                                            continue;
                                        }
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT SUM(A.\"Quantity\") FROM IGN1 A  ");
                                        sbQuery.Append(" INNER JOIN OWOR B ON A.\"BaseEntry\" = B.\"DocEntry\" ");
                                        sbQuery.Append(" WHERE B.\"" + CommonFields.DocEntry + "\" =  '" + poDocEntry + "' AND A.\"TranType\" = 'C' AND A.\"IsByPrdct\" = 'N' ");
                                        string completedQty = objclsComman.SelectRecord(sbQuery.ToString());

                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT SUM(A.\"Quantity\") FROM IGN1 A  ");
                                        sbQuery.Append(" INNER JOIN OWOR B ON A.\"BaseEntry\" = B.\"DocEntry\" ");
                                        sbQuery.Append(" WHERE B.\"" + CommonFields.DocEntry + "\" =  '" + poDocEntry + "' AND A.\"TranType\" = 'R' ");
                                        string rejQty = objclsComman.SelectRecord(sbQuery.ToString());

                                        oDbDataSource.SetValue(matrixCompletedQuantityColumnUDF, i, completedQty);
                                        oDbDataSource.SetValue(matrixRejectedQuantityColumnUDF, i, rejQty);
                                    }
                                    oMatrix.LoadFromDataSource();
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                                catch (Exception ex)
                                {
                                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    //objclsComman.ReleaseObject(oRs);
                                }

                            }
                            #endregion

                            #region Refresh Time
                            else if (pVal.ItemUID == buttonRefreshTime)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string machineCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).Trim();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"U_Process\" ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" ='" + machineCode + "' ");
                                string process = objclsComman.SelectRecord(sbQuery.ToString()).Trim();

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                try
                                {
                                    DateTime startDate = DateTime.Now;
                                    string startTime = "00:00";
                                    string stDate = string.Empty;

                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (i == 0)
                                        {
                                            stDate = oDbDataSource.GetValue(matrixStartDateColumnUDF, i).ToString();
                                            startDate = stDate == string.Empty ? DateTime.Now : objclsComman.ConvertStrToDate(stDate);
                                        }
                                        if (i != 0)
                                        {
                                            stDate = objclsComman.ConvertDateToSAPDateFormat(startDate);
                                            //stDate = startDate.Year.ToString() + startDate.Month.ToString().PadLeft(2, '0') + startDate.Day.ToString().PadLeft(2, '0');
                                            oDbDataSource.SetValue(matrixStartDateColumnUDF, i, stDate);
                                            oDbDataSource.SetValue(matrixStartTimeColumnUDF, i, startTime);
                                        }
                                        //if (i == 0)
                                        //{
                                        //   
                                        //}
                                        //else
                                        //{
                                        //    oDbDataSource.SetValue(matrixStartDateColumnUDF, i, objclsComman.ConvertDateToSAPDateFormat(startDate));
                                        //}
                                        string itemCode = oDbDataSource.GetValue(matrixProductCodeColumnUDF, i).ToString();
                                        string pcweight = oDbDataSource.GetValue(matrixPerPCWtColumnUDF, i).ToString();
                                        string packunit = oDbDataSource.GetValue(matrixPackUnitColumnUDF, i).ToString();

                                        double dblPerPcsWeight = pcweight == string.Empty ? 0 : double.Parse(pcweight);
                                        double dblPerInvUnit = double.Parse(oDbDataSource.GetValue(matrixNumPerMsColumnUDF, i).ToString());
                                        dblPerInvUnit = dblPerInvUnit == 0 ? 1 : dblPerInvUnit;
                                        if (dblPerPcsWeight == 0)
                                        {
                                            pcweight = objclsComman.SelectRecord("SELECT \"" + pcsPerWeightUDF + "\" FROM OITM WHERE \"ItemCode\" = '" + itemCode + "'");
                                            dblPerPcsWeight = pcweight == string.Empty ? 0 : double.Parse(pcweight);
                                            oDbDataSource.SetValue(matrixPerPCWtColumnUDF, i, dblPerPcsWeight.ToString());
                                        }


                                        string cap = oDbDataSource.GetValue(matrixCapacityColumnUDF, i).ToString();
                                        double dblCap = cap == string.Empty ? 0 : double.Parse(cap);

                                        string packQty = oDbDataSource.GetValue(matrixQuantityColumnUDF, i).ToString();
                                        double dblPackQty = packQty == string.Empty ? 0 : double.Parse(packQty);

                                        double weightInKgs = dblPackQty * dblPerPcsWeight;
                                        oDbDataSource.SetValue(matrixWtKgColumnUDF, i, Convert.ToString(weightInKgs));

                                        double noHrs = 0;

                                        if (dblCap != 0)
                                        {
                                            if (process.ToLower() == "bag making")
                                            {
                                                noHrs = (dblPackQty * dblPerInvUnit) / dblCap;
                                            }
                                            else
                                            {
                                                if (packunit.ToLower() == "kgs")
                                                {
                                                    noHrs = (dblPackQty * dblPerInvUnit) / dblCap;
                                                }
                                                else
                                                {
                                                    noHrs = weightInKgs / dblCap;
                                                    // noHrs = (dblPackQty * dblPerInvUnit) / dblCap;
                                                }
                                            }

                                            //int hr = (int)noHrs;

                                            TimeSpan result = TimeSpan.FromHours(noHrs);
                                            double noDays = result.Days;

                                            int hr = result.Hours;

                                            int min = result.Minutes;

                                            //double fraction = noHrs - Math.Truncate(noHrs);
                                            //fraction = fraction * 60;

                                            //double min = Math.Round(fraction);
                                            //min = result.Minutes;

                                            string day = noDays.ToString() + " days ";
                                            string hh = hr.ToString() + " hour ";
                                            string minMM = min.ToString() + " Minutes";

                                            oDbDataSource.SetValue(matrixNoHrsHMColumnUDF, i, hh + minMM);
                                            oDbDataSource.SetValue(matrixNoDayColumnUDF, i, day + hh + minMM);
                                            DateTime endDate = startDate;
                                            endDate = endDate.AddHours(noHrs);
                                            if (i == 0)
                                            {
                                                startTime = oDbDataSource.GetValue(matrixStartTimeColumnUDF, i).ToString();
                                                double startTimeHrs = Convert.ToDouble(TimeSpan.Parse(startTime).TotalHours);
                                                endDate = endDate.AddHours(startTimeHrs);
                                            }

                                            string endTime = endDate.Hour.ToString().PadLeft(2, '0') + ":" + endDate.Minute.ToString().PadLeft(2, '0');
                                            string breakTime = oDbDataSource.GetValue(matrixBreakTimeColumnUDF, i).ToString();
                                            double breakTimeHrs = 0;
                                            if (breakTime != string.Empty)
                                            {
                                                breakTimeHrs = Convert.ToDouble(TimeSpan.Parse(breakTime).TotalHours);
                                            }
                                            string breakDay = oDbDataSource.GetValue(matrixBreakDayColumnUDF, i).ToString();
                                            double breakTimeDays = 0;
                                            if (breakDay != string.Empty)
                                            {
                                                breakTimeDays = Convert.ToDouble(TimeSpan.Parse(breakDay).TotalDays);
                                            }
                                            oDbDataSource.SetValue(matrixEndDateColumnUDF, i, objclsComman.ConvertDateToSAPDateFormat(endDate));
                                            oDbDataSource.SetValue(matrixEndTimeColumnUDF, i, endTime);
                                            startDate = endDate;
                                            if (breakTimeHrs != 0)
                                            {
                                                startDate = startDate.AddHours(breakTimeHrs);
                                            }
                                            if (breakTimeDays != 0)
                                            {
                                                startDate = startDate.AddDays(breakTimeDays);
                                            }
                                            startTime = startDate.Hour.ToString().PadLeft(2, '0') + ":" + startDate.Minute.ToString().PadLeft(2, '0');
                                            //result = endDate.TimeOfDay.Add();
                                            //startDate = endDate.AddMinutes(30);

                                        }
                                        oDbDataSource.SetValue(matrixNoHrsColumnUDF, i, Convert.ToString(noHrs));

                                    }
                                    oMatrix.LoadFromDataSource();
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    //objclsComman.ReleaseObject(oRs);
                                }

                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == machineCodeUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"Code\" ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE NOT EXISTS  ");
                                sbQuery.Append(" ( SELECT 1 FROM  \"" + headerTable + "\" IT0 WHERE T0.\"Code\" = \"" + machineCodeUDF + "\")");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_MAC, clsMachineMaster.objType, sbQuery.ToString(), CommonFields.Code, null);

                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixAdviceNoColumnUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\" ");
                                    sbQuery.Append(" FROM \"ORDR\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"RDR1\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                                    sbQuery.Append(" INNER JOIN \"NNM1\" T2 ON T0.\"" + CommonFields.Series + "\" = T2.\"" + CommonFields.Series + "\" ");
                                    sbQuery.Append(" WHERE T2.\"SeriesName\" LIKE '%OC%' ");

                                    //sbQuery.Append(" WHERE T1.\"Quantity\" - IFNULL(T1.\"U_DPrdQty\",0) > 0 AND T2.\"SeriesName\" LIKE '%OC%' ");

                                    //sbQuery.Append(" WHERE NOT EXISTS( ");
                                    //sbQuery.Append(" SELECT 1 FROM \"" + rowTable + "\" IT0 WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + matrixAdviceDocEntryColumnUDF + "\")");

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_SO, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oOrders), sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                                }

                                //else if (pVal.ColUID == matrixProductCodeColumnUID)
                                //{
                                //    oForm = oApplication.Forms.Item(pVal.FormUID);
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                //    string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                //    sbQuery.Length = 0;
                                //    sbQuery.Append(" SELECT \"U_Process\" ");
                                //    sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                //    sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" ='" + machineCode + "' ");
                                //    string process = objclsComman.SelectRecord(sbQuery.ToString()).Trim();

                                //    ArrayList alCondVal = new ArrayList();
                                //    ArrayList temp = new ArrayList();
                                //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //    string soDocEntry = oDbDataSource.GetValue(matrixAdviceDocEntryColumnUDF, pVal.Row - 1).Trim();
                                //    sbQuery.Length = 0;
                                //    sbQuery.Append(" Select \"ItemCode\" FROM \"" + salesOrderRowTable + "\" ");
                                //    sbQuery.Append("  WHERE \"DocEntry\" = '" + soDocEntry + "' ");

                                //    if (process.ToLower() == "extrusion" || process.ToLower() == "printing")
                                //    {
                                //        string fgItemCode = objclsComman.SelectRecord(sbQuery.ToString());
                                //        List<clsBOMEntity> itemParamterList = new List<clsBOMEntity>();
                                //        List<clsBOMEntity> sfgItemList = new List<clsBOMEntity>();

                                //        itemParamterList.Add(new clsBOMEntity
                                //        {
                                //            SOItemCode = fgItemCode,
                                //            SOQuantity= fgItemCode,
                                //            ItemCode = fgItemCode,
                                //            Process = process,
                                //            SFGItemCode = fgItemCode
                                //        });
                                //        objclsComman.GetSFGItemsFromCustomBOM1(itemParamterList);
                                //        var match = clsVariables.BOMList
                                //                .FirstOrDefault(stringToCheck => stringToCheck.Process.Contains(process) && stringToCheck.MachineCode.Contains(machineCode));
                                //        clsVariables.ItemList = null;
                                //        var items = "'" + string.Join("','", match.ItemCode) + "'";
                                //        sbQuery.Length = 0;
                                //        sbQuery.Append(" Select T0.\"ItemCode\" ");
                                //        sbQuery.Append(" FROM \"" + CommonTables.ItemMasterData + "\" T0 ");
                                //        sbQuery.Append("  WHERE \"" + CommonFields.ItemCode + "\" IN ( " + items + ")");
                                //    }
                                //    objclsComman.AddChooseFromList_WithCond(oForm, CFL_MITEM, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oItems), sbQuery.ToString(), CommonFields.ItemCode, alCondVal);
                                //}

                                else if (pVal.ColUID == matrixRewindBatchColumnUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string rewWhs = oDbDataSource.GetValue(matrixRewindWhsCodeColumnUDF, pVal.Row - 1).Trim();
                                    string rewItemCode = oDbDataSource.GetValue(matrixProductCodeColumnUDF, pVal.Row - 1).Trim();
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T1.\"DistNumber\" FROM OBTQ T0 ");
                                    sbQuery.Append(" INNER JOIN OBTN T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" AND T0.\"SysNumber\" = T1.\"SysNumber\" ");
                                    sbQuery.Append(" WHERE T0.\"ItemCode\" = '" + rewItemCode + "' AND T0.\"WhsCode\" = '" + rewWhs + "' ");
                                    sbQuery.Append(" GROUP BY \"DistNumber\", T0.\"WhsCode\" ");
                                    sbQuery.Append(" HAVING Sum(T0.\"Quantity\") > 0  ");

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_RBAT, "10000044", sbQuery.ToString(), CommonFields.DistNumber, alCondVal);
                                }
                            }
                        }
                        #endregion

                        #region T_et_CLICK
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CLICK)
                        {
                            if (pVal.ItemUID == machineCodeLinkedButtonUID)
                            {
                                BubbleEvent = false;
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string machineCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).Trim();
                                clsMachineMaster obj = new clsMachineMaster();
                                obj.LoadForm(clsMachineMaster.formMenuUID);
                                oForm = oApplication.Forms.ActiveForm;
                                oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.Code).Specific;
                                oEdit.String = machineCode;
                                oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Add)).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            }

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();

                                string itemCode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                string scrapRate = oDataTable.GetValue(Budgted_Scrap_RateUDF, 0).ToString();
                                double dblScrapRate = scrapRate == string.Empty ? 1 : double.Parse(scrapRate);
                                dblScrapRate = dblScrapRate == 0 ? 1 : dblScrapRate;
                                string macCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).Trim();
                                string soDocEntry = oDbDataSource.GetValue(matrixAdviceDocEntryColumnUDF, pVal.Row - 1).ToString();

                                oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());

                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT * ");
                                sbQuery.Append(" FROM \"" + machineRowTable + "\" ");
                                sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" = '" + macCode + "' ");
                                sbQuery.Append(" AND \"" + matrixProductCodeColumnUDF + "\" = '" + itemCode + "' ");
                                SAPbobsCOM.Recordset oRsMachine = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRsMachine.RecordCount == 0)
                                {
                                    oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, string.Empty);
                                    //oDbDataSource.SetValue(matrixWhsCodeColumnUDF, pVal.Row - 1, string.Empty);

                                    oMatrix.LoadFromDataSource();
                                    oApplication.StatusBar.SetText("Item is not linked with machine master", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT * ");
                                sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" ");
                                sbQuery.Append(" WHERE \"" + clsBOMMaster.machineCodeUDF + "\" = '" + macCode + "' ");
                                sbQuery.Append(" AND \"" + clsBOMMaster.productCodeUDF + "\" = '" + itemCode + "' ");
                                oRsMachine = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRsMachine.RecordCount == 0)
                                {
                                    oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, string.Empty);
                                    //   oDbDataSource.SetValue(matrixWhsCodeColumnUDF, pVal.Row - 1, string.Empty);

                                    oMatrix.LoadFromDataSource();
                                    oApplication.StatusBar.SetText("Item & machine combination is not availble in customized BOM", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT * ");
                                sbQuery.Append(" FROM \"" + salesOrderRowTable + "\" ");
                                sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' ");
                                sbQuery.Append(" AND \"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());

                                if (oRs.RecordCount > 0)
                                {
                                    //oDbDataSource.SetValue(matrixWhsCodeColumnUDF, pVal.Row - 1, oRs.Fields.Item(CommonFields.WhsCode).Value);
                                    oDbDataSource.SetValue(matrixSORateColumnUDF, pVal.Row - 1, oRs.Fields.Item(CommonFields.Price).Value);

                                    oDbDataSource.SetValue(matrixCapacityColumnUDF, pVal.Row - 1, oRsMachine.Fields.Item(matrixCapacityColumnUDF).Value);

                                    oDbDataSource.SetValue(matrixPerPCWtColumnUDF, pVal.Row - 1, oDataTable.GetValue(pcsPerWeightUDF, 0).ToString());
                                    //oDbDataSource.SetValue(matrixPerPCWtColumnUDF, pVal.Row - 1, oRs.Fields.Item(pcsPerWeightUDF).Value);

                                    oDbDataSource.SetValue(matrixNumPerMsColumnUDF, pVal.Row - 1, oRs.Fields.Item("NumPerMsr").Value);
                                    oDbDataSource.SetValue(matrixPackUnitColumnUDF, pVal.Row - 1, oRs.Fields.Item("UomCode").Value);
                                    oDbDataSource.SetValue(matrixStockQtyColumnUDF, pVal.Row - 1, oDataTable.GetValue("OnHand", 0).ToString());
                                    oDbDataSource.SetValue(matrixStockUnitColumnUDF, pVal.Row - 1, oDataTable.GetValue("InvntryUom", 0).ToString());

                                    string dpdQty = oRs.Fields.Item("U_DPrdQty").Value.ToString();
                                    dpdQty = dpdQty == string.Empty ? "0" : dpdQty;

                                    double quantity = double.Parse(oRs.Fields.Item(CommonFields.Quantity).Value.ToString());
                                    quantity = quantity - double.Parse(dpdQty);
                                    oDbDataSource.SetValue(matrixAdviceQuantityColumnUDF, pVal.Row - 1, quantity.ToString());

                                    //oDbDataSource.SetValue(matrixPackQtyColumnUDF, pVal.Row - 1, Convert.ToString(((dblScrapRate / 100) * quantity) + quantity));
                                    //oDbDataSource.SetValue(matrixBaseQtyColumnUDF, pVal.Row - 1, Convert.ToString(((dblScrapRate / 100) * quantity) + quantity));

                                }
                                objclsComman.ReleaseObject(oRs);

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixProductCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_SO)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixAdviceNoColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(matrixAdviceDocEntryColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());

                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.DocDate, 0).ToString());
                                oDbDataSource.SetValue(matrixAdviceDateColumnUDF, pVal.Row - 1, objclsComman.ConvertDateToSAPDateFormat(docDate));

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixAdviceNoColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RWHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixRewindWhsCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixRewindWhsCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RBAT)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixRewindBatchColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DistNumber, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixRewindBatchColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_KEY_DOWN
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
                        {
                            try
                            {
                                if (pVal.ItemUID == matrixUID)
                                {
                                    if (pVal.CharPressed == 9)
                                    {
                                        oForm = oApplication.Forms.Item(pVal.FormUID);

                                        #region SO 
                                        if (pVal.ColUID == matrixAdviceNoColumnUID)
                                        {
                                            oMatrix = oForm.Items.Item(matrixUID).Specific;
                                            oMatrix.FlushToDataSource();
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                            string ocNo = oDbDataSource.GetValue(matrixAdviceNoColumnUDF, pVal.Row - 1);
                                            if (ocNo == string.Empty)
                                            {
                                                if (pVal.Row == oMatrix.RowCount)
                                                {
                                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                                    int RowNo = 1;
                                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                                    {
                                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                                        RowNo = RowNo + 1;
                                                    }
                                                }
                                                oMatrix.LoadFromDataSource();

                                                clsVariables.BaseFormUID = oForm.UniqueID;
                                                string rowNo = pVal.Row.ToString();
                                                clsDailyPlanSOSelection obj = new clsDailyPlanSOSelection();
                                                obj.LoadForm(rowNo);
                                            }
                                        }
                                        #endregion

                                        #region Product Code
                                        else if (pVal.ColUID == matrixProductCodeColumnUID)
                                        {
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                            string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                            sbQuery.Length = 0;
                                            sbQuery.Append(" SELECT \"U_Process\" ");
                                            sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                            sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" ='" + machineCode + "' ");
                                            string process = objclsComman.SelectRecord(sbQuery.ToString()).Trim();

                                            oMatrix = oForm.Items.Item(matrixUID).Specific;
                                            oMatrix.FlushToDataSource();
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                            string soDocEntry = oDbDataSource.GetValue(matrixAdviceDocEntryColumnUDF, pVal.Row - 1).Trim();
                                            string soItemCode = oDbDataSource.GetValue(matrixAdviceItemCodeColumnUDF, pVal.Row - 1).Trim();

                                            //string soItemCode = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemCode + "\" FROM RDR1 WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "'");
                                            if (process.ToLower() == "bag making")
                                            {
                                                sbQuery.Length = 0;
                                                sbQuery.Append(" Select 'N' AS \"Chk\",\"ItemCode\" AS \"SOItemCode\", T1.\"Quantity\" AS \"SOQuantity\",\"ItemCode\",\"Dscription\" AS \"ItemName\"");
                                                //sbQuery.Append(" , (T1.\"" + CommonFields.NumPerMsr + "\"  * T1.\"Quantity\") ");
                                                sbQuery.Append(" , T1.\"Quantity\" ");
                                                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                                                {
                                                    sbQuery.Append(" - IFNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                                }
                                                else
                                                {
                                                    sbQuery.Append(" - ISNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                                }
                                                sbQuery.Append(" FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" = T1.\"ItemCode\"),0) ");
                                                sbQuery.Append("  AS \"PlanQty\" ");
                                                sbQuery.Append(" FROM \"" + salesOrderHeaderTable + "\" T0 ");
                                                sbQuery.Append(" INNER JOIN \"" + salesOrderRowTable + "\" T1 ON T0.\"DocEntry\" =T1.\"DocEntry\"");
                                                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + soDocEntry + "' ");
                                                sbQuery.Append(" AND T1.\"ItemCode\" = '" + soItemCode + "' ");
                                            }
                                            else
                                            {
                                                List<clsItemEntity> sfList = new List<clsItemEntity>();
                                                clsVariables.BOMList = new List<clsBOMEntity>();

                                                sbQuery.Length = 0;
                                                sbQuery.Append(" Select \"ItemCode\",\"Quantity\" FROM \"" + CommonTables.SalesOrderRowTable + "\" ");
                                                sbQuery.Append("  WHERE \"DocEntry\" = '" + soDocEntry + "' AND  \"ItemCode\" = '" + soItemCode + "' ");

                                                SAPbobsCOM.Recordset oRsSO = objclsComman.returnRecord(sbQuery.ToString());
                                                while (!oRsSO.EoF)
                                                {
                                                    string fgItemCode = oRsSO.Fields.Item("ItemCode").Value;
                                                    string Quantity = oRsSO.Fields.Item("Quantity").Value.ToString();
                                                    string NumPerMsr = objclsComman.SelectRecord("SELECT \"" + CommonFields.NumPerMsr + "\" FROM RDR1 WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' AND \"" + CommonFields.ItemCode + "\" = '" + fgItemCode + "'");

                                                    Quantity = Convert.ToString(double.Parse(Quantity) * double.Parse(NumPerMsr));
                                                    List<clsBOMEntity> itemParamterList = new List<clsBOMEntity>();
                                                    List<clsBOMEntity> sfgItemList = new List<clsBOMEntity>();

                                                    itemParamterList.Add(new clsBOMEntity
                                                    {
                                                        SOItemCode = fgItemCode,
                                                        SOQuantity = Quantity,
                                                        ItemCode = fgItemCode,
                                                        Process = process,
                                                        SFGItemCode = fgItemCode,
                                                        SFGQty = Quantity
                                                    });

                                                    oApplication.StatusBar.SetText("Please wait...data loading", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                                                    //if (fgItemCode == "FGPET000048")
                                                    //{
                                                    objclsComman.GetSFGItemsFromCustomBOM_DataTable(oForm, itemParamterList);
                                                    //}
                                                    oRsSO.MoveNext();
                                                }
                                                var list = clsVariables.BOMList.Where(p => p.Process == process && p.MachineCode == machineCode).ToList();
                                                clsVariables.BOMList = null;
                                                list = list.GroupBy(x => x.SFGItemCode).Select(x => x.First()).ToList();

                                                sbQuery.Length = 0;
                                                bool itemExist = false;
                                                for (int i = 0; i < list.Count; i++)
                                                {

                                                    string itemCode = list[i].SFGItemCode;
                                                    soItemCode = list[i].SOItemCode;
                                                    string soQuantity = list[i].SOQuantity;

                                                    //items = items +"'"+ list[i].ItemCode.ToString() + "',";
                                                    string baseQty = objclsComman.SelectRecord("SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" ='" + itemCode + "' ");
                                                    //string soQuantity = objclsComman.SelectRecord("SELECT \"" + CommonFields.Quantity + "\"FROM \"" + CommonTables.SalesOrderRowTable + "\" WHERE \"" + CommonFields.DocEntry + "\" ='" + soDocEntry + "' AND \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");
                                                    decimal dblBaseQty = baseQty == string.Empty ? 0 : decimal.Parse(baseQty);
                                                    decimal dblPlanQty = Math.Round(decimal.Parse(list[i].SFGQty), 3) - dblBaseQty;
                                                    if (dblPlanQty != 0)
                                                    {
                                                        if (i > 0 && sbQuery.Length > 0)
                                                        {
                                                            sbQuery.Append(" UNION ALL ");
                                                        }
                                                        sbQuery.Append(" Select 'N' AS \"Chk\",'" + soItemCode + "'AS \"SOItemCode\",'" + soQuantity + "' AS\"SOQuantity\",T0.\"ItemCode\",\"ItemName\",'" + dblPlanQty.ToString() + "' AS \"PlanQty\" ");
                                                        sbQuery.Append(" FROM \"" + CommonTables.ItemMasterData + "\" T0 ");
                                                        sbQuery.Append("  WHERE \"" + CommonFields.ItemCode + "\" IN ('" + itemCode + "')");
                                                        itemExist = true;
                                                    }
                                                }
                                                if (itemExist == false)
                                                {
                                                    oApplication.StatusBar.SetText("No SFG Items", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                    return;
                                                }
                                            }

                                            clsVariables.BaseFormUID = pVal.FormUID;
                                            clsDailyPlanItemSelection obj = new clsDailyPlanItemSelection();
                                            obj.LoadForm(pVal.Row.ToString(), soDocEntry, machineCode, soItemCode, process);
                                            obj.FillGrid(sbQuery.ToString());

                                        }
                                        #endregion

                                        #region Old Product Code
                                        else if (pVal.ColUID == "")
                                        {
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                            string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                            sbQuery.Length = 0;
                                            sbQuery.Append(" SELECT \"U_Process\" ");
                                            sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                            sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" ='" + machineCode + "' ");
                                            string process = objclsComman.SelectRecord(sbQuery.ToString()).Trim();


                                            oMatrix = oForm.Items.Item(matrixUID).Specific;
                                            oMatrix.FlushToDataSource();
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                            string soDocEntry = oDbDataSource.GetValue(matrixAdviceDocEntryColumnUDF, pVal.Row - 1).Trim();
                                            string soItemCode = oDbDataSource.GetValue(matrixAdviceItemCodeColumnUDF, pVal.Row - 1).Trim();

                                            clsVariables.BaseFormUID = pVal.FormUID;
                                            clsDailyPlanItemSelection obj = new clsDailyPlanItemSelection();
                                            obj.LoadForm(pVal.Row.ToString(), soDocEntry, machineCode, soItemCode, process);
                                            //sbQuery.Length = 0;
                                            //obj.FillGrid(sbQuery.ToString());

                                            return;

                                            //string soItemCode = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemCode + "\" FROM RDR1 WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "'");
                                            if (process.ToLower() == "bag making")
                                            {
                                                sbQuery.Length = 0;
                                                sbQuery.Append(" Select 'N' AS \"Chk\",\"ItemCode\" AS \"SOItemCode\", T1.\"Quantity\" AS \"SOQuantity\",\"ItemCode\",\"Dscription\" AS \"ItemName\"");
                                                //sbQuery.Append(" , (T1.\"" + CommonFields.NumPerMsr + "\"  * T1.\"Quantity\") ");
                                                sbQuery.Append(" , T1.\"Quantity\" ");
                                                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                                                {
                                                    sbQuery.Append(" - IFNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                                }
                                                else
                                                {
                                                    sbQuery.Append(" - ISNULL((SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") ");
                                                }
                                                sbQuery.Append(" FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" = T1.\"ItemCode\"),0) ");
                                                sbQuery.Append("  AS \"PlanQty\" ");
                                                sbQuery.Append(" FROM \"" + salesOrderHeaderTable + "\" T0 ");
                                                sbQuery.Append(" INNER JOIN \"" + salesOrderRowTable + "\" T1 ON T0.\"DocEntry\" =T1.\"DocEntry\"");
                                                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + soDocEntry + "' ");
                                                sbQuery.Append(" AND T1.\"ItemCode\" = '" + soItemCode + "' ");
                                            }
                                            else
                                            {
                                                List<clsItemEntity> sfList = new List<clsItemEntity>();
                                                clsVariables.BOMList = new List<clsBOMEntity>();

                                                sbQuery.Length = 0;
                                                sbQuery.Append(" Select \"ItemCode\",\"Quantity\" FROM \"" + CommonTables.SalesOrderRowTable + "\" ");
                                                sbQuery.Append("  WHERE \"DocEntry\" = '" + soDocEntry + "' AND  \"ItemCode\" = '" + soItemCode + "' ");

                                                SAPbobsCOM.Recordset oRsSO = objclsComman.returnRecord(sbQuery.ToString());
                                                while (!oRsSO.EoF)
                                                {
                                                    string fgItemCode = oRsSO.Fields.Item("ItemCode").Value;
                                                    string Quantity = oRsSO.Fields.Item("Quantity").Value.ToString();
                                                    string NumPerMsr = objclsComman.SelectRecord("SELECT \"" + CommonFields.NumPerMsr + "\" FROM RDR1 WHERE \"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' AND \"" + CommonFields.ItemCode + "\" = '" + fgItemCode + "'");

                                                    Quantity = Convert.ToString(double.Parse(Quantity) * double.Parse(NumPerMsr));
                                                    List<clsBOMEntity> itemParamterList = new List<clsBOMEntity>();
                                                    List<clsBOMEntity> sfgItemList = new List<clsBOMEntity>();

                                                    itemParamterList.Add(new clsBOMEntity
                                                    {
                                                        SOItemCode = fgItemCode,
                                                        SOQuantity = Quantity,
                                                        ItemCode = fgItemCode,
                                                        Process = process,
                                                        SFGItemCode = fgItemCode,
                                                        SFGQty = Quantity
                                                    });

                                                    oApplication.StatusBar.SetText("Please wait...data loading", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                                                    //if (fgItemCode == "FGPET000048")
                                                    //{
                                                    objclsComman.GetSFGItemsFromCustomBOM_DataTable(oForm, itemParamterList);
                                                    //}
                                                    oRsSO.MoveNext();
                                                }
                                                var list = clsVariables.BOMList.Where(p => p.Process == process && p.MachineCode == machineCode).ToList();
                                                clsVariables.BOMList = null;
                                                list = list.GroupBy(x => x.SFGItemCode).Select(x => x.First()).ToList();

                                                sbQuery.Length = 0;
                                                bool itemExist = false;
                                                for (int i = 0; i < list.Count; i++)
                                                {

                                                    string itemCode = list[i].SFGItemCode;
                                                    soItemCode = list[i].SOItemCode;
                                                    string soQuantity = list[i].SOQuantity;

                                                    //items = items +"'"+ list[i].ItemCode.ToString() + "',";
                                                    string baseQty = objclsComman.SelectRecord("SELECT SUM(\"" + clsDailyPlan.matrixQuantityColumnUDF + "\") FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\" ='" + soDocEntry + "' AND \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" ='" + itemCode + "' ");
                                                    //string soQuantity = objclsComman.SelectRecord("SELECT \"" + CommonFields.Quantity + "\"FROM \"" + CommonTables.SalesOrderRowTable + "\" WHERE \"" + CommonFields.DocEntry + "\" ='" + soDocEntry + "' AND \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");
                                                    decimal dblBaseQty = baseQty == string.Empty ? 0 : decimal.Parse(baseQty);
                                                    decimal dblPlanQty = Math.Round(decimal.Parse(list[i].SFGQty), 3) - dblBaseQty;
                                                    if (dblPlanQty != 0)
                                                    {
                                                        if (i > 0 && sbQuery.Length > 0)
                                                        {
                                                            sbQuery.Append(" UNION ALL ");
                                                        }
                                                        sbQuery.Append(" Select 'N' AS \"Chk\",'" + soItemCode + "'AS \"SOItemCode\"," + soQuantity + " AS\"SOQuantity\",T0.\"ItemCode\",\"ItemName\",'" + dblPlanQty.ToString() + "' AS \"PlanQty\" ");
                                                        sbQuery.Append(" FROM \"" + CommonTables.ItemMasterData + "\" T0 ");
                                                        sbQuery.Append("  WHERE \"" + CommonFields.ItemCode + "\" IN ('" + itemCode + "')");
                                                        itemExist = true;
                                                    }
                                                }
                                                if (itemExist == false)
                                                {
                                                    oApplication.StatusBar.SetText("No SFG Items", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                    return;
                                                }
                                            }



                                        }
                                        #endregion

                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: F_KeyDown " + ex.Message);
                                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: F_KeyDown " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixQuantityColumnUID)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string itemCode = oDbDataSource.GetValue(matrixProductCodeColumnUDF, pVal.Row - 1).ToString();
                                    string scrapRate = objclsComman.SelectRecord("SELECT \"" + Budgted_Scrap_RateUDF + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");
                                    double dblQuantity = double.Parse(oDbDataSource.GetValue(matrixQuantityColumnUDF, pVal.Row - 1).ToString());
                                    //double dblScrapRate = scrapRate == string.Empty ? 1 : double.Parse(scrapRate);
                                    //dblScrapRate = dblScrapRate == 0 ? 1 : dblScrapRate;

                                    //double dblPackQty = ((dblScrapRate / 100) * dblQuantity) + dblQuantity;
                                    double dblPackQty = dblQuantity;

                                    oDbDataSource.SetValue(matrixPackQtyColumnUDF, pVal.Row - 1, dblPackQty.ToString());
                                    //oDbDataSource.SetValue(matrixBaseQtyColumnUDF, pVal.Row - 1, dblPackQty.ToString());

                                    string pcweight = oDbDataSource.GetValue(matrixPerPCWtColumnUDF, pVal.Row - 1).ToString();
                                    double dblPerPcsWeight = pcweight == string.Empty ? 0 : double.Parse(pcweight);

                                    string cap = oDbDataSource.GetValue(matrixCapacityColumnUDF, pVal.Row - 1).ToString();
                                    double dblCap = cap == string.Empty ? 0 : double.Parse(cap);

                                    double weightInKgs = dblPackQty * dblPerPcsWeight;
                                    oDbDataSource.SetValue(matrixWtKgColumnUDF, pVal.Row - 1, Convert.ToString(weightInKgs));

                                    double noHrs = 0;
                                    if (dblCap != 0)
                                    {
                                        noHrs = weightInKgs / dblCap;
                                        double fraction = noHrs - Math.Truncate(noHrs);
                                        fraction = fraction * 60;
                                        int hr = (int)noHrs;

                                        double min = Math.Round(fraction);
                                        string day = "0 days ";
                                        string hh = hr.ToString() + " hour ";
                                        string minMM = min.ToString() + " Minutes";
                                        oDbDataSource.SetValue(matrixNoHrsHMColumnUDF, pVal.Row - 1, hh + minMM);
                                        oDbDataSource.SetValue(matrixNoDayColumnUDF, pVal.Row - 1, day + hh + minMM);

                                    }
                                    oDbDataSource.SetValue(matrixNoHrsColumnUDF, pVal.Row - 1, Convert.ToString(noHrs));

                                    oMatrix.LoadFromDataSource();
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        int selrow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        if (selrow == -1)
                        {
                            oApplication.StatusBar.SetText("Please select row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            BubbleEvent = false;
                            return;
                        }
                        oMatrix.FlushToDataSource();
                        oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                        if (oDbDataSource.GetValue(matrixPOEnColumnUDF, selrow - 1) != string.Empty)
                        {
                            string status = objclsComman.SelectRecord("SELECT \"Status\" FROM OWOR WHERE\"" + CommonFields.DocEntry + "\"='" + oDbDataSource.GetValue(matrixPOEnColumnUDF, selrow - 1) + "'");
                            if (status.Trim() != "C")
                            {
                                oApplication.StatusBar.SetText("You can't delete row, as Production order is already made", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                            }
                            return;
                        }
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixProductCodeColumnUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixProductCodeColumnUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixPrimaryColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  ISNULL(\"" + matrixPrimaryColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0);
                        if (status == "C")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                            DisableControls(oForm.UniqueID);
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                            oMatrix.LoadFromDataSource();
                            EnableControls(oForm.UniqueID);
                            DisableRow(oMatrix);
                            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                            oEdit.String = "t";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            clsVariables.boolCFLSelected = false;
            if (MenuID == formMenuUID)
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.EnableMenu("5895", true);

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                    SetLineId(oMatrix);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
                string addonName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name; //New Menu Name in Add-on Layouts

                string ReportType = objclsComman.SelectRecord("SELECT \"CODE\" FROM RTYP WHERE \"MNU_ID\" = '" + MenuID + "' AND \"ADD_NAME\" = '" + addonName + "'");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixRewindShiftColumnUID, 1);
                objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SHIFTMASTER\" ");
            }
            oForm = oApplication.Forms.ActiveForm;
            EnableControls(oForm.UniqueID);

            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                #endregion

                //string planNo = AutoPlanNo();
                //oForm.DataSources.DBDataSources.Item(headerTable).SetValue(planNoUDF, 0, planNo);
            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocNum");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("DocEntry");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("Series");
            oItem.EnableinAddMode();

            oItem = oForm.Items.Item(machineCodeUID);
            oItem.EnableinAddMode();
        }

        private string AutoPlanNo()
        {
            sbQuery = new StringBuilder();
            //sbQuery.Append(" SELECT MAX(CAST(\"" + planNoUDF + "\" AS INT)) FROM \"" + headerTable + "\" ");
            string planNo = objclsComman.SelectRecord(sbQuery.ToString());
            planNo = planNo == string.Empty ? "1" : Convert.ToString(Int32.Parse(planNo) + 1);
            return planNo;
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }

        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }

        private void Create_ProdcutionOrder_Special(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.\"" + matrixAdviceDocEntryColumnUDF + "\",T1.\"" + matrixAdviceNoColumnUDF + "\",T0.\"U_DocDate\", T1.\"LineId\",T1.\"U_StDate\",T1.\"U_EnDate\",T1.\"" + matrixPackQtyColumnUDF + "\",T1.\"U_PrdCode\",T0.\"DocNum\" ");
            sbQuery.Append(" ,T1.\"U_PackUnit\", T1.\"U_StkUnit\", T2.\"UgpEntry\",T1.\"" + matrixNumPerMsColumnUDF + "\" ");
            sbQuery.Append(" ,T0.\"" + machineCodeUDF + "\", T0.\"" + machineNameUDF + "\" , T0.\"" + planDateUDF + "\"");
            sbQuery.Append(" ,T1.\"" + matrixQuantityColumnUDF + "\",T1.\"" + matrixBPOEnUDF + "\", T1.\"" + matrixBPONoUDF + "\" ");

            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixPOEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixPOEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    //oApplication.StatusBar.SetText(sbQuery.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    oApplication.MessageBox(" No Production order found to create. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create production order?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

                    try
                    {
                        lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();
                        string ugpEntry = oDataTable.GetValue("UgpEntry", j).ToString();
                        string packUnit = oDataTable.GetValue(matrixPackUnitColumnUDF, j).ToString();
                        string stockUnit = oDataTable.GetValue(matrixStockUnitColumnUDF, j).ToString();
                        string perUnitConvValue = oDataTable.GetValue(matrixNumPerMsColumnUDF, j).ToString();
                        double dblPerUnitConvValue = perUnitConvValue == string.Empty ? 1 : double.Parse(perUnitConvValue);
                        string itemCode = oDataTable.GetValue(matrixProductCodeColumnUDF, j).ToString().Trim();
                        string macCode = oDataTable.GetValue("U_MacCode", 0).ToString().Trim();

                        //double dblPlannedQty = dblPerUnitConvValue * double.Parse(oDataTable.GetValue(matrixPackQtyColumnUDF, j).ToString().Trim());
                        double dblPlannedQty = double.Parse(oDataTable.GetValue(matrixPackQtyColumnUDF, j).ToString().Trim());

                        #region Setting Production Order Headers

                        //wo.Series = Int32.Parse(oDataTable_Items.GetValue("Series", 0).ToString());
                        if (oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString() == string.Empty)
                        {
                            oApplication.StatusBar.SetText("Start date is empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            objclsComman.RefreshRecord();
                            return;
                        }

                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T0.\"" + clsBOMMaster.whsCodeUDF + "\",T0.\"U_Qty\" AS \"BOMHeaderQty\",T1.*  ");
                        sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                        sbQuery.Append(" INNER JOIN \"" + clsBOMMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                        sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' AND T0.\"" + clsBOMMaster.machineCodeUDF + "\" ='" + oDataTable.GetValue("U_MacCode", 0).ToString().Trim() + "' ");

                        oRs = objclsComman.returnRecord(sbQuery.ToString());

                        //wo.PostingDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString());
                        //wo.StartDate = DateTime.Parse(oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString());
                        //wo.DueDate = DateTime.Parse(oDataTable.GetValue(matrixEndDateColumnUDF, j).ToString());

                        wo.StartDate = DateTime.Parse(oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString());
                        wo.DueDate = DateTime.Parse(oDataTable.GetValue(matrixEndDateColumnUDF, j).ToString());
                        wo.PostingDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString().Trim());

                        wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotSpecial;
                        wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                        wo.ItemNo = oDataTable.GetValue(matrixProductCodeColumnUDF, j).ToString().Trim();
                        wo.Warehouse = oRs.Fields.Item(clsBOMMaster.whsCodeUDF).Value.ToString().Trim();
                        wo.PlannedQuantity = dblPlannedQty;
                        wo.ProductionOrderOriginEntry = Int32.Parse(oDataTable.GetValue(matrixAdviceDocEntryColumnUDF, j).ToString().Trim());
                        wo.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder;

                        wo.UserFields.Fields.Item("U_DailyProdPlan").Value = oDataTable.GetValue("DocNum", 0).ToString().Trim();
                        wo.UserFields.Fields.Item("U_MacCode").Value = oDataTable.GetValue("U_MacCode", 0).ToString().Trim();
                        wo.UserFields.Fields.Item("U_MacName").Value = oDataTable.GetValue("U_MacName", 0).ToString().Trim();
                        string process = objclsComman.SelectRecord("SELECT \"" + clsMachineMaster.ProcessUDF + "\" FROM \"" + clsMachineMaster.headerTable + "\" WHERE \"" + CommonFields.Code + "\" = '" + oDataTable.GetValue("U_MacCode", 0).ToString().Trim() + "'");
                        wo.UserFields.Fields.Item("U_Process").Value = process;
                        wo.UserFields.Fields.Item("U_DPPDate").Value = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString());

                        #endregion

                        #region Setting Child Items 

                        int iRow = 0;

                        while (!oRs.EoF)
                        {
                            wo.Lines.SetCurrentLine(iRow);
                            wo.Lines.ItemNo = oRs.Fields.Item(clsBOMMaster.matrixProductCodeColumnUDF).Value.ToString();
                            wo.Lines.Warehouse = oRs.Fields.Item(clsBOMMaster.matrixWhsCodeColumnUDF).Value.ToString();
                            string issueMethod = oRs.Fields.Item("U_IssMeth").Value.ToString();
                            if (issueMethod == "Manual")
                            {
                                wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                            }
                            if (issueMethod == "Backflush")
                            {
                                wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Backflush;
                            }


                            double dblBOMHeaderQty = double.Parse(oRs.Fields.Item("BOMHeaderQty").Value.ToString());
                            double dblCompQty = double.Parse(oRs.Fields.Item("U_CompQty").Value.ToString());
                            //dblBaseQty = Math.Ceiling(dblCompQty / dblBOMHeaderQty);
                            double dblBaseQty = dblPlannedQty * (dblCompQty / dblBOMHeaderQty);

                            double dblCompPlannedQty = Math.Round(dblBaseQty, 6);
                            wo.Lines.BaseQuantity = Math.Ceiling(dblCompQty / dblBOMHeaderQty);

                            wo.Lines.PlannedQuantity = dblCompPlannedQty;
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Percent").Value = oRs.Fields.Item("U_LayerPer").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Layer").Value = oRs.Fields.Item("U_Layer").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Std").Value = oRs.Fields.Item("U_Std").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Station").Value = oRs.Fields.Item("U_Station").Value.ToString();

                            }
                            catch { }
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Anilox").Value = oRs.Fields.Item("U_Anilox").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                wo.Lines.UserFields.Fields.Item("U_Viscocity").Value = oRs.Fields.Item("U_Visc").Value.ToString();
                            }
                            catch { }
                            //  wo.Lines.UserFields.Fields.Item("U_PRM_Line").Value = oDataTable_Items.GetValue("U_Line_No", k).ToString().Trim();

                            wo.Lines.Add();
                            iRow++;
                            oRs.MoveNext();
                        }
                        #endregion

                        int retVal = wo.Add();
                        if (retVal != 0)
                        {
                            oApplication.StatusBar.SetText("For Priority : " + lineId + " Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            sbMessage.Append(oCompany.GetLastErrorDescription());
                            sbMessage.Append(Environment.NewLine);
                        }
                        else
                        {
                            string PODocEntry = oCompany.GetNewObjectKey();
                            string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWOR WHERE \"DocEntry\" = '" + PODocEntry + "'");
                            string soDocEntry = oDataTable.GetValue(matrixAdviceDocEntryColumnUDF, j).ToString();
                            string quantity = oDataTable.GetValue(matrixQuantityColumnUDF, j).ToString();

                            string basePODocEntry = oDataTable.GetValue(matrixBPOEnUDF, 0).ToString().Trim();
                            string basePODocNum = oDataTable.GetValue(matrixBPONoUDF, 0).ToString().Trim();

                            //Updating Row Level Production Order Entry And No
                            objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixPOEnColumnUDF + "\" = '" + PODocEntry + "',\"" + matrixPONoColumnUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"LineId\" = '" + lineId + "'");

                            if (basePODocNum == string.Empty)
                            {
                                string dpdQty = objclsComman.SelectRecord("SELECT\"U_DPrdQty\" FROM RDR1 WHERE \"DocEntry\" ='" + soDocEntry + "' AND  \"ItemCode\" ='" + itemCode + "'  ");
                                dpdQty = dpdQty == string.Empty ? "0" : dpdQty;
                                objclsComman.SelectRecord("UPDATE T0 SET \"U_DPrdQty\" = " + dpdQty + " +  " + quantity + " FROM \"RDR1\" T0 WHERE \"DocEntry\" ='" + soDocEntry + "' AND  \"ItemCode\" ='" + itemCode + "' ");

                                objclsComman.SelectRecord("UPDATE T0 SET \"" + fatherDocEntryUDF + "\" = '" + PODocEntry + "',\"" + fatherDocNumUDF + "\" = '" + PODocNum + "' FROM \"OWOR\" T0 WHERE \"DocEntry\" ='" + PODocEntry + "'");

                            }
                            else
                            {
                                objclsComman.SelectRecord("UPDATE T0 SET \"" + fatherDocEntryUDF + "\" = '" + basePODocEntry + "',\"" + fatherDocNumUDF + "\" = '" + basePODocNum + "' FROM \"OWOR\" T0 WHERE \"DocEntry\" ='" + PODocEntry + "'");
                            }

                            //Updating Father Docentry and Father Docnum in Production Order

                            oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {

                    }
                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void Create_ProdcutionOrder(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.\"" + matrixAdviceDocEntryColumnUDF + "\",T1.\"" + matrixAdviceNoColumnUDF + "\",T0.\"U_DocDate\", T1.\"LineId\",T1.\"U_StDate\",T1.\"U_EnDate\",T1.\"" + matrixPackQtyColumnUDF + "\",T1.\"U_PrdCode\",T0.\"DocNum\" ");
            sbQuery.Append(" ,T1.\"U_PackUnit\", T1.\"U_StkUnit\", T2.\"UgpEntry\",T1.\"" + matrixNumPerMsColumnUDF + "\" ");
            sbQuery.Append(" ,T0.\"" + machineCodeUDF + "\", T0.\"" + machineNameUDF + "\" , T0.\"" + planDateUDF + "\"");
            sbQuery.Append(" ,T1.\"" + matrixQuantityColumnUDF + "\",T1.\"" + matrixBPOEnUDF + "\", T1.\"" + matrixBPONoUDF + "\" ");

            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixPOEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixPOEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    //oApplication.StatusBar.SetText(sbQuery.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    oApplication.MessageBox(" No Production order found to create. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create production order?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

                    try
                    {
                        lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();
                        string ugpEntry = oDataTable.GetValue("UgpEntry", j).ToString();
                        string packUnit = oDataTable.GetValue(matrixPackUnitColumnUDF, j).ToString();
                        string stockUnit = oDataTable.GetValue(matrixStockUnitColumnUDF, j).ToString();
                        string perUnitConvValue = oDataTable.GetValue(matrixNumPerMsColumnUDF, j).ToString();
                        double dblPerUnitConvValue = perUnitConvValue == string.Empty ? 1 : double.Parse(perUnitConvValue);
                        string itemCode = oDataTable.GetValue(matrixProductCodeColumnUDF, j).ToString().Trim();

                        #region Setting Production Order Headers

                        //wo.Series = Int32.Parse(oDataTable_Items.GetValue("Series", 0).ToString());
                        if (oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString() == string.Empty)
                        {
                            oApplication.StatusBar.SetText("Start date is empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            objclsComman.RefreshRecord();
                            return;
                        }
                        wo.StartDate = DateTime.Parse(oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString());
                        wo.DueDate = DateTime.Parse(oDataTable.GetValue(matrixEndDateColumnUDF, j).ToString());
                        wo.PostingDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString().Trim());

                        wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotStandard;
                        wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                        wo.ItemNo = oDataTable.GetValue(matrixProductCodeColumnUDF, j).ToString().Trim();
                        //wo.Warehouse = oDataTable.GetValue(matrixWhsCodeColumnUDF, j).ToString().Trim();
                        wo.PlannedQuantity = dblPerUnitConvValue * double.Parse(oDataTable.GetValue(matrixPackQtyColumnUDF, j).ToString().Trim());
                        wo.ProductionOrderOriginEntry = Int32.Parse(oDataTable.GetValue(matrixAdviceDocEntryColumnUDF, j).ToString().Trim());
                        wo.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder;
                        wo.UserFields.Fields.Item("U_DailyProdPlan").Value = oDataTable.GetValue("DocNum", 0).ToString().Trim();

                        wo.UserFields.Fields.Item("U_MacCode").Value = oDataTable.GetValue("U_MacCode", 0).ToString().Trim();
                        wo.UserFields.Fields.Item("U_MacName").Value = oDataTable.GetValue("U_MacName", 0).ToString().Trim();
                        string process = objclsComman.SelectRecord("SELECT \"" + clsMachineMaster.ProcessUDF + "\" FROM \"" + clsMachineMaster.headerTable + "\" WHERE \"" + CommonFields.Code + "\" = '" + oDataTable.GetValue("U_MacCode", 0).ToString().Trim() + "'");
                        wo.UserFields.Fields.Item("U_Process").Value = process;
                        wo.UserFields.Fields.Item("U_DPPDate").Value = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString());


                        #endregion

                        int retVal = wo.Add();
                        if (retVal != 0)
                        {
                            oApplication.StatusBar.SetText("For Priority : " + lineId + " Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            sbMessage.Append(oCompany.GetLastErrorDescription());
                            sbMessage.Append(Environment.NewLine);
                        }
                        else
                        {
                            string PODocEntry = oCompany.GetNewObjectKey();
                            string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWOR WHERE \"DocEntry\" = '" + PODocEntry + "'");
                            string soDocEntry = oDataTable.GetValue(matrixAdviceDocEntryColumnUDF, j).ToString();
                            string quantity = oDataTable.GetValue(matrixQuantityColumnUDF, j).ToString();

                            string basePODocEntry = oDataTable.GetValue(matrixBPOEnUDF, 0).ToString().Trim();
                            string basePODocNum = oDataTable.GetValue(matrixBPONoUDF, 0).ToString().Trim();

                            //Updating Row Level Production Order Entry And No
                            objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixPOEnColumnUDF + "\" = '" + PODocEntry + "',\"" + matrixPONoColumnUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"LineId\" = '" + lineId + "'");

                            if (basePODocNum == string.Empty)
                            {
                                string dpdQty = objclsComman.SelectRecord("SELECT\"U_DPrdQty\" FROM RDR1 WHERE \"DocEntry\" ='" + soDocEntry + "' AND  \"ItemCode\" ='" + itemCode + "'  ");
                                dpdQty = dpdQty == string.Empty ? "0" : dpdQty;
                                objclsComman.SelectRecord("UPDATE T0 SET \"U_DPrdQty\" = " + dpdQty + " +  " + quantity + " FROM \"RDR1\" T0 WHERE \"DocEntry\" ='" + soDocEntry + "' AND  \"ItemCode\" ='" + itemCode + "' ");

                                objclsComman.SelectRecord("UPDATE T0 SET \"" + fatherDocEntryUDF + "\" = '" + PODocEntry + "',\"" + fatherDocNumUDF + "\" = '" + PODocNum + "' FROM \"OWOR\" T0 WHERE \"DocEntry\" ='" + PODocEntry + "'");

                            }
                            else
                            {
                                objclsComman.SelectRecord("UPDATE T0 SET \"" + fatherDocEntryUDF + "\" = '" + basePODocEntry + "',\"" + fatherDocNumUDF + "\" = '" + basePODocNum + "' FROM \"OWOR\" T0 WHERE \"DocEntry\" ='" + PODocEntry + "'");
                            }

                            //Updating Father Docentry and Father Docnum in Production Order

                            oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {

                    }
                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void Create_ProdcutionOrder_SFG(string DocEntry, string lineID, string fgItemCode, string fatherDocEntry, string fatherDocNum)
        {
            oForm = oApplication.Forms.ActiveForm;
            string orderDataTableUID = "OrdNo1";
            SAPbouiCOM.DataTable oDataTable = null;
            SAPbobsCOM.Recordset oRs = null;

            sbQuery.Length = 0;
            sbQuery.Append(" SELECT T1.\"Code\" ");
            sbQuery.Append(" FROM OITT T0 ");
            sbQuery.Append(" INNER JOIN ITT1 T1 ON T0.\"Code\" = T1.\"Father\" ");
            sbQuery.Append(" INNER JOIN OITM T2 ON T1.\"Code\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"Code\" = '" + fgItemCode + "' AND T2.\"TreeType\" = 'P' ");
            SAPbobsCOM.Recordset oRsItems = objclsComman.returnRecord(sbQuery.ToString());
            if (oRsItems.RecordCount == 0)
            {
                return;
            }
            try
            {
                while (!oRsItems.EoF)
                {
                    string prdCode = oRsItems.Fields.Item("Code").Value;

                    string lineId = string.Empty;
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T1.\"" + matrixAdviceDocEntryColumnUDF + "\",T1.\"" + matrixAdviceNoColumnUDF + "\",T0.\"U_DocDate\", T1.\"LineId\",T1.\"U_StDate\",T1.\"U_EnDate\",T1.\"U_PackQty\",'" + prdCode + "' \"U_PrdCode\",T0.\"DocNum\", ");
                    sbQuery.Append(" T1.\"U_PackUnit\", T1.\"U_StkUnit\",T1.\"" + matrixNumPerMsColumnUDF + "\" ");
                    sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"LineId\" = '" + lineID + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");

                    try
                    {
                        oForm.DataSources.DataTables.Add(orderDataTableUID);
                    }
                    catch
                    {
                    }
                    oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
                    oDataTable.ExecuteQuery(sbQuery.ToString());

                    oRs = objclsComman.returnRecord(sbQuery.ToString());

                    for (int j = 0; j < oDataTable.Rows.Count; j++)
                    {
                        SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

                        try
                        {
                            lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();
                            //string ugpEntry = oDataTable.GetValue("UgpEntry", j).ToString();
                            string packUnit = oDataTable.GetValue(matrixPackUnitColumnUDF, j).ToString();
                            string stockUnit = oDataTable.GetValue(matrixStockUnitColumnUDF, j).ToString();
                            string perUnitConvValue = oDataTable.GetValue(matrixNumPerMsColumnUDF, j).ToString();
                            double dblPerUnitConvValue = perUnitConvValue == string.Empty ? 1 : double.Parse(perUnitConvValue);

                            #region Setting Production Order Headers

                            //wo.Series = Int32.Parse(oDataTable_Items.GetValue("Series", 0).ToString());
                            wo.StartDate = DateTime.Parse(oDataTable.GetValue(matrixStartDateColumnUDF, j).ToString());
                            wo.DueDate = DateTime.Parse(oDataTable.GetValue(matrixEndDateColumnUDF, j).ToString());
                            wo.PostingDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, j).ToString().Trim());

                            wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotStandard;
                            wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                            wo.ItemNo = oDataTable.GetValue(matrixProductCodeColumnUDF, j).ToString().Trim();
                            //wo.Warehouse = oDataTable.GetValue(matrixWhsCodeColumnUDF, j).ToString().Trim();
                            wo.PlannedQuantity = dblPerUnitConvValue * double.Parse(oDataTable.GetValue(matrixPackQtyColumnUDF, j).ToString().Trim());
                            wo.ProductionOrderOriginEntry = Int32.Parse(oDataTable.GetValue(matrixAdviceDocEntryColumnUDF, j).ToString().Trim());
                            wo.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder;
                            wo.UserFields.Fields.Item("U_DailyProdPlan").Value = oDataTable.GetValue("DocNum", 0).ToString().Trim();
                            wo.UserFields.Fields.Item(fatherDocEntryUDF).Value = fatherDocEntry;
                            wo.UserFields.Fields.Item(fatherDocNumUDF).Value = fatherDocNum;

                            #endregion

                            int retVal = wo.Add();
                            if (retVal != 0)
                            {
                                oApplication.StatusBar.SetText("For Priority : " + lineId + " Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                            else
                            {
                                string PODocEntry = oCompany.GetNewObjectKey();
                                string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWOR WHERE \"DocEntry\" = '" + PODocEntry + "'");

                                oApplication.StatusBar.SetText("SF Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            }

                        }
                        catch (Exception ex)
                        {
                            SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                            oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        }
                        finally
                        {

                        }
                    }
                    oRsItems.MoveNext();
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                if (oRsItems != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsItems);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        private void Create_GoodsIssue_Reject(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.\"LineId\",T1.\"" + matrixPOEnColumnUDF + "\",T1.\"" + matrixPONoColumnUDF + "\",T0.\"U_DocDate\",T1.\"" + matrixProductCodeColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRejectedQuantityColumnUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixRewindBatchColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRewindShiftColumnUDF + "\",T1.\"" + matrixRewindWhsCodeColumnUDF + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixRewindIssueEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixRewindIssueEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create goods issue. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create Goods Issue?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit);
                    oDocument.Reference2 = oDataTable.GetValue(matrixPONoColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherDocEntryUDF).Value = oDataTable.GetValue(matrixPOEnColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherDocNumUDF).Value = oDataTable.GetValue(matrixPONoColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherObjectUDF).Value = "202";
                    try
                    {
                        lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();

                        oDocument.DocDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, 0).ToString());
                        oDocument.BPL_IDAssignedToInvoice = 1;
                        oDocument.Lines.ItemCode = oDataTable.GetValue(matrixProductCodeColumnUDF, 0).ToString();
                        oDocument.Lines.Quantity = double.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                        oDocument.Lines.WarehouseCode = oDataTable.GetValue(matrixRewindWhsCodeColumnUDF, 0).ToString();

                        string manBatch = oDataTable.GetValue(CommonFields.ManBtchNum, 0).ToString();
                        if (manBatch == "Y")
                        {
                            oDocument.Lines.SetCurrentLine(0);
                            oDocument.Lines.BatchNumbers.BatchNumber = oDataTable.GetValue(matrixRewindBatchColumnUDF, 0).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            oDocument.Lines.BatchNumbers.Quantity = double.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                            oDocument.Lines.BatchNumbers.ManufacturerSerialNumber = oDataTable.GetValue(matrixRewindShiftColumnUDF, 0).ToString(); ; //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));

                            oDocument.Lines.BatchNumbers.Add();
                        }
                        int retVal = oDocument.Add();
                        if (retVal != 0)
                        {
                            oApplication.StatusBar.SetText("For Priority : " + lineId + " Issue Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            sbMessage.Append(oCompany.GetLastErrorDescription());
                            sbMessage.Append(Environment.NewLine);
                        }
                        else
                        {
                            string PODocEntry = oCompany.GetNewObjectKey();
                            string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGE WHERE \"DocEntry\" = '" + PODocEntry + "'");
                            objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixRewindIssueEnColumnUDF + "\" = '" + PODocEntry + "',\"" + matrixRewindIssueNoColumnUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"LineId\" = '" + lineId + "'");
                            oApplication.StatusBar.SetText("Issue No" + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {

                    }
                }

                //if (sbMessage.Length != 0)
                //{
                //    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                //}
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void Create_GoodsReceipt_Reject_PartialAuto(string DocEntry, string lineId)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"DocEntry\",T1.\"LineId\",T1.\"" + matrixPOEnColumnUDF + "\",T1.\"" + matrixPONoColumnUDF + "\",T0.\"U_DocDate\",T1.\"" + matrixProductCodeColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRejectedQuantityColumnUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixRewindBatchColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRewindShiftColumnUDF + "\",T1.\"" + matrixRewindWhsCodeColumnUDF + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"LineId\" = '" + lineId + "'");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create goods receipt. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create Goods Receipt?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }
                clsVariables.BaseEntry = oRs.Fields.Item("DocEntry").Value.ToString();
                clsVariables.BaseLine = oRs.Fields.Item("LineId").Value.ToString();
                clsVariables.BaseItemCode = oRs.Fields.Item(matrixProductCodeColumnUDF).Value.ToString();
                clsVariables.BaseObjectType = objType;

                clsVariables.boolNewFormOpen = true;
                oApplication.ActivateMenuItem("3078");
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
                objclsComman.ReleaseObject(oDataTable);

                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
            }
        }

        private void Create_GoodsIssue_Reject_PartialAuto(string DocEntry, string lineId)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo1";
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"DocEntry\",T1.\"LineId\",T1.\"" + matrixPOEnColumnUDF + "\",T1.\"" + matrixPONoColumnUDF + "\",T0.\"U_DocDate\",T1.\"" + matrixProductCodeColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRejectedQuantityColumnUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixRewindBatchColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRewindShiftColumnUDF + "\",T1.\"" + matrixRewindWhsCodeColumnUDF + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"LineId\" = '" + lineId + "'");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixRewindIssueEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixRewindIssueEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create goods issue. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create Goods Issue?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }
                clsVariables.BaseEntry = oRs.Fields.Item("DocEntry").Value.ToString();
                clsVariables.BaseLine = oRs.Fields.Item("LineId").Value.ToString();
                clsVariables.BaseItemCode = oRs.Fields.Item(matrixProductCodeColumnUDF).Value.ToString();
                clsVariables.BaseObjectType = objType;

                clsVariables.boolNewFormOpen = true;
                oApplication.ActivateMenuItem("3079");
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void Create_GoodsReceipt_Reject_Auto(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.\"LineId\",T1.\"" + matrixPOEnColumnUDF + "\",T1.\"" + matrixPONoColumnUDF + "\",T0.\"U_DocDate\",T1.\"" + matrixProductCodeColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRejectedQuantityColumnUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixRewindBatchColumnUDF + "\", ");
            sbQuery.Append(" T1.\"" + matrixRewindShiftColumnUDF + "\",T1.\"" + matrixRewindWhsCodeColumnUDF + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create goods receipt. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create Goods Receipt?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);
                    oDocument.Reference2 = oDataTable.GetValue(matrixPONoColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherDocEntryUDF).Value = oDataTable.GetValue(matrixPOEnColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherDocNumUDF).Value = oDataTable.GetValue(matrixPONoColumnUDF, 0).ToString();
                    oDocument.UserFields.Fields.Item(fatherObjectUDF).Value = "202";

                    try
                    {
                        lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();

                        oDocument.DocDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, 0).ToString());
                        oDocument.BPL_IDAssignedToInvoice = 1;
                        //oDocument.Lines.BaseType = 202;
                        oDocument.Lines.ItemCode = oDataTable.GetValue(matrixProductCodeColumnUDF, 0).ToString();
                        oDocument.Lines.Quantity = double.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                        oDocument.Lines.WarehouseCode = oDataTable.GetValue(matrixRewindWhsCodeColumnUDF, 0).ToString();

                        //oDocument.Lines.BaseEntry = Int32.Parse(oDataTable.GetValue(matrixPOEnColumnUDF, 0).ToString());
                        //oDocument.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntReject;

                        string manBatch = oDataTable.GetValue(CommonFields.ManBtchNum, 0).ToString();
                        if (manBatch == "Y")
                        {
                            oDocument.Lines.SetCurrentLine(0);
                            oDocument.Lines.BatchNumbers.BatchNumber = oDataTable.GetValue(matrixRewindBatchColumnUDF, 0).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            oDocument.Lines.BatchNumbers.Quantity = double.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                            oDocument.Lines.BatchNumbers.ManufacturerSerialNumber = oDataTable.GetValue(matrixRewindShiftColumnUDF, 0).ToString(); ; //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));

                            oDocument.Lines.BatchNumbers.Add();
                        }
                        int retVal = oDocument.Add();
                        if (retVal != 0)
                        {
                            oApplication.StatusBar.SetText("For Priority : " + lineId + " Receipt Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            sbMessage.Append(oCompany.GetLastErrorDescription());
                            sbMessage.Append(Environment.NewLine);
                        }
                        else
                        {
                            string PODocEntry = oCompany.GetNewObjectKey();
                            string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + PODocEntry + "'");
                            objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixRewindReceiptEnColumnUDF + "\" = '" + PODocEntry + "',\"" + matrixRewindReceiptNoColumnUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"LineId\" = '" + lineId + "'");
                            oApplication.StatusBar.SetText("Receipt No" + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {

                    }
                }

                //if (sbMessage.Length != 0)
                //{
                //    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                //}
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void Create_ReceiptFromProduction_Reject(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "OrdNo";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.\"LineId\",T1.\"" + matrixPOEnColumnUDF + "\",T0.\"U_DocDate\", ");
            sbQuery.Append(" T1.\"" + matrixRejectedQuantityColumnUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixRewindBatchColumnUDF + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckColumnUDF + "\" ='Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T1.\"" + matrixRewindReceiptEnColumnUDF + "\",'') = '' ");
            }


            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    //oApplication.StatusBar.SetText(sbQuery.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    oApplication.MessageBox(" No Receipt order found to create. ", 1, "Ok", "", "");
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to create Receipt from Production?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);

                    try
                    {
                        lineId = oDataTable.GetValue(CommonFields.LineId, j).ToString();

                        oDocument.DocDate = DateTime.Parse(oDataTable.GetValue(planDateUDF, 0).ToString());
                        oDocument.BPL_IDAssignedToInvoice = 1;
                        oDocument.Lines.BaseType = 202;
                        oDocument.Lines.Quantity = Int32.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                        oDocument.Lines.BaseEntry = Int32.Parse(oDataTable.GetValue(matrixPOEnColumnUDF, 0).ToString());
                        oDocument.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntReject;

                        string manBatch = oDataTable.GetValue(CommonFields.ManBtchNum, 0).ToString();
                        if (manBatch == "Y")
                        {
                            oDocument.Lines.SetCurrentLine(0);
                            oDocument.Lines.BatchNumbers.BatchNumber = oDataTable.GetValue(matrixRewindBatchColumnUDF, 0).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            oDocument.Lines.BatchNumbers.Quantity = Int32.Parse(oDataTable.GetValue(matrixRejectedQuantityColumnUDF, 0).ToString());
                            oDocument.Lines.BatchNumbers.Add();
                        }
                        int retVal = oDocument.Add();
                        if (retVal != 0)
                        {
                            oApplication.StatusBar.SetText("For Priority : " + lineId + " Receipt Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            sbMessage.Append(oCompany.GetLastErrorDescription());
                            sbMessage.Append(Environment.NewLine);
                        }
                        else
                        {
                            string PODocEntry = oCompany.GetNewObjectKey();
                            string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + PODocEntry + "'");
                            objclsComman.SelectRecord("UPDATE T0 SET \"" + matrixRewindReceiptEnColumnUDF + "\" = '" + PODocEntry + "',\"" + matrixRewindReceiptNoColumnUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"LineId\" = '" + lineId + "'");
                            oApplication.StatusBar.SetText("Receipt No" + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {

                    }
                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void SetLineId(SAPbouiCOM.Matrix oMatrix)
        {
            int rowNo = 1;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                oDbDataSource.SetValue(CommonFields.LineId, i, rowNo.ToString());
                rowNo = rowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableRow(SAPbouiCOM.Matrix oMatrix)
        {
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                if (oDbDataSource.GetValue(matrixPOEnColumnUDF, i) != string.Empty)
                {
                    oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixAdviceNoColumnUID), false);
                    oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixProductCodeColumnUID), false);
                    //oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixQuantityColumnUID), false);
                }
                else
                {
                    oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixAdviceNoColumnUID), true);
                    oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixProductCodeColumnUID), true);
                    //oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixQuantityColumnUID), true);
                    //if (oDbDataSource.GetValue(matrixBPOEnUDF, i) != string.Empty)
                    //{
                    //    oMatrix.CommonSetting.SetCellEditable(i + 1, objclsComman.GetMatrixColumnIndex(oMatrix, matrixQuantityColumnUID), false);
                    //}
                }
            }
        }

        #endregion
    }
}
