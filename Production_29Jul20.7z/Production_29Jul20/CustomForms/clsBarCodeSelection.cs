using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;

namespace Production
{
    class clsBarCodeSelection : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string formTypeEx = "BARCODESEL";
        const string formMenuUID = "BARCODESEL";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string rowNoUID = "RowNo";

        const string jbDocEntryUDF = "U_JBEn";
        const string productCodeUDF = "U_PrdCode";

        const string buttonSelect = "btnSelect";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonSelect)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsItemEntity> list = new List<clsItemEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y")
                                    {
                                        list.Add(new clsItemEntity()
                                        {
                                            BarCode = oDT.GetValue("BarCode", i),
                                            GrossWt = oDT.GetValue("Gross Weight", i).ToString(),
                                            TareWt = oDT.GetValue("Tare Weight", i).ToString(),
                                            NetWt = oDT.GetValue("Net Weight", i).ToString(),
                                            Qty = oDT.GetValue("Qty", i).ToString(),
                                            Batch = oDT.GetValue("Batch", i),
                                            Shift = oDT.GetValue("Shift", i),
                                            PackUnit = oDT.GetValue("Pack Unit", i),
                                            UOMQty = oDT.GetValue("UOM Base Qty", i).ToString(),
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                string itemCode = oForm.DataSources.UserDataSources.Item(CommonFields.ItemCode).Value.ToString();
                                //sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT \"U_TareWgt\",\"U_Gr_Wt\"");
                                //sbQuery.Append(" FROM " + CommonTables.ItemMasterData + " T0");
                                //sbQuery.Append(" WHERE \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //string tareWt = oRs.Fields.Item("U_TareWgt").Value.ToString();
                                //string grWt = oRs.Fields.Item("U_Gr_Wt").Value.ToString();


                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("mtx").Specific;
                                oBaseMatrix.FlushToDataSource();

                                #region Weighing Scale

                                if (clsWeighingScale.formTypeEx == clsVariables.BaseFormTypeEx)
                                {
                                    oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsWeighingScale.rowTable);
                                    for (int i = 0; i < list.Count; i++)
                                    {
                                        oDBDataSource.SetValue("LineId", rowNo - 1, rowNo.ToString());
                                        oDBDataSource.SetValue("U_BarCode", rowNo - 1, list[i].BarCode);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixGrossWtUDF, rowNo - 1, list[i].GrossWt);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixTareWtUDF, rowNo - 1, list[i].TareWt);
                                        //oDBDataSource.SetValue(clsWeighingScale.matrixNetWtUDF, rowNo - 1, list[i].NetWt);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixPackUnitUDF, rowNo - 1, list[i].PackUnit);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixUOMBaseQtyUDF, rowNo - 1, list[i].UOMQty);
                                        if (list[i].PackUnit.Trim().ToLower() == "kgs")
                                        {

                                        }
                                        oDBDataSource.InsertRecord(rowNo);
                                        rowNo++;
                                    }

                                    rowNo = 1;
                                    for (int i = 0; i < oDBDataSource.Size; i++)
                                    {
                                        string value = oDBDataSource.GetValue(clsWeighingScale.matrixReceiptEntryUDF, i).ToString().Trim();
                                        oDBDataSource.SetValue(CommonFields.LineId, i, rowNo.ToString());
                                        rowNo = rowNo + 1;
                                    }
                                }
                                #endregion

                                #region Weighing Scale QC

                                else if (clsWeighingScaleQC.formTypeEx == clsVariables.BaseFormTypeEx)
                                {
                                    string recNo = "";
                                    string recEn = "";
                                    string qcEn = "";
                                    string fromWhs = "";

                                    oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsWeighingScaleQC.rowTable);
                                    for (int i = 0; i < list.Count; i++)
                                    {
                                        if (i == 0)
                                        {
                                            recNo = oDBDataSource.GetValue("U_RecNo", rowNo - 1);
                                            recEn = oDBDataSource.GetValue("U_RecEn", rowNo - 1);
                                            qcEn = oDBDataSource.GetValue("U_QCEn", rowNo - 1);
                                            fromWhs = oDBDataSource.GetValue("U_WhsCode", rowNo - 1);
                                        }
                                        oDBDataSource.SetValue("LineId", rowNo - 1, rowNo.ToString());
                                        oDBDataSource.SetValue("U_BarCode", rowNo - 1, list[i].BarCode);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixGrossWtUDF, rowNo - 1, list[i].GrossWt);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixTareWtUDF, rowNo - 1, list[i].TareWt);
                                        oDBDataSource.SetValue(clsWeighingScale.matrixNetWtUDF, rowNo - 1, list[i].NetWt);
                                        oDBDataSource.SetValue(clsWeighingScaleQC.matrixPackQtyUDF, rowNo - 1, list[i].Qty);
                                        oDBDataSource.SetValue(clsWeighingScaleQC.matrixBatchUDF, rowNo - 1, list[i].Batch);
                                        oDBDataSource.SetValue(clsWeighingScaleQC.matrixShiftUDF, rowNo - 1, list[i].Shift);
                                        oDBDataSource.SetValue(clsWeighingScaleQC.matrixPackUnitUDF, rowNo - 1, list[i].PackUnit);
                                        oDBDataSource.SetValue(clsWeighingScaleQC.matrixUOMBaseQtyUDF, rowNo - 1, list[i].UOMQty);

                                        oDBDataSource.SetValue("U_RecNo", rowNo - 1, recNo);
                                        oDBDataSource.SetValue("U_RecEn", rowNo - 1, recEn);
                                        oDBDataSource.SetValue("U_QCEn", rowNo - 1, qcEn);
                                        oDBDataSource.SetValue("U_WhsCode", rowNo - 1, fromWhs);

                                        oDBDataSource.InsertRecord(rowNo);
                                        rowNo++;
                                    }
                                    rowNo = 1;
                                    for (int i = 0; i < oDBDataSource.Size; i++)
                                    {
                                        string value = oDBDataSource.GetValue(clsWeighingScaleQC.matrixReceiptNoUDF, i).ToString().Trim();
                                        if (value == string.Empty)
                                        {
                                            oDBDataSource.RemoveRecord(i);
                                        }
                                        oDBDataSource.SetValue(CommonFields.LineId, i, rowNo.ToString());
                                        rowNo = rowNo + 1;
                                    }
                                }
                                #endregion

                                oBaseMatrix.LoadFromDataSource();
                                if (oBaseForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oBaseForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string rowNo, string jbDocEntry, string productCode,string qcType)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add("RowNo", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(rowNoUID).Specific;
            oEdit.DataBind.SetBound(true, "", rowNoUID);
            oEdit.String = rowNo;

            oForm.DataSources.UserDataSources.Add(CommonFields.ItemCode, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.ItemCode).Specific;
            oEdit.DataBind.SetBound(true, "", CommonFields.ItemCode);
            oEdit.String = productCode;
            FillGrid(jbDocEntry, productCode, qcType);
        }

        public void FillGrid(string jbDocEntry, string productCode,string qcType)
        {
            oForm = oApplication.Forms.ActiveForm;

            sbQuery.Length = 0;
            if (clsVariables.BaseFormTypeEx == clsWeighingScale.formTypeEx)
            {
                sbQuery.Append(" SELECT 'N' \"Select\" ,ROW_NUMBER() OVER (ORDER BY \"U_BarCode\") RowNo,\"U_BarCode\" AS \"BarCode\", T2.\"U_TareWgt\" AS \"Tare Weight\",T2.\"U_Gr_Wt\" AS \"Gross Weight\",'' \"Batch\",'' \"Shift\" ");
                sbQuery.Append(" , '0' AS \"Net Weight\" , '0' AS \"Qty\"  ");
                sbQuery.Append(" , T2.\"" + CommonFields.InvntryUom + "\" AS \"Pack Unit\" , T4.\"BaseQty\" AS \"UOM Base Qty\"  ");

                sbQuery.Append(" FROM \"" + clsBarCodeAssignment.headerTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + clsBarCodeAssignment.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T2 ON T0.\"" + productCodeUDF + "\" = T2.\"" + CommonFields.ItemCode + "\" ");
                sbQuery.Append(" LEFT JOIN \"OUOM\" T3 ON T2.\"" + CommonFields.InvntryUom + "\" = T3.\"" + CommonFields.UomCode + "\" ");
                sbQuery.Append(" LEFT JOIN \"UGP1\" T4 ON T3.\"" + CommonFields.UomEntry + "\" = T4.\"" + CommonFields.UomEntry + "\" AND T2.\"" + CommonFields.UgpEntry + "\" = T4.\"" + CommonFields.UgpEntry + "\"  ");
                sbQuery.Append(" WHERE T0.\"" + jbDocEntryUDF + "\" = '" + jbDocEntry + "' AND T0.\"" + productCodeUDF + "\" = '" + productCode + "' ");
                sbQuery.Append(" AND IFNULL(T1.\"U_IsUsed\",'N') = 'N' ");

                //sbQuery.Append(" AND NOT EXISTS( ");
                //sbQuery.Append(" SELECT 1 FROM \"" + clsWeighingScale.headerTable + "\" IT0 ");
                //sbQuery.Append(" INNER JOIN \"" + clsWeighingScale.rowTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\"  ");
                //sbQuery.Append(" WHERE  T1.\"U_BarCode\" = IT1.\"U_BarCode\" AND T0.\"" + jbDocEntryUDF + "\" = IT0.\"" + jbDocEntryUDF + "\" AND T0.\"" + productCodeUDF + "\" = IT0.\"" + productCodeUDF + "\" ) ");
            }
            else if (clsVariables.BaseFormTypeEx == clsWeighingScaleQC.formTypeEx)
            {
                if (qcType == "N")
                {
                    sbQuery.Append(" SELECT 'N' \"Select\" ,ROW_NUMBER() OVER (ORDER BY \"U_BarCode\") RowNo,\"U_BarCode\" AS \"BarCode\", T1.\"" + clsWeighingScale.matrixTareWtUDF + "\" AS \"Tare Weight\",T1.\"" + clsWeighingScale.matrixGrossWtUDF + "\" AS \"Gross Weight\" ,T0.\"U_Batch\" AS \"Batch\",T0.\"" + clsWeighingScale.shiftUDF + "\" AS \"Shift\" ");
                    sbQuery.Append(" , T1.\"" + clsWeighingScale.matrixNetWtUDF + "\" AS \"Net Weight\" , T1.\"" + clsWeighingScale.matrixQtyUDF + "\" AS \"Qty\"  ");
                    sbQuery.Append(" , T1.\"" + clsWeighingScale.matrixPackUnitUDF + "\" AS \"Pack Unit\" , T1.\"" + clsWeighingScale.matrixUOMBaseQtyUDF + "\" AS \"UOM Base Qty\"  ");

                    sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN \"" + clsWeighingScale.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                    sbQuery.Append(" WHERE T1.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\" = '" + jbDocEntry + "'  ");
                    sbQuery.Append(" AND IFNULL(T1.\"U_IsUsed\",'N') = 'N' ");
                    //sbQuery.Append(" AND NOT EXISTS( ");
                    //sbQuery.Append(" SELECT 1 FROM \"" + clsWeighingScaleQC.headerTable + "\" IT0 ");
                    //sbQuery.Append(" INNER JOIN \"" + clsWeighingScaleQC.rowTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\"  ");

                    //sbQuery.Append(" WHERE T1.\"U_BarCode\" = IT1.\"U_BarCode\" AND T1.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\" = IT1.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\"  ) ");
                }
                else
                {
                    sbQuery.Append(" SELECT 'N' \"Select\" ,ROW_NUMBER() OVER (ORDER BY \"U_BarCode\") RowNo,\"U_BarCode\" AS \"BarCode\", T1.\"" + clsWeighingScale.matrixTareWtUDF + "\" AS \"Tare Weight\",T1.\"" + clsWeighingScale.matrixGrossWtUDF + "\" AS \"Gross Weight\" ,T1.\"U_Batch\" AS \"Batch\",T0.\"" + clsWeighingScale.shiftUDF + "\" AS \"Shift\" ");
                    sbQuery.Append(" , T1.\"" + clsWeighingScaleQC.matrixNetWtUDF + "\" AS \"Net Weight\" , T1.\"" + clsWeighingScaleQC.matrixPackQtyUDF + "\" AS \"Qty\"  ");
                    sbQuery.Append(" , T1.\"" + clsWeighingScaleQC.matrixPackUnitUDF + "\" AS \"Pack Unit\" , T1.\"" + clsWeighingScaleQC.matrixUOMBaseQtyUDF + "\" AS \"UOM Base Qty\"  ");
                    sbQuery.Append(" FROM \"" + clsWeighingScaleQC.headerTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN \"" + clsWeighingScaleQC.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                    sbQuery.Append(" WHERE T1.\"" + clsWeighingScaleQC.matrixReceiptEntryUDF + "\" = '" + jbDocEntry + "'  ");
                    sbQuery.Append(" AND IFNULL(T1.\"U_IsRetest\",'N') = 'N' AND IFNULL(T1.\"U_QCStatus\",'') = 'P'  ");
                }
            }

            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
            }
            oGrid.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

        #endregion
    }
}
