using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsBOMMaster : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        const string formTypeEx = "BOMMASTER";
        public const string formMenuUID = "BOMMASTER";
        public const string objType = "BOMMASTER";
        const string matrixUID = "mtx";

        public const string headerTable = "@BOMMASTER";
        public const string rowTable = "@BOMMASTER1";

        const string CFL_DIST = "CFL_DIST";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_WHS = "CFL_WHS";
        const string CFL_MAC = "CFL_MAC";
        const string CFL_RITEM = "CFL_RITEM";
        const string CFL_RWHS = "CFL_RWHS";
        const string CFL_UOM = "CFL_UOM";
        const string CFL_RES = "CFL_RES";

        const string matrixPrimaryColumnUDF = "U_CompPrdC";
        const string matrixPrimaryColumnUID = "V_7";

        public const string productCodeUDF = "U_PrdCode";
        const string productCodeUID = "PrdCode";
        const string productNameUDF = "U_PrdName";
        public const string machineCodeUDF = "U_MacCode";
        public const string machineCodeUID = "MacCode";
        public const string machineNameUDF = "U_MacName";
        public const string ProcessUDF = "U_Process";
        const string ProcessUID = "Process";
        public const string whsCodeUDF = "U_WhsCode";
        public const string distRuleUDF = "U_DistRule";
        public const string quantityUDF = "U_Qty";


        public const string matrixProductCodeColumnUDF = "U_CompPrdC";
        const string matrixProductCodeColumnUID = "V_7";
        const string matrixProductNameColumnUDF = "U_CompPrdN";
        public const string matrixWhsCodeColumnUDF = "U_CompWhs";
        public const string matrixQuantityColumnUDF = "U_CompQty";

        const string matrixWhsCodeColumnUID = "V_3";
        public const string matrixUOMColumnUDF = "U_UOM";
        const string matrixUOMMColumnUID = "V_4";

        const string matrixTypeUID = "V_9";
        const string matrixTypeUDF = "U_Type";


        const string matrixLayerUID = "V_13";
        const string matrixLayerUDF = "U_Layer";


        const string matrixIssueMethodUDF = "U_IssMeth";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string prdCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();
                                    string headerQuantity = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(quantityUDF, 0).Trim();
                                    string process = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(ProcessUDF, 0).Trim();
                                    string macCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).Trim();
                                    string whsCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(whsCodeUDF, 0).Trim();
                                    string distRule = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(distRuleUDF, 0).Trim();

                                    double dblHeaderQuantity = headerQuantity == string.Empty ? 0 : double.Parse(headerQuantity);
                                    if (prdCode == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Product code is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (dblHeaderQuantity == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Header quantity is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (process == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Process is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (macCode == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Machine code is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (whsCode == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Warehouse code is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (distRule == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Distribution rule is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    string value = "";
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        string itemCode = oDbDataSource.GetValue(matrixProductCodeColumnUDF, i).ToString().Trim();
                                        if (itemCode != string.Empty)
                                        {
                                            if (prdCode == itemCode)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Header itemcode and child itemcode should not be same. For row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            double qty = double.Parse(oDbDataSource.GetValue(matrixQuantityColumnUDF, i).Trim());
                                            if (qty == 0)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Child item Quantity should be greater than 0. For row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            whsCode = oDbDataSource.GetValue(matrixWhsCodeColumnUDF, i).ToString().Trim();
                                            if (whsCode == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Warehouse code is mandatory. For row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            string issMethod = oDbDataSource.GetValue(matrixIssueMethodUDF, i).ToString().Trim();
                                            if (issMethod == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Issue method is mandatory. For row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                        }
                                    }
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT 1 ");
                                        sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                                        sbQuery.Append(" WHERE \"" + productCodeUDF + "\" ='" + prdCode + "' AND \"" + machineCodeUDF + "\" ='" + macCode + "'   ");
                                        value = objclsComman.SelectRecord(sbQuery.ToString());
                                        if (value == "1")
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Combination of Product code and machine code already exist", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == matrixUID)
                            {
                                SAPbouiCOM.Column oColumn;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                if (pVal.ColUID == matrixProductCodeColumnUID)
                                {
                                    string type = oDbDataSource.GetValue(matrixTypeUDF, pVal.Row - 1);
                                    oColumn = oMatrix.Columns.Item(matrixProductCodeColumnUID);

                                    if (type == "4")
                                    {
                                        oColumn.ChooseFromListUID = CFL_RITEM;
                                        oColumn.ChooseFromListAlias = CommonFields.ItemCode;
                                    }
                                    else if (type == "290")
                                    {
                                        oColumn.ChooseFromListUID = CFL_RES;
                                        oColumn.ChooseFromListAlias = CommonFields.ResCode;
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_WHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(whsCodeUDF, 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_DIST)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(distRuleUDF, 0, oDataTable.GetValue(CommonFields.OcrCode, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(matrixProductNameColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue(matrixUOMColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.InvntryUom, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    oDbDataSource.SetValue(matrixTypeUDF, pVal.Row, "4");
                                    oDbDataSource.SetValue(matrixIssueMethodUDF, pVal.Row, "M");

                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixProductCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RES)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ResCode, 0).ToString());
                                oDbDataSource.SetValue(matrixProductNameColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ResName, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixProductCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RWHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixWhsCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixWhsCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_UOM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixUOMColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.UomCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixUOMMColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Code, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemChanged == true)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                if (pVal.ItemUID == matrixUID)
                                {
                                    if (pVal.ColUID == matrixTypeUID)
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                        oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, string.Empty);
                                        oDbDataSource.SetValue(matrixProductNameColumnUDF, pVal.Row - 1, string.Empty);
                                        oMatrix.LoadFromDataSource();
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        int i = oApplication.MessageBox("Do you really want to remove line?", 1, "Yes", "No", "");
                        if (i == 2)
                        {
                            BubbleEvent = false;
                            return;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.RemoveRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        int i = oApplication.MessageBox("Do you really want to remove record?", 1, "Yes", "No", "");
                        if (i == 2)
                        {
                            BubbleEvent = false;
                            return;
                        }
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID, rowTable, matrixProductCodeColumnUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixProductCodeColumnUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Code, 0);

                        objclsComman.SelectRecord("UPDATE T0 SET \"U_TreeType\" ='P' FROM \"" + CommonTables.ItemMasterData + "\" T0 INNER JOIN \"" + headerTable + "\" T1 ON T0.\"" + CommonFields.ItemCode + "\" = T1.\"" + productCodeUDF + "\" WHERE  T1.\"Code\" = '" + docEntry + "'");

                        objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixPrimaryColumnUDF + "\",'')='' AND \"Code\" = '" + docEntry + "'");
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            clsVariables.boolCFLSelected = false;
            if (MenuID == formMenuUID)
            {
                objclsComman.LoadXML(MenuID, "Code", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.RemoveRecord), true);

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(ProcessUID).Specific;
                objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@PROCESSMASTER\" ");

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                oMatrix.CommonSetting.EnableArrowKey = true;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixTypeUID, 1);
                objclsComman.FillCombo_UDF(oCombo, rowTable, matrixTypeUDF.Replace("U_", ""));
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixLayerUID, 1);
                objclsComman.FillCombo_UDF(oCombo, rowTable, matrixLayerUDF.Replace("U_", ""));
            }
            oForm = oApplication.Forms.ActiveForm;

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            oDbDataSource.SetValue(matrixTypeUDF, oMatrix.VisualRowCount - 1, "4");
            oDbDataSource.SetValue(matrixIssueMethodUDF, oMatrix.VisualRowCount - 1, "M");
            oMatrix.LoadFromDataSource();
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.Code, 0, objclsComman.AutoNoMasterTable(headerTable));
            oForm.Items.Item(CommonFields.Code).EnableinFindMode();
            oForm.Items.Item(productCodeUID).EnableinAddMode();
            oForm.Items.Item(machineCodeUID).EnableinAddMode();
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDbDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            //objclsComman.AddRow(oMatrix, oDBDataSource, value);
            if (value != string.Empty)
            {
                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
            }
            oDbDataSource.SetValue(matrixTypeUDF, oMatrix.VisualRowCount, "4");
            oDbDataSource.SetValue(matrixIssueMethodUDF, oMatrix.VisualRowCount, "M");
            oMatrix.LoadFromDataSource();

        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        #endregion
    }
}
