using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;

namespace Production
{
    class clsDailyPlanSOSelection : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string formTypeEx = "DAILYPLANSO";
        const string formMenuUID = "DAILYPLANSO";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string rowNoUID = "RowNo";
        const string searchUID = "Search";

        const string buttonSearch = "btnSearch";

        const string buttonChoose = "btnChoose";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonSearch)
                            {
                                FillGrid();
                            }
                            #endregion

                            #region Select
                            else if (pVal.ItemUID == buttonChoose)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string soDocEntry = string.Empty;
                                string soDocNum = string.Empty;
                                string soDocDate = string.Empty;
                                string soItemCode = string.Empty;
                                string soQuantity = string.Empty;

                                List<string> list = new List<string>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Chk", i) == "Y")
                                    {
                                        list.Add(i.ToString());
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (list.Count > 1)
                                {
                                    oApplication.StatusBar.SetText("Please select only 1 row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString()) - 1;

                                int j = int.Parse(list[0].ToString());
                                soDocEntry = oDT.GetValue("DocEntry", j).ToString();
                                soDocNum = oDT.GetValue("DocNum", j).ToString();
                                soDocDate = oDT.GetValue("DocDate", j).ToString();
                                soItemCode = oDT.GetValue("ItemCode", j).ToString();
                                soQuantity = oDT.GetValue("Quantity", j).ToString();

                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("mtx").Specific;
                                oBaseMatrix.FlushToDataSource();
                                oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsDailyPlan.rowTable);
                                oDBDataSource.SetValue(clsDailyPlan.matrixAdviceDocEntryColumnUDF, rowNo, soDocEntry);
                                oDBDataSource.SetValue(clsDailyPlan.matrixAdviceNoColumnUDF, rowNo, soDocNum);
                                oDBDataSource.SetValue(clsDailyPlan.matrixAdviceItemCodeColumnUDF, rowNo, soItemCode);
                                oDBDataSource.SetValue(clsDailyPlan.matrixAdviceQuantityColumnUDF, rowNo, soQuantity);

                                try
                                {
                                    DateTime docDate = DateTime.Parse(soDocDate);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixAdviceDateColumnUDF, rowNo, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                }
                                catch { }
                                oBaseMatrix.LoadFromDataSource();
                                if (oBaseForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oBaseForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string rowNo)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add(rowNoUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(rowNoUID).Specific;
            oEdit.DataBind.SetBound(true, "", rowNoUID);
            oEdit.String = rowNo;

            oForm.DataSources.UserDataSources.Add(searchUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(searchUID).Specific;
            oEdit.DataBind.SetBound(true, "", searchUID);
            FillGrid();
        }

        private void FillGrid()
        {
            oForm = oApplication.Forms.ActiveForm;
            string searchText = oForm.DataSources.UserDataSources.Item(searchUID).ValueEx;
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT 'N' \"Chk\",T0.\"" + CommonFields.DocEntry + "\",T0.\"" + CommonFields.DocNum + "\",T0.\"" + CommonFields.DocDate + "\" ");
            sbQuery.Append(" ,T1.\"" + CommonFields.ItemCode + "\",T1.\"" + CommonFields.Dscription + "\",T1.\"" + CommonFields.Quantity + "\" ");
            sbQuery.Append(" FROM \"ORDR\" T0 ");
            sbQuery.Append(" INNER JOIN \"RDR1\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
            sbQuery.Append(" INNER JOIN \"NNM1\" T2 ON T0.\"" + CommonFields.Series + "\" = T2.\"" + CommonFields.Series + "\" ");
            sbQuery.Append(" WHERE T2.\"SeriesName\" LIKE '%OC%' ");
            sbQuery.Append(" AND (T0.\"" + CommonFields.DocNum + "\" LIKE '%" + searchText + "%' ");
            sbQuery.Append(" OR T1.\"" + CommonFields.ItemCode + "\" LIKE '%" + searchText + "%' ");
            sbQuery.Append(" OR T1.\"" + CommonFields.Dscription + "\" LIKE '%" + searchText + "%' ");
            sbQuery.Append(" ) ");

            sbQuery.Append(" ORDER BY T0.\"" + CommonFields.DocEntry + "\"  ");

            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
                oGrid.Columns.Item(i).Editable = false;
            }

            oGrid.Columns.Item("Chk").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

        #endregion
    }
}
