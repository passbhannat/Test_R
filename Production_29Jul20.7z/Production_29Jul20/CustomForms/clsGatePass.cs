using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsGatePass : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "GATEPASS";
        const string formMenuUID = "GATEPASS";
        const string objType = "GATEPASS";
        const string headerTable = "@GATEPASS";
        const string rowTable = "@GATEPASS1";

        const string CFL_VEH = "CFL_VEH";
        const string CFL_CARD = "CFL_CARD";
        const string CFL_INV = "CFL_INV";

        const string vehicleNoUDF = "U_VehcNo";
        const string vehicleNoUID = "VehcNo";
        const string driverNameUDF = "U_DriName";

        const string docDateUDF = "U_DocDate";
        const string mtrReadStartUDF = "U_TLODOMtr";
        const string mtrReadEndUDF = "U_TAODOMtr";
        const string KMTravelUDF = "U_KMTravel";

        const string mtrReadStartUID = "TLODOMtr";
        const string mtrReadEndUID = "TAODOMtr";

        const string destinationUID = "Dest";

        const string verifiedByUDF = "U_VerBy";
        const string verifiedByUID = "VerBy";
        const string approvedByUDF = "U_AppBy";
        const string approvedByUID = "AppBy";
        const string releasedByUID = "ReleseBy";

        const string totalWeightUDF = "U_TotWt";

        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_InvEn";
        const string matrixPrimaryColumnUID = "V_7";

        const string matrixCustomerCodeUID = "V_6";
        const string matrixCustomerCodeUDF = "U_CustCode";
        const string matrixCustomerNameUDF = "U_CustName";

        const string matrixInvoiceNoUID = "V_4";
        const string matrixInvoiceNoUDF = "U_InvNo";
        const string matrixInvoiceEntryUDF = "U_InvEn";
        const string matrixInvoiceDateUDF = "U_InvDate";
        const string matrixActualWeightUDF = "U_ActWt";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Dest", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Destination is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TimeLeft", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Time Left is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FuelIssu", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Fuel Issue is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ReleseBy", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Released by is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_AppBy", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Approved by is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_VerBy", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Verified by is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    string meterStart = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(mtrReadStartUDF, 0).ToString().Trim();
                                    double dblMeterStart = meterStart == string.Empty ? 0 : double.Parse(meterStart);
                                    if (dblMeterStart == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Meter start reading is mandatory.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    #region Duplicate Invoice Validation 

                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                                    List<string> list = new List<string>();
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        list.Add(oDbDataSource.GetValue(matrixInvoiceNoUDF, i));
                                    }

                                    var query = list.GroupBy(x => x)
                                      .Where(g => g.Count() > 1)
                                      .Select(y => y.Key)
                                      .ToList();
                                    if (query.Count > 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Duplicates Invoice No ." + query[0].ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    #endregion
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == "VehcNo")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT DISTINCT \"" + vehicleNoUDF + "\"  ");
                                sbQuery.Append(" FROM \"OINV\" T0  ");
                                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                                {
                                    sbQuery.Append(" WHERE IFNULL(T0.\"" + vehicleNoUDF + "\",'') !='' ");
                                }
                                else
                                {
                                    sbQuery.Append(" WHERE ISNULL(T0.\"" + vehicleNoUDF + "\",'') !='' ");
                                }
                                sbQuery.Append(" AND NOT EXISTS ");
                                sbQuery.Append("  (SELECT 1 FROM \"" + rowTable + "\" IT0 INNER JOIN  \"" + headerTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + matrixInvoiceEntryUDF + "\" AND IT1.\"" + CommonFields.Canceled + "\" = 'N' )");
                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_VEH, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInvoices), sbQuery.ToString(), vehicleNoUDF, alCondVal);
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixCustomerCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string vehicleNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(vehicleNoUDF, 0).Trim();

                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    //temp = new ArrayList();
                                    //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    //temp.Add(CommonFields.CardType); //Condition Alias             
                                    //temp.Add("C"); //Condition Value
                                    //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    //alCondVal.Add(temp);
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T0.\"" + CommonFields.CardCode + "\"  ");
                                    sbQuery.Append(" FROM \"OINV\" T0  ");
                                    sbQuery.Append(" WHERE T0.\"" + vehicleNoUDF + "\" ='" + vehicleNo + "'  ");
                                    sbQuery.Append(" AND NOT EXISTS ");
                                    sbQuery.Append("  (SELECT 1 FROM \"" + rowTable + "\" IT0 INNER JOIN  \"" + headerTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + matrixInvoiceEntryUDF + "\" AND IT1.\"" + CommonFields.Canceled + "\" = 'N' )");

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    //string query = "Select \"ItemCode\" FROM \"IGN1\" WHERE \"DocEntry\" = '" + receiptEntry + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARD, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oBusinessPartners), sbQuery.ToString(), CommonFields.CardCode, alCondVal);
                                }
                                else if (pVal.ColUID == matrixInvoiceNoUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string vehicleNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(vehicleNoUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    //temp = new ArrayList();
                                    //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    //temp.Add(CommonFields.CardType); //Condition Alias             
                                    //temp.Add("C"); //Condition Value
                                    //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    //alCondVal.Add(temp);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string cardCode = oDbDataSource.GetValue(matrixCustomerCodeUDF, pVal.Row - 1).Trim();
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\"  ");
                                    sbQuery.Append(" FROM \"OINV\" T0  ");
                                    sbQuery.Append(" WHERE T0.\"" + vehicleNoUDF + "\" ='" + vehicleNo + "' AND T0.\"" + CommonFields.CardCode + "\" = '" + cardCode + "' ");
                                    sbQuery.Append(" AND NOT EXISTS ");
                                    sbQuery.Append("  (SELECT 1 FROM \"" + rowTable + "\" IT0 INNER JOIN  \"" + headerTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + matrixInvoiceEntryUDF + "\" AND IT1.\"" + CommonFields.Canceled + "\" = 'N' )");
                                    // string query = "Select \"DocEntry\" FROM \"OINV\" T0 WHERE T0.\"CardCode\" = '" + cardCode + "' AND  NOT EXISTS (SELECT 1 FROM \"" + rowTable + "\" IT0 INNER JOIN  \"" + headerTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\" WHERE T0.\"DocEntry\" = IT0.\"" + matrixInvoiceEntryUDF + "\" AND IT1.\"" + CommonFields.Canceled + "\" = 'N' AND T0.\"CardCode\" = IT0.\"" + matrixCustomerCodeUDF + "\" )";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_INV, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInvoices), sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                                }
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            try
                            {
                                SAPbouiCOM.DataTable oDataTable = null;
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                oDataTable = oCFLEvento.SelectedObjects;
                                string sCFL_ID = oCFLEvento.ChooseFromListUID;
                                string Value = string.Empty;

                                if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                {
                                    return;
                                }

                                if (oCFLEvento.ChooseFromListUID == CFL_CARD)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.SetValue(matrixCustomerCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                    oDbDataSource.SetValue(matrixCustomerNameUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                    if (pVal.Row == oMatrix.RowCount)
                                    {
                                        oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                        int RowNo = 1;
                                        for (int i = 0; i < oDbDataSource.Size; i++)
                                        {
                                            oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                            RowNo = RowNo + 1;
                                        }
                                    }
                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixCustomerCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_VEH)
                                {
                                    string vehicleNo = oDataTable.GetValue(vehicleNoUDF, 0).ToString();
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(vehicleNoUDF, 0, vehicleNo);
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(driverNameUDF, 0, oDataTable.GetValue("U_DriveName", 0).ToString());
                                    sbQuery.Length = 0;
                                    sbQuery.Append("SELECT TOP 1 \"" + mtrReadEndUDF + "\" FROM \"" + headerTable + "\" WHERE \"" + vehicleNoUDF + "\" = '" + vehicleNo + "' ORDER BY \"" + CommonFields.DocEntry + "\" DESC");
                                    string meterReadEnd = objclsComman.SelectRecord(sbQuery.ToString());
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(mtrReadStartUDF, 0, meterReadEnd);

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.Clear();
                                    oMatrix.FlushToDataSource();
                                    oMatrix.LoadFromDataSource();
                                    /*string vehicleNo = oDataTable.GetValue(vehicleNoUDF, 0).ToString();
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(vehicleNoUDF, 0, vehicleNo);

                                    

                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T0.\"CardCode\",T0.\"CardName\",T0.\"DocNum\",T0.\"DocDate\",T0.\"DocEntry\" ");
                                    sbQuery.Append(" FROM OINV T0  ");
                                    sbQuery.Append(" WHERE T0.\"" + vehicleNoUDF + "\" ='" + vehicleNo + "' ");
                                    sbQuery.Append(" AND NOT EXISTS(SELECT 1 FROM \"" + rowTable + "\" IT0 ");
                                    sbQuery.Append(" INNER JOIN  \"" + headerTable + "\" IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\" ");
                                    sbQuery.Append(" WHERE T0.\"DocEntry\" = IT0.\"" + matrixInvoiceEntryUDF + "\" AND IT1.\"" + CommonFields.Canceled + "\" = 'N' ) ");
                                    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.Clear();
                                    int row = 0;
                                    while (!oRs.EoF)
                                    {
                                        oDbDataSource.InsertRecord(row);
                                        oDbDataSource.SetValue(CommonFields.LineId, row, (row + 1).ToString());
                                        oDbDataSource.SetValue(matrixCustomerCodeUDF, row, oRs.Fields.Item("CardCode").Value.ToString());
                                        oDbDataSource.SetValue(matrixCustomerNameUDF, row, oRs.Fields.Item("CardName").Value.ToString());
                                        oDbDataSource.SetValue(matrixInvoiceNoUDF, row, oRs.Fields.Item("DocNum").Value.ToString());
                                        oDbDataSource.SetValue(matrixInvoiceEntryUDF, row, oRs.Fields.Item("DocEntry").Value.ToString());
                                        DateTime docDate = DateTime.Parse(oRs.Fields.Item("DocDate").Value.ToString());
                                        oDbDataSource.SetValue(matrixInvoiceDateUDF, row, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                        row++;
                                        oRs.MoveNext();
                                    }
                                    objclsComman.ReleaseObject(oRs);

                                    oMatrix.LoadFromDataSource();*/

                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_INV)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.SetValue(matrixInvoiceNoUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                    oDbDataSource.SetValue(matrixInvoiceEntryUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());

                                    sbQuery.Length = 0;
                                    sbQuery.Append("SELECT SUM(\"" + matrixActualWeightUDF + "\") FROM INV1 WHERE \"" + CommonFields.DocEntry + "\" ='" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "' ");
                                    string totAct = objclsComman.SelectRecord(sbQuery.ToString());
                                    oDbDataSource.SetValue(matrixActualWeightUDF, pVal.Row - 1, totAct);

                                    DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.DocDate, 0).ToString());
                                    oDbDataSource.SetValue(matrixInvoiceDateUDF, pVal.Row - 1, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                    if (pVal.Row == oMatrix.RowCount)
                                    {
                                        oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                        int RowNo = 1;
                                        for (int i = 0; i < oDbDataSource.Size; i++)
                                        {
                                            oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                            RowNo = RowNo + 1;
                                        }
                                    }
                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixInvoiceNoUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                    calTotalWeight(oForm.UniqueID);
                                }
                            }
                            catch (Exception ex)
                            {
                                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: et_ChooseFromList" + ex.Message);
                                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: et_ChooseFromList" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }
                            else if (pVal.ItemUID == mtrReadStartUID || pVal.ItemUID == mtrReadEndUID)
                            {
                                string mtrReadStart = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(mtrReadStartUDF, 0).Trim();
                                string mtrReadEnd = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(mtrReadEndUDF, 0).Trim();
                                double dblmtrReadStart = mtrReadStart == string.Empty ? 0 : double.Parse(mtrReadStart);
                                double dblmtrReadEnd = mtrReadEnd == string.Empty ? 0 : double.Parse(mtrReadEnd);
                                double dblKMTravelled = dblmtrReadEnd - dblmtrReadStart;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(KMTravelUDF, 0, dblKMTravelled.ToString());
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.CancelRecord))
                    {
                        int i = oApplication.MessageBox("Do you really want to cancel record?", 1, "Yes", "No", "");
                        if (i != 1)
                        {
                            BubbleEvent = false;
                            return;
                        }
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                        calTotalWeight(oForm.UniqueID);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        string mtrReadEnd = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(mtrReadEndUDF, 0);
                        double dblmtrReadEnd = mtrReadEnd == string.Empty ? 0 : double.Parse(mtrReadEnd);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND IFNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND ISNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                        }
                        if (dblmtrReadEnd > 0)
                        {
                            objclsComman.SelectRecord("UPDATE \"" + headerTable + "\" SET \"" + CommonFields.Status + "\" = 'C' WHERE  \"DocEntry\" ='" + docEntry + "' ");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        string canceled = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Canceled, 0).Trim();
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0).Trim();

                        if (canceled == "N" && status == "O")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                            oMatrix.LoadFromDataSource();
                            EnableControls(oForm.UniqueID);
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.EnableMenu("5895", true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    string addonName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name; //New Menu Name in Add-on Layouts
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(destinationUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@DESTMASTER\" ");

                    oCombo = oForm.Items.Item(approvedByUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM \"OUSR\" ORDER BY \"U_NAME\"");

                    oCombo = oForm.Items.Item(verifiedByUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM \"OUSR\" ORDER BY \"U_NAME\"");

                    oCombo = oForm.Items.Item(releasedByUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM \"OUSR\" ORDER BY \"U_NAME\"");

                    string ReportType = objclsComman.SelectRecord("SELECT \"CODE\" FROM RTYP WHERE \"MNU_ID\" = '" + MenuID + "' AND \"ADD_NAME\" = '" + addonName + "'");
                    if (ReportType != string.Empty)
                    {
                        oForm.ReportType = ReportType; //(Code of RTYP table)
                    }
                }
                oForm = oApplication.Forms.ActiveForm;
                EnableControls(oForm.UniqueID);

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                oItem = oForm.Items.Item("DocNum");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Status");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Canceled");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Series");
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(vehicleNoUID);
                oItem.EnableinAddMode();

                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_LorryBoy", 0, "N/A");
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void calTotalWeight(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            double dblTotalWeight = 0;
            double dblActualWeight = 0;

            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                dblActualWeight = oDbDataSource.GetValue(matrixActualWeightUDF, i) == string.Empty ? 0 : double.Parse(oDbDataSource.GetValue(matrixActualWeightUDF, i));
                dblTotalWeight = dblTotalWeight + dblActualWeight;
            }
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue(totalWeightUDF, 0, dblTotalWeight.ToString());
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
        }

        #endregion
    }
}
