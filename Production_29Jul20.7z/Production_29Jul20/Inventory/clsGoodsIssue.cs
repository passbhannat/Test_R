using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsGoodsIssue : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Column oCol;

        const string matrixUID = "13";

        public const string headerTable = "OIGE";
        public const string rowTable = "IGE1";
        
        const string matrixBaseLineUDF = "U_BaseLine";
        const string matrixBaseEntryUDF = "U_BaseEn";
        const string matrixBaseObjectTypeUDF = "U_BaseObj";

        const string matrixItemCodeUID = "1";
        const string matrixQuantityUID = "9";
        const string matrixWhsCodeUID = "15";
        const string matrixUOMCodeUID = "1001";
        const string matrixActualWeightUID = "U_ActWt";
        const string buttonCalculation = "btnAW";
        const string buttonCalculationCaption = "Actual Weight";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == buttonCalculation)
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    CalculateActualWeight(oForm);
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Form should be at Add Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            oMatrix = oForm.Items.Item(matrixUID).Specific;

                            #region Button

                            SAPbouiCOM.Item oNewItem = oForm.Items.Add(buttonCalculation, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            SAPbouiCOM.Item oItem = oForm.Items.Item("2");
                            SAPbouiCOM.Button oButton = oNewItem.Specific;
                            oButton.Caption = buttonCalculationCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width * 2;
                            oNewItem.Left = oItem.Left + oItem.Width + 10;

                            #endregion

                            if (clsVariables.boolNewFormOpen)
                            {
                                clsVariables.boolNewFormOpen = false;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUID, 1);
                                oEdit.String = clsVariables.BaseItemCode;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, 1);
                                oEdit.String = clsVariables.BaseEntry;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseLineUDF, 1);
                                oEdit.String = clsVariables.BaseLine;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, 1);
                                oEdit.String = clsVariables.BaseObjectType;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, 1);
                                oEdit.String = "1";
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {

                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT \"" + matrixBaseObjectTypeUDF + "\" ");
                        sbQuery.Append(" FROM " + rowTable + " ");
                        sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                        string baseObj = objclsComman.SelectRecord(sbQuery.ToString());
                        if (baseObj == clsDailyPlan.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsDailyPlan.matrixRewindIssueEnColumnUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsDailyPlan.matrixRewindIssueNoColumnUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append(" FROM  \"" + clsDailyPlan.rowTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\"  AND T0.\"" + CommonFields.LineId + "\" =   T1.\"" + matrixBaseLineUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");

                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                            objclsComman.SelectRecord(sbQuery.ToString());
                        }

                        #region Actual Weight

                        // Reduce Actual Weight in From Warehouse Location
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_ActWt\" = IFNULL(T0.\"U_ActWt\",0)  -  ");
                        sbQuery.Append("  (SELECT SUM(A.\"U_ActWt\") FROM " + rowTable + " A WHERE  A.\"DocEntry\" = T1.\"DocEntry\" AND A.\"ItemCode\" = T1.\"ItemCode\" AND A.\"WhsCode\" = T1.\"WhsCode\" ) ");

                        sbQuery.Append(" FROM OITW T0 ");
                        sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" AND T0.\"WhsCode\" = T1.\"WhsCode\" ");
                        sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' ");

                        objclsComman.SelectRecord(sbQuery.ToString());

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion


        private void CalculateActualWeight(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oCol = oMatrix.Columns.Item(matrixActualWeightUID);
            oCol.Editable = true;
            try
            {
                SAPbobsCOM.Recordset oRs = null;
                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                {
                    string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUID, i)).String;
                    string quantity = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, i)).String;
                    string whsCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixWhsCodeUID, i)).String;
                    string uomCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixUOMCodeUID, i)).String;

                    if (itemCode == string.Empty)
                    {
                        continue;
                    }
                    quantity = quantity == string.Empty ? "0" : quantity;
                    double dblQuantity = double.Parse(quantity);
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.\"OnHand\",T0.\"U_ActWt\"  ");
                    sbQuery.Append(" FROM OITW T0 ");
                    sbQuery.Append(" WHERE T0.\"ItemCode\" = '" + itemCode + "' AND  T0.\"WhsCode\" = '" + whsCode + "'");
                    oRs = objclsComman.returnRecord(sbQuery.ToString());
                    double dblOnHandQty = oRs.Fields.Item("OnHand").Value;
                    string actualWeight = oRs.Fields.Item("U_ActWt").Value.ToString();
                    actualWeight = actualWeight == string.Empty ? "0" : actualWeight;
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T4.\"BaseQty\" ");
                    sbQuery.Append(" FROM \"OITM\" T2  ");
                    sbQuery.Append(" LEFT JOIN \"OUOM\" T3 ON  T3.\"UomCode\" = '" + uomCode + "' ");
                    sbQuery.Append(" LEFT JOIN \"UGP1\" T4 ON T3.\"UomEntry\" = T4.\"UomEntry\" ");
                    sbQuery.Append(" AND T2.\"UgpEntry\" = T4.\"UgpEntry\"  ");
                    sbQuery.Append(" WHERE T2.\"ItemCode\" = '" + itemCode + "'  ");
                    string baseQty = objclsComman.SelectRecord(sbQuery.ToString());
                    baseQty = baseQty == string.Empty ? "1" : baseQty;
                    double dblBaseQty = double.Parse(baseQty);
                    double dblActualWeight = 0;
                    if (dblOnHandQty > 0)
                    {
                        dblActualWeight = (double.Parse(actualWeight) / dblOnHandQty) * dblQuantity * dblBaseQty;
                    }
                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixActualWeightUID, i)).String = dblActualWeight.ToString();
                }
                objclsComman.ReleaseObject(oRs);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calculate Actual Weight: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            //Comments 
            //oEdit = oForm.Items.Item("16").Specific;
            //oEdit.Active = true;
            //oCol.Editable = false;
        }
    }
}
