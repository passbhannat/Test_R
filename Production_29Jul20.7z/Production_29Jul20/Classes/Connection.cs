using Production;
using Production.Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace General.Classes
{
    class Connection
    {
        #region SAP Objects

        public static SAPbouiCOM.Application oApplication;
        public static SAPbobsCOM.Company oCompany;
        public static bool isLiceseExpired;
        public static string salt;

        #endregion

        #region Methods

        /// <summary>
        /// Connect to SAP application
        /// </summary>
        public void ConnectToSAPApplication()
        {
            try
            {
                SAPMain.logger.DebugFormat("> {0}", nameof(ConnectToSAPApplication));
                string devConnectionString = string.Empty;
                try
                {
                    devConnectionString = Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));
                }
                catch
                {
                    devConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
                }
                var sboGuiApi = new SAPbouiCOM.SboGuiApi();
                sboGuiApi.Connect(devConnectionString);

                oApplication = sboGuiApi.GetApplication();
                oCompany = (SAPbobsCOM.Company)oApplication.Company.GetDICompany();
                TempLicenseExpired();
                if (isLiceseExpired == false)
                {
                    oApplication.StatusBar.SetText(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " addon connected successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Connect Application Error: " + ex.Message);
            }
        }

        private void TempLicenseExpired()
        {
            clsCommon _clsCommon = new clsCommon();
            SAPbobsCOM.Recordset oRs = _clsCommon.returnRecord("SELECT * FROM \"@DBCONFIG\"");
            if (oRs.RecordCount == 0)
            {
                isLiceseExpired = true;
                oApplication.StatusBar.SetText("Add on licensing not set", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                _clsCommon.ReleaseObject(oRs);
                return;
            }
            else
            {
                salt = "uEFTde3i2fYGVGWFvBMQL7S2oMpM2hsDzsxrvGzUWQVwbr2qEC";
                string dateHashValue = oRs.Fields.Item("U_Password2").Value.ToString();
                DateTime dateTime = Convert.ToDateTime(oRs.Fields.Item("U_Date").Value);
                string year = dateTime.Year.ToString();
                if (year.Length == 2)
                {
                    year = "20" + year;
                }
                string date = year + dateTime.Month.ToString().PadLeft(2, '0') + dateTime.Day.ToString().PadLeft(2, '0');
                var encodedDate = AccountHelper.EncodePassword(date, salt);
                if (encodedDate != dateHashValue)
                {
                    isLiceseExpired = true;
                    oApplication.StatusBar.SetText("Add on licensing has been tampered", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    _clsCommon.ReleaseObject(oRs);
                    return;
                }
                DateTime todayDatetime = DateTime.Now.Date;
                DateTime validDatetime = new DateTime(2000, 1, 1);
                if (dateTime <= validDatetime)
                {
                    isLiceseExpired = true;
                    oApplication.StatusBar.SetText("Addon license expire. Please contact to your vendor", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                if (dateTime < todayDatetime)
                {
                    isLiceseExpired = true;
                    oApplication.StatusBar.SetText("Addon license expire. Please contact to your vendor", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                DateTime oneMonthPriorDate = dateTime.AddMonths(-1);
                if (oneMonthPriorDate < todayDatetime)
                {
                    //oApplication.StatusBar.SetText("Add on will expire on " + dateTime.ToShortDateString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    oApplication.MessageBox("Add on will expire on " + dateTime.ToShortDateString());
                }
                return;
            }
        }

        #endregion
    }
}
