using General;
using General.Classes;
using General.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;

namespace Production
{
    class SAPMain : Connection
    {
        public static ILog logger;
        SAPbouiCOM.Form oForm;

        #region Variables

        clsCommon objclsComman = new clsCommon();
        clsImportLicense objclsImportLicense = new clsImportLicense();
        clsValidatePassword objclsValidatePassword = new clsValidatePassword();

        clsWeighingScale objclsWeighingScale = new clsWeighingScale();
        clsWeighingScaleQC objclsWeighingScaleQC = new clsWeighingScaleQC();
        clsBatchWeighingScale objclsBatchWeighingScale = new clsBatchWeighingScale();
        clsDailyPlan objclsDailyPlan = new clsDailyPlan();
        clsDailyPlanSFG objclsDailyPlanSFG = new clsDailyPlanSFG();
        clsDailyPlanSOSelection objclsDailyPlanSOSelection = new clsDailyPlanSOSelection();
        clsDailyPlanItemSelection objclsDailyPlanItemSelection = new clsDailyPlanItemSelection();

        clsBarCodeGeneration objclsBarCodeGeneration = new clsBarCodeGeneration();
        clsBarCodeSelection objclsBarCodeSelection = new clsBarCodeSelection();
        clsBarCodeAssignment objclsBarCodeAssignment = new clsBarCodeAssignment();
        clsMultipleBarCodeSelection objclsMultipleBarCodeSelection = new clsMultipleBarCodeSelection();
        clsMultipleQCAssignment objclsMultipleQCAssignment = new clsMultipleQCAssignment();

        clsMachineMaster objclsMachineMaster = new clsMachineMaster();
        clsQCParameter objclsQCParameter = new clsQCParameter();
        clsQCSpecification objclsQCSpecification = new clsQCSpecification();
        clsWeighingScaleQCParameter objclsWeighingScaleQCParameter = new clsWeighingScaleQCParameter();
        clsScrapScale objclsScrapScale = new clsScrapScale();
        clsGatePass objclsGatePass = new clsGatePass();

        clsGoodsReceipt objclsGoodsReceipt = new clsGoodsReceipt();
        clsGoodsIssue objclsGoodsIssue = new clsGoodsIssue();
        clsIT objclsIT = new clsIT();

        clsProduction objclsProduction = new clsProduction();
        clsReceiptFromProduction objclsReceiptFromProduction = new clsReceiptFromProduction();
        clsBatchInward objclsBatchInward = new clsBatchInward();
        clsIssueForProduction objclsIssueForProduction = new clsIssueForProduction();

        clsBOMMaster objclsBOMMaster = new clsBOMMaster();

        clsDelivery objclsDelivery = new clsDelivery();
        clsARInvoice objclsARInvoice = new clsARInvoice();
        clsReturn objclsReturn = new clsReturn();
        clsARCreditMemo objclsARCreditMemo = new clsARCreditMemo();

        clsBinCodeOutward objclsBinCodeOutward = new clsBinCodeOutward();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
        }


        private void PrepareMenus()
        {
            //logger.DebugFormat("> {0}", nameof(PrepareMenus));
            string superUser = objclsComman.SelectRecord("SELECT SuperUser FROM OUSR WHERE UserId='" + oCompany.UserSignature + "'");
            if (superUser == YesNoEnum.Y.ToString())
            {
                objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.PROUDO.ToString(), SAPCustomFormUIDEnum.PROUDO.ToDescription(), "", 0);
                objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.IMPORT_LICENSE.ToString(), SAPCustomFormUIDEnum.IMPORT_LICENSE.ToDescription(), "", 6);
            }
            if (isLiceseExpired == false)
            {
                objclsComman.AddMenu(BoMenuType.mt_POPUP, Convert.ToString((int)SAPMenuEnum.Modules), SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.PRODCUST.ToDescription(), SAPCustomFormUIDEnum.PRODCUST.ToString(), 16);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.DAILYPLAN.ToString(), SAPCustomFormUIDEnum.DAILYPLAN.ToDescription(), "", 0);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.BARCODEGEN.ToString(), SAPCustomFormUIDEnum.BARCODEGEN.ToDescription(), "", 1);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.BARCODEASSIGN.ToString(), SAPCustomFormUIDEnum.BARCODEASSIGN.ToDescription(), "", 2);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString(), SAPCustomFormUIDEnum.WEIGHINGSCALE.ToDescription(), "", 3);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString(), SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToDescription(), "", 4);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.SCRAPSCALE.ToString(), SAPCustomFormUIDEnum.SCRAPSCALE.ToDescription(), "", 5);
                //objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString(), SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToDescription(), "", 5);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.GATEPASS.ToString(), SAPCustomFormUIDEnum.GATEPASS.ToDescription(), "", 6);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.MACHINEMASTER.ToString(), SAPCustomFormUIDEnum.MACHINEMASTER.ToDescription(), "", 7);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.BOMMASTER.ToString(), SAPCustomFormUIDEnum.BOMMASTER.ToDescription(), "", 8);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.QCPARA.ToString(), SAPCustomFormUIDEnum.QCPARA.ToDescription(), "", 9);
                objclsComman.AddMenu(BoMenuType.mt_STRING, SAPCustomFormUIDEnum.PRODCUST.ToString(), SAPCustomFormUIDEnum.QCSPEC.ToString(), SAPCustomFormUIDEnum.QCSPEC.ToDescription(), "", 10);
            }
        }

        private void RemoveMenusFromSAP()
        {
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.PROUDO.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString());
            //objclsComman.RemoveMenu(SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.BARCODEGEN.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.BARCODEASSIGN.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.GATEPASS.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.DAILYPLAN.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.SCRAPSCALE.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.MACHINEMASTER.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.BOMMASTER.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.QCPARA.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.QCPARA.ToString());
            objclsComman.RemoveMenu(SAPCustomFormUIDEnum.QCSPEC.ToString());
        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.LayoutKeyEvent += new _IApplicationEvents_LayoutKeyEventEventHandler(oApplication_LayoutKeyEvent);
        }


        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.FormTypeEx == SAPCustomFormUIDEnum.PASSWORD.ToString())
                {
                    objclsValidatePassword.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.IMPORT_LICENSE.ToString())
                {
                    objclsImportLicense.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString())
                {
                    objclsWeighingScale.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString())
                {
                    objclsWeighingScaleQC.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.MULTIQCASSIGN.ToString())
                {
                    objclsMultipleQCAssignment.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQCPAR.ToString())
                {
                    objclsWeighingScaleQCParameter.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString())
                {
                    objclsBatchWeighingScale.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLAN.ToString())
                {
                    objclsDailyPlan.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLANSO.ToString())
                {
                    objclsDailyPlanSOSelection.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLANITEM.ToString())
                {
                    objclsDailyPlanItemSelection.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLANSFG.ToString())
                {
                    objclsDailyPlanSFG.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.BARCODEGEN.ToString())
                {
                    objclsBarCodeGeneration.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.BARCODESEL.ToString())
                {
                    objclsBarCodeSelection.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.MULTIBARCODESEL.ToString())
                {
                    objclsMultipleBarCodeSelection.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.BARCODEASSIGN.ToString())
                {
                    objclsBarCodeAssignment.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.MACHINEMASTER.ToString())
                {
                    objclsMachineMaster.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.QCPARA.ToString())
                {
                    objclsQCParameter.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.QCSPEC.ToString())
                {
                    objclsQCSpecification.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.SCRAPSCALE.ToString())
                {
                    objclsScrapScale.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.GATEPASS.ToString())
                {
                    objclsGatePass.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.GoodsReceipt))
                {
                    objclsGoodsReceipt.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.GoodsIssue))
                {
                    objclsGoodsIssue.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.InventoryTransfer))
                {
                    objclsIT.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
                {
                    objclsDelivery.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.BinCodeOutward))
                {
                    objclsBinCodeOutward.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Production))
                {
                    objclsProduction.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProduction) || pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProductionUDFForm))
                {
                    objclsReceiptFromProduction.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.BatchInward))
                {
                    objclsBatchInward.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.IssueForProduction))
                {
                    objclsIssueForProduction.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == SAPCustomFormUIDEnum.BOMMASTER.ToString())
                {
                    objclsBOMMaster.ItemEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch
                {
                    oForm = null;
                }

                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == SAPCustomFormUIDEnum.PROUDO.ToString())
                    {
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }
                if (pVal.MenuUID == SAPCustomFormUIDEnum.IMPORT_LICENSE.ToString() || oForm.TypeEx == SAPCustomFormUIDEnum.IMPORT_LICENSE.ToString())
                {
                    objclsValidatePassword.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString()))
                {
                    objclsWeighingScale.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString()))
                {
                    objclsWeighingScaleQC.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.WEIGHINGSCALEQCPAR.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQCPAR.ToString()))
                {
                    objclsWeighingScaleQCParameter.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString()))
                {
                    objclsBatchWeighingScale.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.DAILYPLAN.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.DAILYPLAN.ToString()))
                {
                    objclsDailyPlan.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.DAILYPLANSFG.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.DAILYPLANSFG.ToString()))
                {
                    objclsDailyPlanSFG.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.BARCODEGEN.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.BARCODEGEN.ToString()))
                {
                    objclsBarCodeGeneration.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.BARCODEASSIGN.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.BARCODEASSIGN.ToString()))
                {
                    objclsBarCodeAssignment.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.MACHINEMASTER.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.MACHINEMASTER.ToString()))
                {
                    objclsMachineMaster.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.QCPARA.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.QCPARA.ToString()))
                {
                    objclsQCParameter.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.QCSPEC.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.QCSPEC.ToString()))
                {
                    objclsQCSpecification.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.SCRAPSCALE.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.SCRAPSCALE.ToString()))
                {
                    objclsScrapScale.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.GATEPASS.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.GATEPASS.ToString()))
                {
                    objclsGatePass.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == SAPCustomFormUIDEnum.BOMMASTER.ToString() || (oForm != null && oForm.TypeEx == SAPCustomFormUIDEnum.BOMMASTER.ToString()))
                {
                    objclsBOMMaster.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                //oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALE.ToString())
                {
                    objclsWeighingScale.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQC.ToString())
                {
                    objclsWeighingScaleQC.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.WEIGHINGSCALEQCPAR.ToString())
                {
                    objclsWeighingScaleQCParameter.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.BATCHWEIGHINGSCALE.ToString())
                {
                    objclsBatchWeighingScale.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLAN.ToString())
                {
                    objclsDailyPlan.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.DAILYPLANSFG.ToString())
                {
                    objclsDailyPlanSFG.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.BARCODEGEN.ToString())
                {
                    objclsBarCodeGeneration.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.BARCODEASSIGN.ToString())
                {
                    objclsBarCodeAssignment.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.MACHINEMASTER.ToString())
                {
                    objclsMachineMaster.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.QCSPEC.ToString())
                {
                    objclsQCSpecification.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.SCRAPSCALE.ToString())
                {
                    objclsScrapScale.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.GATEPASS.ToString())
                {
                    objclsGatePass.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
                {
                    objclsDelivery.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ARInvoice))
                {
                    objclsARInvoice.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Return))
                {
                    objclsReturn.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ARCreditMemo))
                {
                    objclsARCreditMemo.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.GoodsReceipt))
                {
                    objclsGoodsReceipt.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.GoodsIssue))
                {
                    objclsGoodsIssue.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.InventoryTransfer))
                {
                    objclsIT.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.IssueForProduction))
                {
                    objclsIssueForProduction.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProduction))
                {
                    objclsReceiptFromProduction.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Production))
                {
                    objclsProduction.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == SAPCustomFormUIDEnum.BOMMASTER.ToString())
                {
                    objclsBOMMaster.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    RemoveMenusFromSAP();
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        void oApplication_LayoutKeyEvent(ref LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (eventInfo.BeforeAction == true)
            {
                if (eventInfo.FormUID.Contains(SAPCustomFormUIDEnum.DAILYPLAN.ToString())
                    || eventInfo.FormUID.Contains(SAPCustomFormUIDEnum.GATEPASS.ToString())
                    || eventInfo.FormUID.Contains(SAPCustomFormUIDEnum.BARCODEGEN.ToString())
                    || eventInfo.FormUID.Contains(SAPCustomFormUIDEnum.WEIGHINGSCALEQCPAR.ToString()
                    )
                    )
                {
                    eventInfo.LayoutKey = clsVariables.DocEntry;
                }

                if (eventInfo.FormUID.Contains(SAPCustomFormUIDEnum.BARCODEGEN.ToString()))
                {
                    string todayDate = objclsComman.ConvertDateToSAPDateFormat(DateTime.Now);
                    objclsComman.SelectRecord("UPDATE T0 SET T0.\"U_Printed\" = 'Y',T0.\"U_PrDate\" = '" + todayDate + "',T0.\"U_PrBy\" = '" + oCompany.UserSignature.ToString() + "'  FROM \"" + clsBarCodeGeneration.rowTable + "\" T0 WHERE T0.\"" + CommonFields.DocEntry + "\" ='" + clsVariables.DocEntry + "' ");
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
