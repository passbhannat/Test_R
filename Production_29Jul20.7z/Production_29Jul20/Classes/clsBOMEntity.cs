﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Production.Classes
{
    public class clsBOMEntity
    {
        public string SOItemCode { get; set; }

        public string SOQuantity { get; set; }

        public string ItemCode { get; set; }

        public string MachineCode { get; set; }

        public string Process { get; set; }

        public string SFGItemCode { get; set; }

        public string SFGQty{ get; set; }
         

        public string BOMQty { get; set; }

        public string Qty { get; set; }

        public string PlanQty { get; set; }


        public string Batch { get; set; }

    }
}
