using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;
using System.IO;

namespace Production
{
    class clsReceiptFromProduction : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;

        const string matrixUID = "13";
        const string formTypeEx = "65214";

        public const string headerTable = "OIGN";
        public const string rowTable = "IGN1";

        const string matrixOrdNoUID = "61";
        const string matrixItemCodeUID = "1";
        const string matrixQuantityUID = "9";

        const string matrixBaseLineUDF = "U_BaseLine";
        const string matrixBaseEntryUDF = "U_BaseEn";
        const string matrixBaseObjectTypeUDF = "U_BaseObj";
        const string matrixActualWeightUDF = "U_ActWt";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    try
                                    {
                                        string isExists = objclsComman.SelectRecord("SELECT 1 FROM \"" + CommonTables.ValidationTable + "\" WHERE \"" + CommonFields.Code + "\" = '" + formTypeEx + "' AND \"U_InActive\" ='Y' ");
                                        if (isExists != "1")
                                        {
                                            ValidateFormData(oForm);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    }
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProductionUDFForm))
                            {
                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(pVal.FormUID);
                                oEdit = (SAPbouiCOM.EditText)oBaseForm.Items.Item("U_Shift").Specific;
                                oEdit.String = clsVariables.BaseShift;
                            }
                            if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProduction))
                            {
                                if (clsVariables.boolNewFormOpen)
                                {
                                    if (clsVariables.BaseObjectType == clsWeighingScale.objType)
                                    {
                                        clsVariables.boolNewFormOpen = false;
                                        oForm = oApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount);
                                        try
                                        {
                                            oEdit = oForm.Items.Item("9").Specific;
                                            DateTime dtDocDate = Convert.ToDateTime(clsVariables.BaseDocDate);
                                            oEdit.Value = objclsComman.ConvertDateToSAPDateFormat(dtDocDate);
                                        }
                                        catch { }
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixOrdNoUID, 1);
                                        oEdit.String = clsVariables.BaseOrderNo;

                                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                        {
                                            string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                            var match = clsVariables.ItemList
                                                .FirstOrDefault(stringToCheck => stringToCheck.ItemCode.Contains(itemCode));
                                            if (match != null)
                                            {
                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, i);
                                                oEdit.String = clsVariables.BaseEntry;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, i);
                                                oEdit.String = clsVariables.BaseObjectType;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, i);
                                                oEdit.String = match.Qty;

                                                try
                                                {
                                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixActualWeightUDF, i);
                                                    oEdit.String = clsVariables.BaseTotalNetWt == string.Empty ? "0" : clsVariables.BaseTotalNetWt;
                                                }
                                                catch { }
                                            }
                                        }
                                        objclsComman.DeleteMatrixRow(oMatrix, matrixBaseEntryUDF);
                                    }
                                    if (clsVariables.BaseObjectType == clsScrapScale.objType)
                                    {
                                        clsVariables.boolNewFormOpen = false;
                                        oForm = oApplication.Forms.Item(pVal.FormUID);
                                        try
                                        {
                                            oEdit = oForm.Items.Item("9").Specific;
                                            DateTime dtDocDate = Convert.ToDateTime(clsVariables.BaseDocDate);
                                            oEdit.Value = objclsComman.ConvertDateToSAPDateFormat(dtDocDate);
                                        }
                                        catch { }
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixOrdNoUID, 1);
                                        oEdit.String = clsVariables.BaseOrderNo;

                                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                        {
                                            string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                            var match = clsVariables.ItemList
                                                .FirstOrDefault(stringToCheck => stringToCheck.ItemCode.Contains(itemCode) && stringToCheck.Selected == null);
                                            if (match != null)
                                            {
                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, i);
                                                oEdit.String = clsVariables.BaseEntry;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, i);
                                                oEdit.String = clsVariables.BaseObjectType;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, i);
                                                oEdit.String = match.Qty;

                                                match.Selected = "Y";
                                            }
                                        }
                                        objclsComman.DeleteMatrixRow(oMatrix, matrixBaseEntryUDF);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {

                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);

                        #region Updating Weighing Scale

                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT \"" + matrixBaseObjectTypeUDF + "\" ");
                        sbQuery.Append(" FROM " + rowTable + " ");
                        sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                        string baseObj = objclsComman.SelectRecord(sbQuery.ToString());
                        if (baseObj == clsWeighingScale.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsWeighingScale.matrixReceiptNoUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append(" FROM  \"" + clsWeighingScale.rowTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\" ");
                            //AND T0.\"" + CommonFields.LineId + "\" =   T1.\"" + matrixBaseLineUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");
                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "' AND  T0.\"" + clsWeighingScale.matrixCheckUDF + "\" ='Y' ");
                            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                            {
                                sbQuery.Append("  AND  IFNULL(\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'')='' ");
                            }
                            else
                            {
                                sbQuery.Append("  AND  ISNULL(\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'')='' ");
                            }
                            objclsComman.SelectRecord(sbQuery.ToString());

                            sbQuery.Length = 0;
                            sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\" FROM \"" + clsWeighingScale.rowTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\" ");
                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "'  ");
                            string weighingScaleDocEntry = objclsComman.SelectRecord(sbQuery.ToString());

                            sbQuery.Length = 0;
                            sbQuery.Append(" SELECT 1  FROM \"" + clsWeighingScale.rowTable + "\" T0 ");
                            sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + weighingScaleDocEntry + "'  ");
                            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                            {
                                sbQuery.Append(" AND  IFNULL(T0.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'') = ''  ");
                            }
                            else
                            {
                                sbQuery.Append(" AND  ISNULL(T0.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'') = ''  ");
                            }
                            string isExist = objclsComman.SelectRecord(sbQuery.ToString()).Trim();
                            if (isExist != "1")
                            {
                                sbQuery.Length = 0;
                                sbQuery.Append(" UPDATE T0 ");
                                sbQuery.Append(" SET  T0.\"" + CommonFields.Status + "\" = 'C' ");
                                sbQuery.Append(" FROM  \"" + clsWeighingScale.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + weighingScaleDocEntry + "'  ");
                                objclsComman.SelectRecord(sbQuery.ToString());
                            }
                        }
                        #endregion

                        #region Updating Scrap Scale
                        else if (baseObj == clsScrapScale.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsScrapScale.receiptEntryUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsScrapScale.receiptNoUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append("  , T0.\"" + CommonFields.Status + "\" = 'C' ");
                            sbQuery.Append(" FROM  \"" + clsScrapScale.headerTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");
                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "'  ");

                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                        #endregion

                        //Get Production order docEntry

                        string poDocEntry = "";
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T0.\"" + CommonFields.BaseEntry + "\"  ");
                        sbQuery.Append(" FROM \"" + rowTable + "\" T0 ");
                        sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + docEntry + "' AND IFNULL(T0.\"LineNum\",0) = 0 ");
                        poDocEntry = objclsComman.SelectRecord(sbQuery.ToString());

                        //Get Production order completed

                        string completedQty = "";
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T0.\"" + CommonFields.CmpltQty + "\"  ");
                        sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" T0 ");
                        sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + docEntry + "' ");
                        completedQty = objclsComman.SelectRecord(sbQuery.ToString());

                        //Get Minimum WIL
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT MIN(T1.\"U_WIL\")  ");
                        sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" T0 ");
                        sbQuery.Append(" INNER JOIN  \"" + CommonTables.ProductionOrderRowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                        sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + poDocEntry + "' AND IFNULL(T1.\"U_WIL\",0) > 0 ");
                        string minWIL = objclsComman.SelectRecord(sbQuery.ToString());
                        double dblSmallestWIL = minWIL == string.Empty ? 0 : double.Parse(minWIL);

                        double dblCompletedQty = completedQty == string.Empty ? 0 : double.Parse(completedQty);
                        double dblPendingReceipt = dblSmallestWIL - dblCompletedQty;

                        // Updating Pending Quantity
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET T0.\"U_PendRec\" = '" + dblPendingReceipt.ToString() + "' ");
                        sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" T0 ");
                        sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + poDocEntry + "'");
                        objclsComman.SelectRecord(sbQuery.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }


        #endregion

        private void ValidateFormData(SAPbouiCOM.Form oForm)
        {

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            SAPbobsCOM.Recordset oRs = null;
            double pendReceipt = 0;
            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                string poNo = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", i)).String;
                string poSeries = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", i)).Value.Trim();
                string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                string completedQuantity = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", i)).String;

                sbQuery.Length = 0;
                sbQuery.Append(" SELECT \"U_PendRec\"");
                sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\"");
                sbQuery.Append(" WHERE \"" + CommonFields.DocNum + "\" = '" + poNo + "'");
                sbQuery.Append(" AND \"" + CommonFields.Series + "\" = '" + poSeries + "' ");
                sbQuery.Append(" AND \"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");

                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount > 0)
                {
                    pendReceipt = oRs.Fields.Item("U_PendRec").Value;
                    completedQuantity = completedQuantity == string.Empty ? "0" : completedQuantity;
                    if (double.Parse(completedQuantity) > pendReceipt)
                    {
                        throw new InvalidDataException("Receipt quantity: " + completedQuantity + " is greater than pending receipt quantity: " + pendReceipt);
                    }
                }
            }
            objclsComman.ReleaseObject(oRs);
        }
    }
}
