using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsProduction : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        const string matrixUID = "37";

        public const string headerTable = "OWOR";
        public const string rowTable = "WOR1";

        const string matrixTypeUID = "1880000002";
        const string matrixItemCodeUID = "4";
        const string matrixBaseQtyUID = "2";
        const string matrixPlannedQtyUID = "14";
        const string matrixIssuedQtyUID = "13";
        const string matrixWILUID = "U_WIL";

        const string matrixWhsCodeUID = "10";
        const string matrixIssMethodUID = "9";
        const string matrixLayerUID = "U_Layer";
        const string matrixLayerPerUID = "U_Percent";
        const string matrixStaionUID = "U_Station";
        const string matrixStandardUID = "U_Std";
        const string matrixAniloxUID = "U_Anilox";
        const string matrixViscUID = "U_Viscocity";


        const string stPendingReceipt = "stPendRec";
        const string stPendingReceiptCaption = "Pending Receipt";
        const string edPendingReceipt = "U_PendRec";

        const string buttonFillBOM = "btnFill";
        const string buttonFillBOMCaption = "Fill BOM";

        const string buttonCalc = "btnCalc";
        const string buttonCalcCaption = "Calc";

        const string buttonRemove = "btnRem";
        const string buttonRemoveCaption = "Remove DPI ";


        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Fill BOM

                            if (pVal.ItemUID == buttonFillBOM)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string type = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Type", 0).Trim();
                                if (type != "P")
                                {
                                    oApplication.StatusBar.SetText("Production type should be special", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                string itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ItemCode", 0).Trim();
                                string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("PlannedQty", 0).Trim();
                                double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
                                string machineCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MacCode", 0).Trim();
                                if (dblPlannedQty > 1)
                                {
                                    oApplication.StatusBar.SetText("Planned Qty should be 1 while filling BOM data", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (machineCode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Machine code is mandatory", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                SAPbobsCOM.Recordset oRs;
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"U_Qty\" AS \"BOMHeadeQty\",T1.* ");
                                sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" INNER JOIN \"" + clsBOMMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' ");
                                sbQuery.Append(" AND T0.\"" + clsBOMMaster.machineCodeUDF + "\" ='" + machineCode + "' ");
                                oRs = objclsComman.returnRecord(sbQuery.ToString());

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                decimal dblBOMHeaderQty = 0;
                                decimal dblCompQty = 0;
                                decimal dblBaseQty = 0;

                                int i = 1;
                                while (!oRs.EoF)
                                {
                                    dblBOMHeaderQty = decimal.Parse(oRs.Fields.Item("BOMHeadeQty").Value.ToString());
                                    dblCompQty = decimal.Parse(oRs.Fields.Item("U_CompQty").Value.ToString());
                                    //dblBaseQty = Math.Ceiling(dblCompQty / dblBOMHeaderQty);
                                    dblBaseQty = dblCompQty / dblBOMHeaderQty;
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixTypeUID, i)).Select(oRs.Fields.Item("U_Type").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUID, i)).String = oRs.Fields.Item("U_CompPrdC").Value.ToString();

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseQtyUID, i)).String = dblBaseQty.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixPlannedQtyUID, i)).String = dblBaseQty.ToString();

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixWhsCodeUID, i)).String = oRs.Fields.Item("U_CompWhs").Value.ToString();
                                    ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixIssMethodUID, i)).Select(oRs.Fields.Item("U_IssMeth").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixLayerPerUID, i)).String = oRs.Fields.Item("U_LayerPer").Value.ToString();
                                    try
                                    {
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixLayerUID, i)).Select(oRs.Fields.Item("U_Layer").Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue);
                                    }
                                    catch { }
                                    //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixStandardUID, i)).String = oRs.Fields.Item("U_Std").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixStaionUID, i)).String = oRs.Fields.Item("U_Station").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixAniloxUID, i)).String = oRs.Fields.Item("U_Anilox").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixViscUID, i)).String = oRs.Fields.Item("U_Visc").Value.ToString();
                                    i++;
                                    oRs.MoveNext();
                                }

                                objclsComman.ReleaseObject(oRs);
                            }
                            #endregion

                            #region Calc
                            else if (pVal.ItemUID == buttonCalc)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                Calc(oForm);
                            }
                            #endregion

                            #region Remove Daily Production Item
                            else if (pVal.ItemUID == buttonRemove)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Status", 0).Trim();
                                if (status != "L")
                                {
                                    oApplication.StatusBar.SetText("Form status should be closed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                RemoveDailyPlanItem(oForm);
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region Button

                            SAPbouiCOM.Item oNewItem = oForm.Items.Add(buttonFillBOM, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            SAPbouiCOM.Item oItem = oForm.Items.Item("2");
                            SAPbouiCOM.Button oButton = oNewItem.Specific;
                            oButton.Caption = buttonFillBOMCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left + oItem.Width + 10;

                            oNewItem = oForm.Items.Add(buttonCalc, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            oButton = oNewItem.Specific;
                            oButton.Caption = buttonCalcCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oForm.Items.Item(buttonFillBOM).Left + oItem.Width + 10;

                            oNewItem = oForm.Items.Add(buttonRemove, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            oButton = oNewItem.Specific;
                            oButton.Caption = buttonRemoveCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oForm.Items.Item(buttonCalc).Left + oItem.Width + 10;


                            oNewItem = oForm.Items.Add(stPendingReceipt, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("255000116");
                            SAPbouiCOM.StaticText oStatic = oNewItem.Specific;
                            oStatic.Caption = stPendingReceiptCaption;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            //oNewItem.FromPane = 2;
                            //oNewItem.ToPane = 2;

                            oNewItem = oForm.Items.Add(edPendingReceipt, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("255000117");
                            oEdit = oNewItem.Specific;
                            oNewItem.Top = oItem.Top + oItem.Height + 5;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Disable();
                            oEdit.DataBind.SetBound(true, headerTable, edPendingReceipt);
                            //oNewItem.FromPane = 2;
                            //oNewItem.ToPane = 2;

                            #endregion

                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oColumn = oMatrix.Columns.Item(matrixWILUID);
                            oColumn.Editable = false;
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "12")
                            {
                                string itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ItemCode", 0).Trim();
                                string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("PlannedQty", 0).Trim();
                                decimal dblPlannedQty = plannedQty == string.Empty ? 0 : decimal.Parse(plannedQty);
                                string machineCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MacCode", 0).Trim();


                                SAPbobsCOM.Recordset oRs;
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"U_Qty\" AS \"BOMHeadeQty\",T1.* ");
                                sbQuery.Append(" FROM \"" + clsBOMMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" INNER JOIN \"" + clsBOMMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                sbQuery.Append(" WHERE T0.\"" + clsBOMMaster.productCodeUDF + "\" ='" + itemCode + "' ");
                                sbQuery.Append(" AND T0.\"" + clsBOMMaster.machineCodeUDF + "\" ='" + machineCode + "' ");
                                oRs = objclsComman.returnRecord(sbQuery.ToString());

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                decimal dblBOMHeaderQty = 0;
                                decimal dblCompQty = 0;
                                decimal dblBaseQty = 0;

                                int i = 1;
                                while (!oRs.EoF)
                                {
                                    try
                                    {
                                        dblBOMHeaderQty = decimal.Parse(oRs.Fields.Item("BOMHeadeQty").Value.ToString());
                                        dblCompQty = decimal.Parse(oRs.Fields.Item("U_CompQty").Value.ToString());
                                        //dblBaseQty = Math.Ceiling(dblCompQty / dblBOMHeaderQty);
                                        dblBaseQty = dblPlannedQty * (dblCompQty / dblBOMHeaderQty);

                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseQtyUID, i)).String = dblBaseQty.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixPlannedQtyUID, i)).String = Math.Round(dblBaseQty, 6).ToString();

                                    }
                                    catch (Exception ex)
                                    {

                                    }
                                    i++;
                                    oRs.MoveNext();
                                }

                                objclsComman.ReleaseObject(oRs);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string productionDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                        RemoveDailyPlanItem(oForm);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Methods
        private void Calc(SAPbouiCOM.Form oForm)
        {
            double dblPlannedQty = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.PlannedQty, 0).Trim());
            double dblCompletedQty = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.CmpltQty, 0).Trim());

            double dblWIL = 0;

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oColumn = oMatrix.Columns.Item(matrixWILUID);
            oColumn.Editable = true;
            List<double> list = new List<double>();

            try
            {
                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    double dblPlannedQty_Row = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixPlannedQtyUID, i)).String);
                    double dblIssuedQty_Row = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixIssuedQtyUID, i)).String);
                    dblWIL = 0;
                    if (dblPlannedQty != 0 && dblIssuedQty_Row != 0)
                    {
                        dblWIL = dblIssuedQty_Row / (dblPlannedQty_Row / dblPlannedQty);
                    }
                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixWILUID, i)).String = dblWIL.ToString();
                    if (dblWIL != 0)
                    {
                        list.Add(dblWIL);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calculation: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("12").Specific;
            oEdit.Active = true;

            oColumn.Editable = false;

            if (list.Count > 0)
            {
                double dblSmallestWIP = list.Min();
                double dblPendingReceipt = dblSmallestWIP - dblCompletedQty;

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edPendingReceipt).Specific;
                oEdit.String = dblPendingReceipt.ToString();
            }
        }

        private void RemoveDailyPlanItem(SAPbouiCOM.Form oForm)
        {
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Status", 0).Trim();
            if (status == "L")
            {
                if (CreateDailyPlan_Archive(formDocEntry) == true)
                {
                    objclsComman.SelectRecord("DELETE FROM \"" + clsDailyPlan.rowTable + "\" WHERE \"" + clsDailyPlan.matrixPOEnColumnUDF + "\" = '" + formDocEntry + "'");
                    oApplication.StatusBar.SetText("Operation completed successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                }
            }
        }

        public bool CreateDailyPlan_Archive(string formDocEntry)
        {
            SAPbobsCOM.Recordset oRs = null;
            string generalServiceHeaderTable = "DAILYPLAN";
            string generalServiceRowTable = "DAILYPLAN2";

            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT * ");
            sbQuery.Append(" FROM \"" + clsDailyPlan.rowTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"" + clsDailyPlan.matrixPOEnColumnUDF + "\"='" + formDocEntry + "'  ");

            oRs = objclsComman.returnRecord(sbQuery.ToString());
            if (oRs.RecordCount == 0)
            {
                return false;
            }
            #region Adding Record in UDO

            try
            {
                string prodPlanDocEntry = oRs.Fields.Item(CommonFields.DocEntry).Value.ToString();

                SAPbobsCOM.GeneralService oGeneralService;
                SAPbobsCOM.GeneralData oGeneralData;
                SAPbobsCOM.GeneralDataParams oGeneralParams;
                SAPbobsCOM.CompanyService oCompService;
                SAPbobsCOM.GeneralData oChild;
                SAPbobsCOM.GeneralDataCollection oChildren;
                oCompService = oCompany.GetCompanyService();

                oGeneralService = oCompService.GetGeneralService(generalServiceHeaderTable);
                oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
                oGeneralParams.SetProperty(CommonFields.DocEntry, prodPlanDocEntry);

                oGeneralData = oGeneralService.GetByParams(oGeneralParams);

                // Adding data to Detail Line
                oChildren = oGeneralData.Child(generalServiceRowTable);
                oChild = oChildren.Add();

                //oChild.SetProperty("U_BaseEn", oRs.Fields.Item(CommonFields.DocEntry).Value.ToString());
                oChild.SetProperty("U_BaseLine", oRs.Fields.Item(CommonFields.LineId).Value.ToString());

                string query = objclsComman.GetAllFieldsOfTableQuery(clsDailyPlan.archiveRowTable);
                SAPbobsCOM.Recordset oRsFields = objclsComman.returnRecord(query);
                while (!oRsFields.EoF)
                {
                    try
                    {
                        string fieldName = oRsFields.Fields.Item(0).Value;
                        oChild.SetProperty(fieldName, oRs.Fields.Item(fieldName).Value.ToString());
                    }
                    catch(Exception ex) {

                    }
                    oRsFields.MoveNext();
                }
                oGeneralService.Update(oGeneralData);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
            #endregion

            return true;
        }

        #endregion
    }
}
