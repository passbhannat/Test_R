using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;
using Production.Classes;

namespace Production
{
    class clsBinCodeOutward : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;

        public const string headerTable = "ODLN";
        public const string rowTable = "DLN1";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.ActiveForm;
                            string title = oForm.Title;
                            clsVariables.BaseFormUID = oForm.UniqueID;
                            clsVariables.BaseForm = oForm;
                        }
                        #endregion

                        #region T_et_ITEM_PRESSED

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "1470000001")
                            {
                                string itemCode = "";
                                string inStock = "";
                                string allocated = "";
                                string actualWeight = "";
                                double dblInStock = 0;
                                double dblAllocated = 0;
                                double dblActualWeight = 0;

                                double dblTotalActualWeight = 0;

                                itemCode = ((SAPbouiCOM.EditText)oForm.Items.Item("1470000013").Specific).String;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("1470000023").Specific;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    inStock = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1470000079", i)).String;
                                    inStock = inStock == string.Empty ? "0" : inStock;
                                    dblInStock = double.Parse(inStock);

                                    allocated = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1470000005", i)).String;
                                    allocated = allocated == string.Empty ? "0" : allocated;
                                    dblAllocated = double.Parse(inStock);

                                    actualWeight = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ActualWeight", i)).String;
                                    actualWeight = actualWeight == string.Empty ? "0" : actualWeight;
                                    dblActualWeight = double.Parse(actualWeight);
                                    dblActualWeight = (dblActualWeight / dblInStock) * dblAllocated;

                                    dblTotalActualWeight = dblTotalActualWeight + dblActualWeight;
                                }
                                List<clsItemEntity> list = new List<clsItemEntity>();
                                list.Add(new clsItemEntity
                                {
                                    ItemCode = itemCode,
                                    ActualWt = dblTotalActualWeight.ToString()
                                });
                                clsVariables.ItemList = list;
                                clsVariables.boolNewFormOpen = true;
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {

                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
