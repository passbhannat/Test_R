using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsARCreditMemo : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;

        public const string headerTable = "ORIN";
        public const string rowTable = "RIN1";
         
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).ToString().Trim();

                        // Reduce Actual Weight in From Warehouse Location
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_ActWt\" = IFNULL(T0.\"U_ActWt\",0)  +  ");
                        sbQuery.Append("  (SELECT SUM(A.\"U_ActWt\") FROM " + rowTable + " A WHERE  A.\"DocEntry\" = T1.\"DocEntry\" AND A.\"ItemCode\" = T1.\"ItemCode\" AND A.\"WhsCode\" = T1.\"WhsCode\" ) ");

                        sbQuery.Append(" FROM OITW T0 ");
                        sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" AND T0.\"WhsCode\" = T1.\"WhsCode\" ");
                        sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' ");

                        objclsComman.SelectRecord(sbQuery.ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

    }
}
