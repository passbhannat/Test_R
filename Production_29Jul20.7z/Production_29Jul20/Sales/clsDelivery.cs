using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsDelivery : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;

        public const string headerTable = "ODLN";
        public const string rowTable = "DLN1";

        const string matrixUID = "38";
        const string matrixActualWeightUID = "U_ActWt";
        const string buttonCalculation = "btnAW";
        const string buttonCalculationCaption = "Actual Weight";
        SAPbouiCOM.Column oCol;
        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == buttonCalculation)
                            {
                                CalculateActualWeight(oForm);
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    #region F_et_FORM_LOAD
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);

                        oMatrix = oForm.Items.Item(matrixUID).Specific;
                        oCol = oMatrix.Columns.Item(matrixActualWeightUID);
                        oCol.Editable = false;

                        #region Button

                        SAPbouiCOM.Item oNewItem = oForm.Items.Add(buttonCalculation, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                        SAPbouiCOM.Item oItem = oForm.Items.Item("2");
                        SAPbouiCOM.Button oButton = oNewItem.Specific;
                        oButton.Caption = buttonCalculationCaption;
                        oNewItem.Top = oItem.Top;
                        oNewItem.Height = oItem.Height;
                        oNewItem.Width = oItem.Width * 2;
                        oNewItem.Left = oItem.Left + oItem.Width + 10;

                        #endregion
                    }
                    #endregion

                    #region F_et_FORM_ACTIVATE
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                    {
                        if (clsVariables.boolNewFormOpen == true)
                        {
                            clsVariables.boolNewFormOpen = false;
                            if (clsVariables.ItemList == null)
                            {
                                return;
                            }
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            for (int i = 1; i < oMatrix.VisualRowCount; i++)
                            {
                                string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                var match = clsVariables.ItemList
                                                .FirstOrDefault(stringToCheck => stringToCheck.ItemCode.Contains(itemCode));
                                if (match != null)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixActualWeightUID, i);
                                    oEdit.String = match.ActualWt;
                                }
                            }
                        }
                    }
                    #endregion

                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).ToString().Trim();

                        // Reduce Actual Weight in From Warehouse Location
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_ActWt\" = IFNULL(T0.\"U_ActWt\",0)  -  ");
                        sbQuery.Append("  (SELECT SUM(A.\"U_ActWt\") FROM " + rowTable + " A WHERE  A.\"DocEntry\" = T1.\"DocEntry\" AND A.\"ItemCode\" = T1.\"ItemCode\" AND A.\"WhsCode\" = T1.\"WhsCode\" ) ");

                        sbQuery.Append(" FROM OITW T0 ");
                        sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" AND T0.\"WhsCode\" = T1.\"WhsCode\" ");
                        sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' ");

                        objclsComman.SelectRecord(sbQuery.ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion


        private void CalculateActualWeight(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
            oCol = oMatrix.Columns.Item(matrixActualWeightUID);
            oCol.Editable = true;
            try
            {
                SAPbobsCOM.Recordset oRs = null;
                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                {
                    string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                    string pickNo = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10000308", i)).String;
                    string soDocEntry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("45", i)).String.Trim();
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.*  ");
                    sbQuery.Append(" FROM PKL2 T0 ");
                    sbQuery.Append(" INNER JOIN PKL1 T1 ON T0.\"AbsEntry\" = T1.\"AbsEntry\" AND  T0.\"PickEntry\" = T1.\"PickEntry\" ");
                    sbQuery.Append(" WHERE T0.\"AbsEntry\" = '" + pickNo + "' AND T0.\"ItemCode\" = '" + itemCode + "' ");
                    sbQuery.Append(" AND T1.\"OrderEntry\" = '" + soDocEntry + "'  ");

                    oRs = objclsComman.returnRecord(sbQuery.ToString());
                    double dblTotalActualweight = 0;
                    while (!oRs.EoF)
                    {
                        double quantity = oRs.Fields.Item("PickQtty").Value;
                        string binAbsEntry = oRs.Fields.Item("BinAbs").Value.ToString();
                        string actualWeight = objclsComman.SelectRecord("SELECT \"U_ActualWeight\" FROM OBIN WHERE \"AbsEntry\" = '" + binAbsEntry + "'");
                        sbQuery.Length = 0;
                        sbQuery.Append("  SELECT T1.\"OnHandQty\" ");
                        sbQuery.Append(" FROM OBIN T0 LEFT JOIN OIBQ T1 ON T0.\"WhsCode\" = T1.\"WhsCode\" ");
                        sbQuery.Append(" AND T0.\"AbsEntry\" = T1.\"BinAbs\" "); ;
                        sbQuery.Append(" LEFT JOIN OITM T2 ON T1.\"ItemCode\" = T2.\"ItemCode\" ");
                        sbQuery.Append(" WHERE T2.\"ItemCode\" = '" + itemCode + "' AND T0.\"AbsEntry\" = '" + binAbsEntry + "'");
                        string onHandQty = objclsComman.SelectRecord(sbQuery.ToString());
                        onHandQty = onHandQty == string.Empty ? "1" : onHandQty;
                        actualWeight = actualWeight == string.Empty ? "0" : actualWeight;

                        double dblActualWeight = (double.Parse(actualWeight) / double.Parse(onHandQty)) * quantity;
                        dblTotalActualweight = dblTotalActualweight + dblActualWeight;
                        oRs.MoveNext();
                    }
                     ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ActWt", i)).String = dblTotalActualweight.ToString();
                }
                objclsComman.ReleaseObject(oRs);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calculate Actual Weight: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            //Comments 
            oEdit = oForm.Items.Item("16").Specific;
            oEdit.Active = true;
            oCol.Editable = false;
        }
    }
}
