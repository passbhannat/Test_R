using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Order
{
    class clsPrOrder : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {

                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {

                            #region pVal.ItemUID ==  "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string OrderDistr_DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("U_ORDDSTNO", 0).Trim();
                                    if (OrderDistr_DocEntry != string.Empty)
                                    {
                                        string ItemCode = oForm.DataSources.DBDataSources.Item(0).GetValue("ItemCode", 0).Trim();
                                        string OpenQty = objclsComman.SelectRecord("SELECT U_OpenQty FROM [@ORDDIST_AC1] WHERE DOCENTRY='" + OrderDistr_DocEntry + "' AND U_CITEMCOD='" + ItemCode + "'");
                                        double dblOpenQty = OpenQty == string.Empty ? 0 : double.Parse(OpenQty);
                                        double dblPlanQty = double.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("PlannedQty", 0).Trim());
                                        if (dblPlanQty > dblOpenQty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Planned Quantity can't be greater than Open Order Distribution Quantity.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {

                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("PO Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("PO Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        System.Xml.XmlDocument oXml = null;
                        oXml = new System.Xml.XmlDocument();
                        oXml.LoadXml(BusinessObjectInfo.ObjectKey);
                        string DocEntry = oXml.SelectSingleNode("/ProductionOrderParams/AbsoluteEntry").InnerText;
                        string BaseEntry = objclsComman.SelectRecord("SELECT U_ORDDSTNO FROM OWOR WHERE DOCENTRY='" + DocEntry + "' AND ISNULL(U_ORDDSTNO,'')!=''");
                        if (BaseEntry == string.Empty)
                        {
                            return;
                        }

                        StringBuilder sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET T0.U_OpenQty= T0.U_OpenQty-T1.PlannedQty ");
                        sbQuery.Append(" FROM [@ORDDIST_AC1] T0 ");
                        sbQuery.Append(" INNER JOIN OWOR T1 ON T0.DocEntry=T1.U_ORDDSTNO AND T0.U_CITEMCOD=T1.ITEMCODE ");
                        sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                        objclsComman.SelectRecord(sbQuery.ToString());

                        //string BaseEntry = objclsComman.SelectRecord("SELECT U_BaseEntry FROM OWOR WHERE DOCENTRY='" + DocEntry + "' AND U_BaseEntry IS NOT NULL");


                        sbQuery = new StringBuilder();
                        sbQuery.Append(" IF NOT EXISTS(SELECT DOCENTRY FROM [@ORDDIST_AC1] WHERE DocEntry='" + BaseEntry + "' AND ISNULL(U_OpenQty,0)!=0) ");
                        sbQuery.Append(" BEGIN ");
                        sbQuery.Append(" UPDATE [@ORDDIST_AC] SET STATUS='C' WHERE DOCENTRY='" + BaseEntry + "'");
                        sbQuery.Append(" END");
                        objclsComman.SelectRecord(sbQuery.ToString());


                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion


    }
}
