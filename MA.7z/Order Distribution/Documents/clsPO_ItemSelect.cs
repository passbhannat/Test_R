using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Order
{
    class clsPO_ItemSelect : Connection
    {
        #region Variables

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
       
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {

                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");

                                    bool IsSeletedRow = false;
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            IsSeletedRow = true;
                                            break;
                                        }
                                    }
                                    if (IsSeletedRow == false)
                                    {
                                        return;
                                    }

                                    oForm = clsVariables.BaseForm;
                                    oForm.Select();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                    if (oMatrix.VisualRowCount > 1)
                                    {
                                        oMatrix.Clear();
                                    }
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        try
                                        {
                                            oMatrix.AddRow(1, 1);
                                        }
                                        catch { }
                                    }

                                    try
                                    {
                                        oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                        oColumn.Editable = true;
                                        oColumn = oMatrix.Columns.Item("U_BaseLine");
                                        oColumn.Editable = true;
                                        oColumn = oMatrix.Columns.Item("U_BaseType");
                                        oColumn.Editable = true;
                                    }
                                    catch { }

                                    int Row = 1;
                                    string SelectedSO = string.Empty;
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            string ItemCode = oDataTable.GetValue("ItemCode", i).ToString();
                                            string Quantity = oDataTable.GetValue("Approved Qty", i).ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", Row)).String = ItemCode;
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", Row)).String = Quantity;
                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", Row)).String = oDataTable.GetValue("Warehouse", i).ToString();


                                            }
                                            catch { }
                                            try
                                            {
                                                string AdhocODNo = oDataTable.GetValue("Order Distribution No.", i).ToString();
                                                string SONO = oDataTable.GetValue("SO No", i).ToString();
                                                DateTime DocDate;
                                                if (SONO != string.Empty)
                                                {
                                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SALODRNO", Row)).String = oDataTable.GetValue("SO No", i).ToString();
                                                    DocDate = DateTime.Parse(oDataTable.GetValue("SO Date", i).ToString());
                                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SALDT", Row)).String = DocDate.ToString("yyyyMMdd");
                                                }
                                                else
                                                {
                                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SALODRNO", Row)).String = AdhocODNo;
                                                    DocDate = DateTime.Parse(oDataTable.GetValue("OD_Date", i).ToString());
                                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SALDT", Row)).String = DocDate.ToString("yyyyMMdd");
                                                }

                                            }
                                            catch { }

                                            try
                                            {

                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", Row)).String = oDataTable.GetValue("DocEntry", i).ToString();// oRs.Fields.Item("DocEntry").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseLine", Row)).String = oDataTable.GetValue("LineId", i).ToString();// oRs.Fields.Item("LineId").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", Row)).String = oDataTable.GetValue("Object", i).ToString();// oRs.Fields.Item("Object").Value.ToString();
                                            }
                                            catch { }
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", Row)).Active = true;
                                            Row = Row + 1;
                                        }
                                    }
                                }
                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseLine");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseType");
                                    oColumn.Editable = false;
                                }
                                catch { }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnSel"
                            else if (pVal.ItemUID == "btnSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "Y";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnDSel"
                            else if (pVal.ItemUID == "btnDSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "N";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion
                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Selection Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

    }
}
