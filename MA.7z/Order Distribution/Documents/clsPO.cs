using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Order
{
    class clsPO : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.DataTable oDataTable = null;
        bool boolStuffSelected = false;
        ArrayList alSelectedDoc = null;
        SAPbouiCOM.Column oColumn;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            clsVariables.BaseForm = oApplication.Forms.Item(pVal.FormUID);
                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {

                            #region Job Work & LPO
                            if (pVal.ItemUID == "btnJW" || pVal.ItemUID == "btnLPO")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).Trim();
                                string Branch = oForm.DataSources.DBDataSources.Item(0).GetValue("BPLId", 0).Trim();

                                if (CardCode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please Select the vendor code.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    BubbleEvent = false;
                                    return;
                                }

                                string Decision = string.Empty;
                                if (pVal.ItemUID == "btnJW")
                                {
                                    Decision = "JBW";
                                }
                                else
                                {
                                    Decision = "Buy";
                                }
                                clsVariables.BaseForm = oForm;
                                objclsComman.LoadXML("ORDDIST_ITEMSEL", "", "", "O");
                                string SODocEntry = string.Empty;

                                StringBuilder Query = new StringBuilder();


                                Query.Append(" SELECT 'N' Selected, T1.U_CItemCod [ItemCode],T1.U_CItemNam [Item Description],T1.U_OpenQty [Approved Qty]");
                                Query.Append(" , T0.U_DRefNo [Order Distribution No.] ,T0.U_CARDCODE [Customer Code] ");
                                Query.Append("  ,T1.U_DueDate [Order Due Date],t0.U_SONO [SO No]");
                                Query.Append(",(SELECT DOCDATE FROM ORDR A WHERE A.DOCENTRY=T0.U_SODOCE) [SO Date],T0.U_DocDate [OD_Date]");
                                Query.Append(" ,T1.U_PrefWhs [Warehouse],U_SODocE [SO DocEntry],T1.DocEntry,T1.Object,T1.LineId  ");
                                Query.Append("  FROM [@ORDDIST_AC] T0 INNER JOIN [@ORDDIST_AC1] T1 ON T0.DOCENTRY=T1.DOCENTRY ");
                                Query.Append(" WHERE T1.U_DECISION='" + Decision + "' AND U_PrefVCod='" + CardCode + "' AND T1.U_OpenQty>0 AND T0.CANCELED='N'  ");

                                if (Branch != string.Empty)
                                {
                                    Query.Append(" AND  T0.U_BPLId='" + Branch + "'   ");
                                }
                                //oForm = (SAPbouiCOM.Form)oApplication.Forms.Item("ORDDIST_ITEMSEL");
                                oForm = oApplication.Forms.ActiveForm;
                                oForm.DataSources.DataTables.Add("SODataTable");

                                oForm.DataSources.DataTables.Item(0).ExecuteQuery(Query.ToString());
                                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item("grd1").Specific;
                                oGrid.DataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                oGrid.AutoResizeColumns();

                                for (int i = 0; i < oGrid.DataTable.Columns.Count; i++)
                                {
                                    if (i == 0)
                                    {
                                        oGrid.Columns.Item("Selected").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
                                    }
                                    else
                                    {
                                        oGrid.Columns.Item(i).Editable = false;
                                    }
                                }

                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region btnDO
                            if (pVal.ItemUID == "btnStuff")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = string.Empty;
                                CardCode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).ToString();
                                string Port = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PRTOFDSHG", 0).ToString();

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_CardCode"); //Condition Alias             
                                temp.Add(CardCode); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("Status"); //Condition Alias             
                                temp.Add("O"); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_PORT"); //Condition Alias             
                                temp.Add(Port); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);


                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_STUFF", "STUFF", "", "", alCondVal);
                            }
                            #endregion
                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Delivery Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            clsVariables.BaseForm = oApplication.Forms.Item(pVal.FormUID);

                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.Button oButton;
                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);


                            //objclsComman.AddChooseFromList_NoCond(oForm, "CFL_JW", "ORDDIST");
                            oNewItem = oForm.Items.Add("btnJW", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            oNewItem.Top = oItem.Top;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.Width = oItem.Width * 2;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            // oButton.ChooseFromListUID = "CFL_JW";
                            oButton.Caption = "Copy For JobWork";

                            //objclsComman.AddChooseFromList_NoCond(oForm, "CFL_LPO", "ORDDIST");
                            oNewItem = oForm.Items.Add("btnLPO", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("btnJW");
                            oNewItem.Top = oItem.Top;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.Width = oItem.Width;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            //oButton.ChooseFromListUID = "CFL_LPO";
                            oButton.Caption = "Copy For LPO";

                            try
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                oColumn = oMatrix.Columns.Item("U_BaseLine");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_BaseType");
                                oColumn.Editable = false;
                            }
                            catch { }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region pVal.ItemUID == "btnCalc"
                            if (pVal.ItemUID == "btnCalc")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double GrsWt = 0;
                                double NoCrate = 0;

                                double TotalNoCrate = 0;
                                double TotalGrsWt = 0;
                                double TotalNetWt = 0;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i)).String);
                                    TotalNoCrate = TotalNoCrate + NoCrate;

                                    GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String);
                                    TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);

                                    NetWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);
                                    TotalNetWt = TotalNetWt + (NetWt * NoCrate);

                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                oEdit.String = TotalNoCrate.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                oEdit.String = TotalNetWt.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                oEdit.String = TotalGrsWt.ToString();
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;

                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            #region oCFLEvento.ChooseFromListUID == "CFL_STUFF"

                            if (oCFLEvento.ChooseFromListUID == "CFL_STUFF")
                            {
                                oDataTable = oCFLEvento.SelectedObjects;
                                alSelectedDoc = new ArrayList();
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    boolStuffSelected = true;
                                    alSelectedDoc.Add(oDataTable.GetValue("DocEntry", 0).ToString());

                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            oForm = oApplication.Forms.Item(FormUID);


                            if (boolStuffSelected == true)
                            {
                                boolStuffSelected = false;

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                if (oMatrix.VisualRowCount > 1)
                                {
                                    oMatrix.Clear();
                                }
                                if (oMatrix.VisualRowCount == 0)
                                {
                                    try
                                    {
                                        oMatrix.AddRow(1, 1);
                                    }
                                    catch { }
                                }
                                //oMatrix.FlushToDataSource();

                                int Row = 1;
                                string SODocEntry = string.Empty;
                                string TotalExpns = string.Empty;
                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_BaseLine");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_BaseType");
                                    oColumn.Editable = true;
                                }
                                catch { }
                                for (int i = 0; i < alSelectedDoc.Count; i++)
                                {
                                    SODocEntry = alSelectedDoc[i].ToString();
                                    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(" SELECT T0.U_OthChg, T1.U_ItemCode,T1.U_ItemName,T1.U_MARKING" +
                                          " ,T1.U_OpenQty,T1.U_Rate,T1.U_Amount,T1.U_Netwt,T1.U_GrsWt" +
                                          " ,T1.U_NoCrat,T1.U_NoPack,T1.U_PCCrate,T1.U_WtPack,T1.DOCENTRY [Disp_DocEntry],T1.LineId AS LINENUM,T1.Object" +
                                          " ,U_SONo,U_SODocEn,U_NumAtCar,U_TotCrat,U_TotNwt,U_TotGrWt,U_Total,U_FOBValue,U_InrRate" +
                                          " ,T0.DocEntry,T1.LineId,T0.Object,U_WhsCode,U_GRExch" +
                                          " ,(SELECT MAX(TAXCODE) FROM RDR1 A WHERE A.ITEMCODE=T1.U_ITEMCODE AND A.DOCENTRY=T1.u_SODocEn) TaxCode" +
                                          //" T3.*,T2.Currency" +
                                          " FROM [@STUFF] T0 " +
                                          " INNER JOIN [@STUFF1] T1 ON T0.DOCENTRY= T1.DOCENTRY " +
                                          //" LEFT JOIN RDR1 T2 ON T2.ITEMCODE= T1.U_ITEMCODE  " +
                                          " WHERE T0.DOCENTRY='" + SODocEntry + "' AND U_OpenQty>0");
                                    try
                                    {
                                        while (!oRs.EoF)
                                        {
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", Row)).String = oRs.Fields.Item("U_ItemCode").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", Row)).String = oRs.Fields.Item("U_WhsCode").Value.ToString();
                                            try
                                            {
                                                string TaxCode = oRs.Fields.Item("TaxCode").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", Row)).String = TaxCode;

                                            }
                                            catch { }

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", Row)).String = oRs.Fields.Item("U_Netwt").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", Row)).String = oRs.Fields.Item("U_GrsWt").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NOPACKING", Row)).String = oRs.Fields.Item("U_NoPack").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CRTWT", Row)).String = oRs.Fields.Item("U_PCCrate").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TOTCRTWT", Row)).String = oRs.Fields.Item("U_WtPack").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", Row)).String = oRs.Fields.Item("U_NoCrat").Value.ToString();
                                            try
                                            {

                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", Row)).String = oRs.Fields.Item("DocEntry").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseLine", Row)).String = oRs.Fields.Item("LineId").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", Row)).String = oRs.Fields.Item("Object").Value.ToString();
                                            }
                                            catch { }
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", Row)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FOBVALUE", Row)).String = oRs.Fields.Item("U_FOBValue").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RATEININR", Row)).String = oRs.Fields.Item("U_InrRate").Value.ToString();
                                            try
                                            {
                                                try
                                                {

                                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("140002027", Row)).String = oRs.Fields.Item("U_FOBValue").Value.ToString();

                                                }
                                                catch { }
                                            }
                                            catch { }
                                            try
                                            {
                                                string GRExc = oRs.Fields.Item("U_GRExch").Value.ToString();
                                                ((SAPbouiCOM.EditText)oForm.Items.Item("64").Specific).String = GRExc;
                                            }
                                            catch
                                            {
                                                oApplication.StatusBar.SetText("You can't edit Rate (System Defined field)", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", Row)).String = oRs.Fields.Item("U_Rate").Value.ToString();
                                            Row++;
                                            oRs.MoveNext();
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    }
                                    finally
                                    {
                                        if (oRs != null)
                                        {
                                            System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                        }
                                        GC.Collect();
                                        GC.WaitForPendingFinalizers();
                                    }


                                }
                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseLine");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseType");
                                    oColumn.Editable = false;
                                }
                                catch { }

                            }

                        }
                        #endregion

                        #region F_pVal.ItemChanged==true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ColUID == "U_NETWT")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;
                                double NoCrate = 0;


                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    NoCrate = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }
                            if (pVal.ColUID == "U_GRSWT")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;
                                double NoCrate = 0;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    NoCrate = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }
                            if (pVal.ColUID == "13")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + NetWt;
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("PO Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("PO Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        System.Xml.XmlDocument oXml = null;
                        oXml = new System.Xml.XmlDocument();
                        oXml.LoadXml(BusinessObjectInfo.ObjectKey);
                        string DocEntry = oXml.SelectSingleNode("/DocumentParams/DocEntry").InnerText;
                        string Exist_OD = objclsComman.SelectRecord("SELECT U_BASETYPE FROM POR1 WHERE DOCENTRY='" + DocEntry + "' AND ISNULL(U_BASETYPE,'')='ORDDIST_AC'");
                        if (Exist_OD == string.Empty)
                        {
                            return;
                        }

                        StringBuilder sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET T0.U_OpenQty= T0.U_OpenQty-T1.Quantity ");
                        sbQuery.Append(" FROM [@ORDDIST_AC1] T0 ");
                        sbQuery.Append(" INNER JOIN POR1 T1 ON T0.DocEntry=T1.U_BaseEntry AND T0.LineId=T1.U_BaseLine ");
                        sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                        objclsComman.SelectRecord(sbQuery.ToString());

                        string Disp_Plan_DocEntry = objclsComman.SelectRecord("SELECT U_BaseEntry FROM POR1 WHERE DOCENTRY='" + DocEntry + "' AND U_BaseEntry IS NOT NULL");


                        sbQuery = new StringBuilder();
                        sbQuery.Append(" IF NOT EXISTS(SELECT DOCENTRY FROM [@ORDDIST_AC1] WHERE DocEntry='" + Disp_Plan_DocEntry + "' AND ISNULL(U_OpenQty,0)!=0) ");
                        sbQuery.Append(" BEGIN ");
                        sbQuery.Append(" UPDATE [@ORDDIST_AC] SET STATUS='C' WHERE DOCENTRY='" + Disp_Plan_DocEntry + "'");
                        sbQuery.Append(" END");
                        objclsComman.SelectRecord(sbQuery.ToString());


                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion


    }
}
