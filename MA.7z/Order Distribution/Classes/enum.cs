﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace General.Classes
{
    public enum YesNoEnum
    {
        [Description("Yes")]
        Y,
        [Description("No")]
        N,
    }

    public enum SAPButtonEnum
    {
        Add = 1,
        Cancel = 2,
    }

    public enum SAPMenuEnum
    {
        FindRecord = 1281,
        AddRecord = 1282,
        RemoveRecord = 1283,
        CancelRecord = 1284,
        RestoreRecord = 1285,
        CloseRecord = 1286,
        LastRecord = 1291,
        FirstRecord = 1290,
        NextRecord = 1288,
        PreviousRecord = 1289,
        AddRow = 1292,
        DeleteRow = 1293,
        FilterTable = 4870,
        UDFForm = 6913,
        SystemInitialisation = 8192,
        Modules = 43520
    }

    public enum SAPFormUIDEnum
    {
        MainMenu = 169,
        SalesOrder = 139,
        ARInvoice = 133,
        PurchaseOrder = 142,
        GoodsReceipt = 721,
        InventoryTransfer = 940
    }

    public enum SAPCustomFormUIDEnum
    {
        [Description("Create Production UDO")]
        PROUDO,

        [Description("Production Customization")]
        PRODCUST,

        [Description("Daily Production Plan")]
        DAILYPLAN,

        [Description("Daily Production Plan SFG")]
        DAILYPLANSFG,

        [Description("BarCode Generation and Assignment")]
        BARCODEGEN,

        [Description("Weighing Scale")]
        WEIGHINGSCALE,

        [Description("Weighing Scale QC")]
        WEIGHINGSCALEQC,

        [Description("Weighing Scale QC Parameter")]
        WEIGHINGSCALEQCPAR,

        [Description("Scrap Scale ")]
        SCRAPSCALE,

        [Description("Batch Posting Weighing Scale")]
        BATCHWEIGHINGSCALE,

        [Description("BarCode Selection")]
        BARCODESEL,

        [Description("Gate Pass")]
        GATEPASS,

        [Description("Machine Master")]
        MACHINEMASTER,

        [Description("QC Parameter")]
        QCPARA,

        [Description("QC Specification")]
        QCSPEC,
    }

    public enum SAPCommonFieldEnum
    {
        CardCode,
        ItemCode
    }

    public enum UDFFieldType
    {
        Alpha,
        Text,
        Integer,
        Date,
        Time,
        Amount,
        Quantity,
        Percent,
        UnitTotal,
        Rate,
        Price,
        Link,
        YN,
        Status,
        Activity,
        ActivityStatus,
        QCStastus
    }

    public enum TableType
    {
        StandardTable,
        CustomTable
    }

    public enum SAPCommonMaskModeEnum
    {
        All = -1,
        Ok = 1,
        Add = 2,
        Find = 4,
        View = 8
    }

}
