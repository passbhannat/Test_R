using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;

namespace Order
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;

        clsPO objclsPO = new clsPO();
        clsPrOrder objclsPrOrder = new clsPrOrder();
        clsOrderDist objclsOrderDist = new clsOrderDist();
        clsOrderDist_AC objclsOrderDist_AC = new clsOrderDist_AC();
        clsOrderDist_DC objclsOrderDist_DC = new clsOrderDist_DC();

        clsPO_ItemSelect objclsItemSelect = new clsPO_ItemSelect();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            oForm = oApplication.Forms.GetFormByTypeAndCount(169, 1); // Get reference to the Center form
            //oForm.Freeze(true);
            PrepareMenus();
            //oForm.Freeze(false);
            //oForm.Update();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            string superUser = objclsComman.SelectRecord("SELECT SUPERUSER FROM OUSR WHERE USERID='" + oCompany.UserSignature + "'");
            if (superUser == "Y")
            {
                objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "OUDO", "Create Order OD UDO", 0);
            }

            objclsComman.AddMenu(BoMenuType.mt_POPUP, "2048", "ORDER", "Order Customization", 16);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "ORDER", "ORDDIST", "Order Distrbution", 0);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "ORDER", "ORDDIST_AC", "Order Distrbution Approval/Confirmation", 1);
        }

        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));

            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.RightClickEvent += new _IApplicationEvents_RightClickEventEventHandler(oApplication_RightClickEvent);
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;

                }
                catch { }
                switch (pVal.FormTypeEx)
                {

                    case "ORDDIST":
                        objclsOrderDist.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "ORDDIST_AC":
                        objclsOrderDist_AC.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "ORDDIST_DC":
                        objclsOrderDist_DC.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "142":
                        objclsPO.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "ORDDIST_ITEMSEL":
                        objclsItemSelect.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "65211":
                        objclsPrOrder.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                }
            }
            catch { }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "OUDO")
                {
                    if (pVal.BeforeAction == true)
                    {
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }
                else if (pVal.MenuUID == "CS_RFIELD")
                {
                    objclsComman.LoadFromXML(pVal.MenuUID, "", "");
                }

                if (pVal.MenuUID == "ORDDIST" || oForm.TypeEx == "ORDDIST")
                {
                    objclsOrderDist.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "ORDDIST_AC" || oForm.TypeEx == "ORDDIST_AC")
                {
                    objclsOrderDist_AC.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "ORDDIST_DC" || oForm.TypeEx == "ORDDIST_DC")
                {
                    objclsOrderDist_DC.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message, 1, "Ok", "Cancel", "");
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            switch (BusinessObjectInfo.FormTypeEx)
            {
                case "ORDDIST":
                    objclsOrderDist.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "ORDDIST_AC":
                    objclsOrderDist_AC.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "ORDDIST_DC":
                    objclsOrderDist_DC.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "142":
                    objclsPO.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "65211":
                    objclsPrOrder.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            string processAssemlbly = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(processAssemlbly + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(processAssemlbly + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(processAssemlbly + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(processAssemlbly + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        void oApplication_RightClickEvent(ref ContextMenuInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (eventInfo.BeforeAction == true)
            {
                if (eventInfo.FormUID == "ORDDIST")
                {
                    oForm = oApplication.Forms.Item(eventInfo.FormUID);
                    try
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                        {
                            eventInfo.RemoveFromContent("1292");
                            eventInfo.RemoveFromContent("1293");
                        }

                    }
                    catch { }
                }
            }
        }

        #endregion
    }
}
