using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using General.Extensions;

namespace Order
{
    class clsOrderDist : Connection
    {
        #region Variables

        public SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;

        const string headerTable = "@ORDDIST";
        const string rowTable = "@ORDDIST1";
         
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region SONO
                            if (pVal.ItemUID == "SONO")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string branchQuery = string.Empty;
                                string soDate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_SODate", 0).Trim();
                                if (soDate == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select SO Date", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                sbQuery.Length = 0;
                               
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                sbQuery.Append(" SELECT T0.DOCENTRY FROM ORDR T0 ");
                                sbQuery.Append(" INNER JOIN RDR1 T1 ON T0.DOCENTRY=T1.DOCENTRY ");
                                sbQuery.Append(" WHERE  T0.DOCSTATUS='O'  AND ISNULL(U_ODQTY,0) != QUANTITY ");
                                sbQuery.Append(" AND  T0.DocDate= '" + soDate + "' ");
                                sbQuery.Append(branchQuery);
                                sbQuery.Append(" GROUP BY T0.DOCENTRY ");
                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_SO", "17", sbQuery.ToString(), "DocEntry", alCondVal);
                            }
                            #endregion

                            #region mtx
                            else if (pVal.ItemUID == "mtx")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                //ItemCode
                                if (pVal.ColUID == "V_4")
                                {
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    string SONO = oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_SONO", 0).ToString().Trim();
                                    string SODocE = oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_SODocE", 0).ToString().Trim();
                                    if (SONO == string.Empty)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST").SetValue("U_SODocE", 0, string.Empty);
                                    }
                                    string query = "SELECT ITEMCODE FROM RDR1 WHERE DOCENTRY='" + SODocE + "'";
                                    string Adhoc = oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_Adhoc", 0).ToString().Trim();
                                    if (Adhoc == "Y")
                                    {
                                        objclsComman.AddChooseFromList_WithCond(oForm, "CFL_ITM", "4", string.Empty, "", alCondVal);
                                    }
                                    else
                                    {
                                        objclsComman.AddChooseFromList_WithCond(oForm, "CFL_ITM", "4", query, "", alCondVal);
                                    }
                                }
                                //Child ItemCode
                                else if (pVal.ColUID == "V_11")
                                {
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;

                                    string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).String;
                                    string PlanParent = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row)).Caption;
                                    string query = string.Empty;
                                    if (PlanParent == "Y")
                                    {
                                        query = "SELECT '" + ItemCode + "'";
                                    }
                                    else
                                    {
                                        query = "SELECT CODE FROM ITT1 WHERE FATHER='" + ItemCode + "'";
                                    }
                                    objclsComman.AddChooseFromList_WithCond(oForm, "CFL_ITMC", "4", query, "", alCondVal);
                                }
                            }
                            #endregion

                            #region Port
                            else if (pVal.ItemUID == "Port")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardName = string.Empty;
                                CardName = oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_CardCode", 0).ToString();

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_CUSTNAME"); //Condition Alias             
                                temp.Add(CardName); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);



                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_PORT", "PORT", "", "", alCondVal);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string Adhoc = oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_Adhoc", 0).ToString().Trim();
                                    if (Adhoc != "Y")
                                    {
                                        if (oForm.DataSources.DBDataSources.Item("@ORDDIST").GetValue("U_CardCode", 0).ToString().Trim() == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }


                                    for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                    {
                                        string Decision = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_7", i)).Value.Trim();
                                        if (Decision == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Select the Decision for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }

                                        double PlanQty = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).String);
                                        if (PlanQty == 0)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Planed quantity can't be 0 for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }

                                        if (Adhoc != "Y")
                                        {
                                            double AvailableQty = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).String);
                                            //if (AvailableQty == 0)
                                            //{
                                            //    BubbleEvent = false;
                                            //    oApplication.StatusBar.SetText("Available quantity is 0 for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            //    return;
                                            //}
                                            //if (PlanQty > (AvailableQty * -1))
                                            //{
                                            //    BubbleEvent = false;
                                            //    oApplication.StatusBar.SetText("Planed quantity is exceeded for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            //    return;
                                            //}
                                        }

                                    }


                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion


                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("OD Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_SO")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST");
                                oDbDataSource.SetValue("U_SONO", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                oDbDataSource.SetValue("U_SODocE", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                                DateTime DueDate = DateTime.Parse(oDataTable.GetValue("DocDueDate", 0).ToString());

                                oDbDataSource.SetValue("U_DueDate", 0, DueDate.ToString("yyyyMMdd"));

                                string DRefNo = oDataTable.GetValue("DocNum", 0).ToString() + oForm.DataSources.DBDataSources.Item(0).GetValue("DocNum", 0);
                                oDbDataSource.SetValue("U_DRefNo", 0, DRefNo);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.Clear();
                                oMatrix.AddRow(1, 1);
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITM")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());
                                string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).Trim();

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT LINENUM,SHIPDATE FROM RDR1 WHERE DOCENTRY='" + DocEntry + "' AND ITEMCODE='" + oDataTable.GetValue("ItemCode", 0).ToString() + "'");
                                try
                                {
                                    if (oRs.RecordCount > 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_BaseLine", pVal.Row - 1, oRs.Fields.Item("LINENUM").Value.ToString());
                                        DateTime DueDate = DateTime.Parse(oRs.Fields.Item("SHIPDATE").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_DueDate", pVal.Row - 1, DueDate.ToString("yyyyMMdd"));
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.boolCFLSelected = true;
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;

                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITMC")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();



                                string ItemCode = oDataTable.GetValue("ItemCode", 0).ToString();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemCod", pVal.Row - 1, ItemCode);
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemNam", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());

                                string OnHand = objclsComman.SelectRecord("SELECT T1.OnHand FROM OITM T0 INNER JOIN OITW T1 ON T0.ItemCode=T1.ItemCode AND T0.DfltWH=T1.WhsCode WHERE T0.ITEMCODE='" + oDataTable.GetValue("ItemCode", 0).ToString() + "'");
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_InStock", pVal.Row - 1, OnHand);

                                Get_RequiredQty(oForm, ItemCode, pVal.Row);
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_11").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.boolCFLSelected = true;
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_CARD")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_PrefVCod", pVal.Row - 1, oDataTable.GetValue("CardCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_PrefVNam", pVal.Row - 1, oDataTable.GetValue("CardName", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_2").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);

                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.boolCFLSelected = true;
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WHS")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_PrefWhs", pVal.Row - 1, oDataTable.GetValue("WhsCode", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_12").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.boolCFLSelected = true;
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            try
                            {
                                if (pVal.FormUID == "ORDDIST")
                                {

                                    if (clsVariables.boolCFLSelected)
                                    {
                                        clsVariables.boolCFLSelected = false;
                                        oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                        oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                        clsVariables.RowNo = 0;
                                        clsVariables.ColNo = 0;
                                    }
                                }
                            }
                            catch
                            {

                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                if (pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    string Code = oForm.DataSources.DBDataSources.Item(0).GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        //AutoCode(oForm);

                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "mtx"
                            else if (pVal.ItemUID == "mtx")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.Row == -1)
                                {
                                    return;
                                }
                                if (pVal.ColUID == "V_9")
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    string PlanParent = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row)).Caption;
                                    string SODocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).ToString();
                                    string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).String;
                                    //string ReqQty = objclsComman.SelectRecord("SELECT QUANTITY FROM RDR1 WHERE DOCENTRY='" + SODocE + "' AND ITEMCODE='" + ItemCode + "'");

                                    if (PlanParent == "Y")
                                    {
                                        string ItemName = objclsComman.SelectRecord("SELECT ITEMNAME FROM OITM WHERE ITEMCODE='" + ItemCode + "'");
                                        oMatrix.FlushToDataSource();
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemCod", pVal.Row - 1, ItemCode.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemNam", pVal.Row - 1, ItemName.ToString());
                                        string OnHand = objclsComman.SelectRecord("SELECT T1.OnHand FROM OITM T0 INNER JOIN OITW T1 ON T0.ItemCode=T1.ItemCode AND T0.DfltWH=T1.WhsCode WHERE T0.ITEMCODE='" + ItemCode + "'");

                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_InStock", pVal.Row - 1, OnHand);

                                        //oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ReqQty", pVal.Row - 1, ReqQty.ToString());
                                        Get_RequiredQty(oForm, ItemCode, pVal.Row);
                                        oMatrix.LoadFromDataSource();
                                    }
                                    else
                                    {
                                        oMatrix.FlushToDataSource();
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemCod", pVal.Row - 1, string.Empty);
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_CItemNam", pVal.Row - 1, string.Empty);
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ReqQty", pVal.Row - 1, "0");
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_AvQty", pVal.Row - 1, "0");
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_InStock", pVal.Row - 1, "0");

                                        oMatrix.LoadFromDataSource();
                                    }
                                }
                            }
                            #endregion

                            #region Adhoc CheckBox
                            else if (pVal.ItemUID == "Adhoc")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Adhoc = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Adhoc", 0).Trim();
                                ((SAPbouiCOM.EditText)(oForm.Items.Item("DRefNo").Specific)).Active = true;

                                if (Adhoc == "Y")
                                {
                                    oForm.Items.Item("SONO").Enabled = false;
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_SONO", 0, string.Empty);
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_DRefNo", 0, string.Empty);
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_CardCode", 0, string.Empty);
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_CardName", 0, string.Empty);
                                }
                                else
                                {
                                    oForm.Items.Item("SONO").Enabled = true;
                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "ORDDIST").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                            //AutoCode(oForm);
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion


                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            #region DocDate
                            if (pVal.ItemUID == "DocDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                }

                            }
                            #endregion
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("OD Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("OD Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                   
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "ORDDIST" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@ORDDIST1").GetValue("U_ItemCode", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@ORDDIST1").GetValue("U_ItemCode", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@ORDDIST1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if ((BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE))
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DOCENTRY", 0);
                        objclsComman.SelectRecord("DELETE FROM [@ORDDIST1] WHERE U_ITEMCODE IS NULL AND DOCENTRY='" + DocEntry + "'");

                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            objclsComman.SelectRecord("UPDATE [@ORDDIST1] SET U_OpenQty=U_PlanQty WHERE DOCENTRY='" + DocEntry + "'");

                            string Adhoc = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Adhoc", 0).ToString().Trim();
                            string DRefNo = string.Empty;
                            if (Adhoc == "Y")
                            {

                                //DRefNo ="AD-"+ oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0) + "-"+ oForm.DataSources.DBDataSources.Item(0).GetValue("DocNum", 0);
                            }
                            else
                            {
                                DRefNo = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SONO", 0) + oForm.DataSources.DBDataSources.Item(0).GetValue("DocNum", 0);
                                objclsComman.SelectRecord("UPDATE [@ORDDIST] SET U_DRefNo='" + DRefNo + "' WHERE DOCENTRY='" + DocEntry + "'");

                                objclsComman.SelectRecord("UPDATE T0 SET U_ODQTY = ISNULL(U_ODQTY,0) + T2.U_ReqQty FROM  RDR1 T0 INNER JOIN [@ORDDIST] T1 ON T0.DOCENTRY=T1.U_SODOCE INNER JOIN [@ORDDIST1] T2 ON T2.U_BaseLine = T0.LineNum WHERE T1.DOCENTRY='" + DocEntry + "'");

                            }

                        }

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");



                    }
                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method


        private void LoadForm(string MenuID)
        {
            if (MenuID == "ORDDIST")
            {
                // objclsComman.LoadFromXML(MenuID, "DocEntry", "A");
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                oForm = oApplication.Forms.ActiveForm;

                clsVariables.boolCFLSelected = false;

                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false);//Remove
                oForm.EnableMenu("1286", false);//Close
                oForm.EnableMenu("4870", false);//Filter Table
                oForm.EnableMenu("1285", false);//Restore

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                

                string ReportType = objclsComman.SelectRecord("SELECT CODE FROM RTYP WHERE MNU_ID='" + MenuID + "' ");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_7", 1);
                objclsComman.FillCombo(oCombo, "SELECT T1.FLDVALUE,T1.DESCR FROM CUFD T0  INNER JOIN UFD1 T1 ON T0.TABLEID=T1.TABLEID AND T0.FIELDID=T1.FIELDID WHERE ALIASID='DECISION' AND T0.TABLEID='@ORDDIST1'");

                oMatrix.CommonSetting.EnableArrowKey = true;

                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Customer Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("S"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_CARD", "2", "", "", alCondVal);

                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("121"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("124"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                //temp.Add("InvntItem"); //Condition Alias             
                //temp.Add("N"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);
                //StringBuilder sb = new StringBuilder();
                //sb.Append(" SELECT ITEMCODE FROM OITM T0 INNER JOIN OITB T1 ON T0.ITMSGRPCOD=T1.ITMSGRPCOD ");
                //sb.Append("WHERE T1.ITMSGRPNAM LIKE '%SOG FG%' AND InvntItem='N'");

                //objclsComman.AddChooseFromList_WithCond(oForm, "CFL_FG", "4", sb.ToString(), "ItemCode", null);
                //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("ItemCode").Specific;
                //oEdit.ChooseFromListUID = "CFL_FG";
                //oEdit.ChooseFromListAlias = "ItemCode";
                #endregion


            }
            oForm = oApplication.Forms.ActiveForm;


            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "ORDDIST").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion

            oForm.DataSources.DBDataSources.Item(0).SetValue("U_Owner", 0, oCompany.UserName);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }


            //oItem = oForm.Items.Item("CardCode");
            //objclsComman.SetAutoManagedAttribute_AddMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Status");
            objclsComman.SetAutoManagedAttribute(oItem);


            oItem = oForm.Items.Item("Canceled");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("SONO");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("SODate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("DRefNo");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("mtx");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
            oEdit.String = "t";
            oForm.Select();


        }




        private void Get_RequiredQty(SAPbouiCOM.Form oForm, string ItemCode, int Row)
        {
            string SODocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).ToString();
            //string ItemCode = oDataTable.GetValue("ItemCode", 0).ToString();
            string ParentItemCode = oForm.DataSources.DBDataSources.Item("@ORDDIST1").GetValue("U_ItemCode", Row - 1).Trim();

            string ReqQty = objclsComman.SelectRecord("SELECT QUANTITY-ISNULL(U_ODQTY,0) FROM RDR1 WHERE DOCENTRY='" + SODocE.Trim() + "' AND ITEMCODE='" + ParentItemCode + "'");
            string ConfirmedQty = objclsComman.SelectRecord("SELECT SUM(T1.U_APQTY) FROM [@ORDDIST_AC] T0 INNER JOIN  [@ORDDIST_AC1] T1 ON T0.DOCENTRY=T1.DOCENTRY " +
                " WHERE T0.U_SODOCE='" + SODocE.Trim() + "' AND T1.U_CItemCod='" + ItemCode + "' AND T0.CANCELED='N'");

            ReqQty = ReqQty == string.Empty ? "0" : ReqQty;
            ConfirmedQty = ConfirmedQty == string.Empty ? "0" : ConfirmedQty;

            double dbl_ReqQty = ((-1) * double.Parse(ReqQty)) + double.Parse(ConfirmedQty);

            string ParenPlan = oForm.DataSources.DBDataSources.Item("@ORDDIST1").GetValue("U_PParent", Row - 1);
            if (ParenPlan == "Y")
            {
                //oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ReqQty", Row - 1, ((-1) * double.Parse(ReqQty)).ToString());
                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ReqQty", Row - 1, (double.Parse(ReqQty)).ToString());
                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_AvQty", Row - 1, dbl_ReqQty.ToString());

            }
            else
            {
                string previousPlanQty = objclsComman.SelectRecord("SELECT SUM(T1.U_PlanQty) FROM [@ORDDIST] T0 INNER JOIN  [@ORDDIST1] T1 ON T0.DOCENTRY=T1.DOCENTRY " +
               " WHERE T0.U_SODOCE='" + SODocE.Trim() + "' AND T1.U_ItemCode ='" + ParentItemCode + "' AND T1.U_CItemCod='" + ItemCode + "' AND T0.CANCELED='N'");
                double dblPreviousPlanQty = previousPlanQty == string.Empty ? 0 : double.Parse(previousPlanQty);

                string previousReqQty = objclsComman.SelectRecord("SELECT T1.U_ReqQty FROM [@ORDDIST] T0 INNER JOIN  [@ORDDIST1] T1 ON T0.DOCENTRY=T1.DOCENTRY " +
               " WHERE T0.U_SODOCE='" + SODocE.Trim() + "' AND T1.U_ItemCode ='" + ParentItemCode + "' AND T1.U_CItemCod='" + ItemCode + "' AND T0.CANCELED='N'");
                double dblPreviousReqQty = previousReqQty == string.Empty ? 0 : double.Parse(previousReqQty);

                double dbl_AvgQty = 0;
                if (dblPreviousPlanQty > 0)
                {
                    dbl_ReqQty = dblPreviousReqQty - dblPreviousPlanQty;
                    dbl_AvgQty = ((-1) * dbl_ReqQty) + double.Parse(ConfirmedQty);
                }
                else
                {
                    string Quantity = objclsComman.SelectRecord(" SELECT QUANTITY FROM ITT1 WHERE FATHER='" + ParentItemCode + "' AND CODE='" + ItemCode + "'");
                    Quantity = Quantity == string.Empty ? "1" : Quantity;
                    dbl_ReqQty = double.Parse(ReqQty) * double.Parse(Quantity);
                    dbl_AvgQty = ((-1) * dbl_ReqQty) + double.Parse(ConfirmedQty);
                }
                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_ReqQty", Row - 1, dbl_ReqQty.ToString());
                oForm.DataSources.DBDataSources.Item("@ORDDIST1").SetValue("U_AvQty", Row - 1, dbl_AvgQty.ToString());

            }
        }

        #endregion
    }
}
