using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General.Extensions;

namespace Order
{
    class clsOrderDist_AC : Connection
    {
        #region Variables
        public SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        StringBuilder sbQuery = new StringBuilder();
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;

        public const string objType = "ORDDIST_AC";
        public const string headerTable = "@ORDDIST_AC";
        public const string rowTable = "@ORDDIST_AC1";
        const string branchUDF = "U_BPLId";
        const string branchUID = "BPLId";

        #endregion

        #region Events
        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region SONO
                            if (pVal.ItemUID == "SONO")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string branchQuery = string.Empty;
                                string soDate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_SODate", 0).Trim();
                                if (soDate == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select SO Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                if (isBranchDatabase == "Y")
                                {
                                    string branchID = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(branchUDF, 0).Trim();
                                    if (string.IsNullOrEmpty(branchID))
                                    {
                                        oApplication.StatusBar.SetText("Please select branch", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    branchQuery = " AND T0.U_BPLID = '" + branchID + "'";
                                }

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                //temp = new ArrayList();
                                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                //temp.Add("DocStatus"); //Condition Alias             
                                //temp.Add("O"); //Condition Value
                                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                //alCondVal.Add(temp);

                                sbQuery.Length = 0;
                                sbQuery.Append("SELECT U_SODOCE FROM [@ORDDIST] T0 WHERE U_DRefNo IS NOT NULL AND U_SODATE = '" + soDate + "'");
                                sbQuery.Append(branchQuery);
                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_SO", "17", sbQuery.ToString(), "DocEntry", alCondVal);
                            }
                            #endregion

                            #region DRefNo
                            else if (pVal.ItemUID == "DRefNo")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                string SODocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).Trim();
                                string SODocNo = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SONO", 0).Trim();
                                string Adhoc = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Adhoc", 0).Trim();

                                string query = string.Empty;
                                if (Adhoc == "Y")
                                {
                                    query = "SELECT T0.U_DRefNo FROM [@ORDDIST] T0  WHERE T0.U_Adhoc='Y' AND T0.U_DRefNo IS NOT NULL and status='O' " +
                                           " AND NOT EXISTS (SELECT * FROM [@ORDDIST_AC] A WHERE T0.U_DRefNo=A.U_DRefNo )";
                                }
                                else
                                {
                                    if (SODocNo == string.Empty)
                                    {
                                        query = "SELECT '0'";
                                    }
                                    else
                                    {
                                        // query = "SELECT U_DRefNo FROM [@ORDDIST] WHERE U_SODocE='" + SODocEntry + "' AND U_DRefNo IS NOT NULL and status='O'";
                                        query = "SELECT T0.U_DRefNo FROM [@ORDDIST] T0  WHERE ISNULL(T0.U_Adhoc,'N')='N' AND T0.U_SODocE='" + SODocEntry + "' AND T0.U_DRefNo IS NOT NULL and t0.status='O' ";
                                        //   " AND NOT EXISTS (SELECT * FROM [@ORDDIST_AC] A WHERE T0.U_SODocE=A.U_SODocE AND  T0.U_DRefNo=A.U_DRefNo )";
                                    }
                                }


                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_DR", "ORDDIST", query, "U_DRefNo", alCondVal);
                            }
                            #endregion

                            #region mtx
                            else if (pVal.ItemUID == "mtx")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                //ItemCode
                                if (pVal.ColUID == "V_4")
                                {
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    string SODocE = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").GetValue("U_SODocE", 0).ToString();
                                    string query = "SELECT ITEMCODE FROM RDR1 WHERE DOCENTRY='" + SODocE + "'";

                                    objclsComman.AddChooseFromList_WithCond(oForm, "CFL_ITM", "4", query, "", alCondVal);
                                }
                                //Child ItemCode
                                else if (pVal.ColUID == "V_11")
                                {
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;

                                    string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).String;
                                    string PlanParent = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row)).Caption;
                                    string query = string.Empty;
                                    if (PlanParent == "Y")
                                    {
                                        query = "SELECT '" + ItemCode + "'";
                                    }
                                    else
                                    {
                                        query = "SELECT CODE FROM ITT1 WHERE FATHER='" + ItemCode + "'";
                                    }
                                    objclsComman.AddChooseFromList_WithCond(oForm, "CFL_ITMC", "4", query, "", alCondVal);
                                }
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string Adhoc = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Adhoc", 0).ToString().Trim();
                                    if (Adhoc != "Y")
                                    {
                                        if (oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").GetValue("U_CardCode", 0).ToString().Trim() == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                    {
                                        double PlanQty = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).String);
                                        double ApprQty = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_0", i)).String);
                                        if (ApprQty == 0)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Available quantity is 0 for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        if (PlanQty < ApprQty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Approved quantity is exceeded for Row: " + i.ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }


                                    }

                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                           
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("OD Item Event Before_Action=true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_SO")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC");
                                oDbDataSource.SetValue("U_SONO", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                oDbDataSource.SetValue("U_SODocE", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                                //oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                //oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                                //DateTime DueDate = DateTime.Parse(oDataTable.GetValue("DocDueDate", 0).ToString());

                                //oDbDataSource.SetValue("U_DueDate", 0, DueDate.ToString("yyyyMMdd"));

                                //string DRefNo = oDataTable.GetValue("DocNum", 0).ToString() + oForm.DataSources.DBDataSources.Item(0).GetValue("DocNum", 0);
                                //oDbDataSource.SetValue("U_DRefNo", 0, DRefNo);
                                //int Row = 0;

                                //oDbDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1");
                                //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                //oMatrix.Clear();
                                //oMatrix.FlushToDataSource();

                                //oRs = objclsComman.returnRecord("SELECT * FROM RDR1 WHERE DOCENTRY='" + oDataTable.GetValue("DocEntry", 0).ToString() + "'");
                                //if (oRs.RecordCount == 0)
                                //{
                                //    return;
                                //}
                                //while (!oRs.EoF)
                                //{
                                //    oDbDataSource.InsertRecord(Row + 1);

                                //    oDbDataSource.SetValue("U_ItemCode", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                                //    oDbDataSource.SetValue("U_ItemName", Row, oRs.Fields.Item("Dscription").Value.ToString());
                                //    oDbDataSource.SetValue("U_BaseKey", Row, oRs.Fields.Item("DocEntry").Value.ToString());
                                //    oDbDataSource.SetValue("U_BaseLine", Row, oRs.Fields.Item("LineNum").Value.ToString());
                                //    oDbDataSource.SetValue("U_BaseType", Row, oRs.Fields.Item("ObjType").Value.ToString());

                                //    Row++;

                                //    oRs.MoveNext();
                                //}
                                //oMatrix.LoadFromDataSource();

                            }

                            if (oCFLEvento.ChooseFromListUID == "CFL_DR")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC");
                                oDbDataSource.SetValue("U_DRefNo", 0, oDataTable.GetValue("U_DRefNo", 0).ToString());

                                string DocEntry = oDataTable.GetValue("DocEntry", 0).ToString();
                                //oDbDataSource.SetValue("U_SONO", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                //oDbDataSource.SetValue("U_SODocE", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                                //oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                //oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                                //DateTime DueDate = DateTime.Parse(oDataTable.GetValue("DocDueDate", 0).ToString());

                                //oDbDataSource.SetValue("U_DueDate", 0, DueDate.ToString("yyyyMMdd"));

                                int Row = 0;

                                SAPbouiCOM.DBDataSource oDbDataSource1 = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1");
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.Clear();
                                oMatrix.FlushToDataSource();
                                DateTime DueDate;
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT U_CardCode,U_CardName,T0.U_DueDate [H_DueDate],U_ItemCode" +
                                    " ,U_ItemName,U_BaseKey,U_BaseLine,U_BaseType" +
                                    " ,T0.DocEntry,LineID,T0.Object" +
                                    " ,U_PParent,U_CItemCod,U_CItemNam,U_Decision,U_ReqQty,U_OpenQty ,U_PrefVCod,U_PrefVNam,U_PrefWhs" +
                                    " ,T1.U_DueDate,T1.U_Remarks" +
                                    " FROM [@ORDDIST] T0 INNER JOIN [@ORDDIST1] T1 ON T0.DOCENTRY=T1.DOCENTRY " +
                                    " WHERE T0.DOCENTRY='" + oDataTable.GetValue("DocEntry", 0).ToString() + "' AND U_OpenQty>0");
                                try
                                {
                                    if (oRs.RecordCount == 0)
                                    {
                                        return;
                                    }
                                    while (!oRs.EoF)
                                    {
                                        oDbDataSource1.InsertRecord(Row + 1);
                                        if (Row == 0)
                                        {
                                            oDbDataSource.SetValue("U_CardCode", Row, oRs.Fields.Item("U_CardCode").Value.ToString());
                                            oDbDataSource.SetValue("U_CardName", Row, oRs.Fields.Item("U_CardName").Value.ToString());
                                            DueDate = DateTime.Parse(oRs.Fields.Item("H_DueDate").Value.ToString());
                                            oDbDataSource.SetValue("U_DueDate", 0, DueDate.ToString("yyyyMMdd"));
                                        }
                                        oDbDataSource1.SetValue("U_ItemCode", Row, oRs.Fields.Item("U_ItemCode").Value.ToString());
                                        oDbDataSource1.SetValue("U_ItemName", Row, oRs.Fields.Item("U_ItemName").Value.ToString());
                                        oDbDataSource1.SetValue("U_BaseKey", Row, oRs.Fields.Item("DocEntry").Value.ToString());
                                        oDbDataSource1.SetValue("U_BaseLine", Row, oRs.Fields.Item("LineID").Value.ToString());
                                        oDbDataSource1.SetValue("U_BaseType", Row, oRs.Fields.Item("Object").Value.ToString());
                                        oDbDataSource1.SetValue("U_PParent", Row, oRs.Fields.Item("U_PParent").Value.ToString());
                                        oDbDataSource1.SetValue("U_CItemCod", Row, oRs.Fields.Item("U_CItemCod").Value.ToString());
                                        oDbDataSource1.SetValue("U_CItemNam", Row, oRs.Fields.Item("U_CItemNam").Value.ToString());
                                        oDbDataSource1.SetValue("U_Decision", Row, oRs.Fields.Item("U_Decision").Value.ToString());
                                        oDbDataSource1.SetValue("U_ReqQty", Row, oRs.Fields.Item("U_ReqQty").Value.ToString());
                                        oDbDataSource1.SetValue("U_PlanQty", Row, oRs.Fields.Item("U_OpenQty").Value.ToString());
                                        oDbDataSource1.SetValue("U_PrefVCod", Row, oRs.Fields.Item("U_PrefVCod").Value.ToString());
                                        oDbDataSource1.SetValue("U_PrefVNam", Row, oRs.Fields.Item("U_PrefVNam").Value.ToString());
                                        oDbDataSource1.SetValue("U_PrefWhs", Row, oRs.Fields.Item("U_PrefWhs").Value.ToString());
                                        oDbDataSource1.SetValue("U_Remarks", Row, oRs.Fields.Item("U_Remarks").Value.ToString());

                                        oDbDataSource1.SetValue("U_SOLine", Row, oRs.Fields.Item("U_BaseLine").Value.ToString());


                                        DueDate = DateTime.Parse(oRs.Fields.Item("U_DueDate").Value.ToString());
                                        oDbDataSource1.SetValue("U_DueDate", Row, DueDate.ToString("yyyyMMdd"));



                                        Row++;
                                        oRs.MoveNext();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }
                                oMatrix.LoadFromDataSource();
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITM")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITMC")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                string SODocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).ToString();
                                string ItemCode = oDataTable.GetValue("ItemCode", 0).ToString();
                                string ParentItemCode = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_ItemCode", pVal.Row - 1);

                                string ReqQty = objclsComman.SelectRecord("SELECT QUANTITY FROM RDR1 WHERE DOCENTRY='" + SODocE.Trim() + "' AND ITEMCODE='" + ParentItemCode + "'");
                                ReqQty = ReqQty == string.Empty ? "0" : ReqQty;
                                string ParenPlan = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_PParent", pVal.Row - 1);


                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemCod", pVal.Row - 1, ItemCode);
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemNam", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());
                                if (ParenPlan == "Y")
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ReqQty", pVal.Row - 1, ReqQty.ToString());
                                }
                                else
                                {
                                    string Quantity = objclsComman.SelectRecord(" SELECT QUANTITY FROM ITT1 WHERE FATHER='" + ParentItemCode + "' AND CODE='" + ItemCode + "'");
                                    ReqQty = Convert.ToString(double.Parse(ReqQty) * double.Parse(Quantity));
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ReqQty", pVal.Row - 1, ReqQty.ToString());
                                }
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_11").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_CARD")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_PrefVCod", pVal.Row - 1, oDataTable.GetValue("CardCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_PrefVNam", pVal.Row - 1, oDataTable.GetValue("CardName", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_2").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WHS")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_PrefWhs", pVal.Row - 1, oDataTable.GetValue("WhsCode", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_12").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormUID == "ORDDIST_AC")
                            {
                                try
                                {

                                    if (clsVariables.boolCFLSelected)
                                    {
                                        clsVariables.boolCFLSelected = false;
                                        oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                        oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                        clsVariables.RowNo = 0;
                                        clsVariables.ColNo = 0;
                                    }
                                }
                                catch { }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                if (pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    string Code = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        //AutoCode(oForm);

                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "mtx"
                            else if (pVal.ItemUID == "mtx")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.Row == -1)
                                {
                                    return;
                                }
                                if (pVal.ColUID == "V_9")
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    string PlanParent = ((SAPbouiCOM.CheckBox)oMatrix.GetCellSpecific("V_9", pVal.Row)).Caption;
                                    string SODocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SODocE", 0).ToString();
                                    string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", pVal.Row)).String;
                                    string ReqQty = objclsComman.SelectRecord("SELECT QUANTITY FROM RDR1 WHERE DOCENTRY='" + SODocE + "' AND ITEMCODE='" + ItemCode + "'");

                                    if (PlanParent == "Y")
                                    {
                                        string ItemName = objclsComman.SelectRecord("SELECT ITEMNAME FROM OITM WHERE ITEMCODE='" + ItemCode + "'");
                                        oMatrix.FlushToDataSource();
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemCod", pVal.Row - 1, ItemCode.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemNam", pVal.Row - 1, ItemName.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ReqQty", pVal.Row - 1, ReqQty.ToString());

                                        oMatrix.LoadFromDataSource();
                                    }
                                    else
                                    {
                                        oMatrix.FlushToDataSource();
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemCod", pVal.Row - 1, string.Empty);
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_CItemNam", pVal.Row - 1, string.Empty);
                                        oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_ReqQty", pVal.Row - 1, "0");

                                        oMatrix.LoadFromDataSource();
                                    }
                                }
                            }
                            #endregion

                            #region Adhoc CheckBox
                            else if (pVal.ItemUID == "Adhoc")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Adhoc = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Adhoc", 0).Trim();
                                ((SAPbouiCOM.EditText)(oForm.Items.Item("DRefNo").Specific)).Active = true;

                                if (Adhoc == "Y")
                                {
                                    oForm.Items.Item("SONO").Enabled = false;

                                }
                                else
                                {
                                    oForm.Items.Item("SONO").Enabled = true;
                                }
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_SONO", 0, string.Empty);
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_DRefNo", 0, string.Empty);
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_CardCode", 0, string.Empty);
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_CardName", 0, string.Empty);

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Clear();
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                        }
                        #endregion


                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "ORDDIST_AC").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                            //AutoCode(oForm);
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion


                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            #region DocDate
                            if (pVal.ItemUID == "DocDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                }

                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("OD Item Event Before_Action=false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("OD Item Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                  
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "ORDDIST_AC" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_ItemCode", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_ItemCode", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            BubbleEvent = true;
            try
            {

                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if ((BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE))
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DOCENTRY", 0);
                        objclsComman.SelectRecord("DELETE FROM [@ORDDIST_AC1] WHERE U_ITEMCODE IS NULL AND DOCENTRY='" + DocEntry + "'");
                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            objclsComman.SelectRecord("UPDATE [@ORDDIST_AC1] SET U_OpenQty=U_APQty WHERE DOCENTRY='" + DocEntry + "'");

                            StringBuilder sbQuery = new StringBuilder();
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_OpenQty= T0.U_OpenQty-T1.U_APQty ");
                            sbQuery.Append(" FROM [@ORDDIST1] T0 ");
                            sbQuery.Append(" INNER JOIN [@ORDDIST_AC1] T1 ON T0.DocEntry=T1.U_BaseKey AND T0.LineId=T1.U_BaseLine ");
                            sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                            objclsComman.SelectRecord(sbQuery.ToString());

                            string BaseEntry = objclsComman.SelectRecord("SELECT U_BASEKEY FROM [@ORDDIST_AC1] WHERE DOCENTRY='" + DocEntry + "' AND U_BASEKEY IS NOT NULL");


                            sbQuery = new StringBuilder();
                            sbQuery.Append(" IF NOT EXISTS(SELECT DOCENTRY FROM [@ORDDIST1] WHERE DocEntry='" + BaseEntry + "' AND ISNULL(U_OpenQty,0)!=0) ");
                            sbQuery.Append(" BEGIN ");
                            sbQuery.Append(" UPDATE [@ORDDIST] SET STATUS='C' WHERE DOCENTRY='" + BaseEntry + "'");
                            sbQuery.Append(" END");
                            objclsComman.SelectRecord(sbQuery.ToString());


                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");
                        oItem = oForm.Items.Item("mtx");
                        objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
                    }
                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method


        private void LoadForm(string MenuID)
        {
            if (MenuID == "ORDDIST_AC")
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                oForm = oApplication.Forms.ActiveForm;

                clsVariables.boolCFLSelected = false;

                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false);//Remove
                oForm.EnableMenu("1286", false);//Close
                oForm.EnableMenu("4870", false);//Filter Table
                oForm.EnableMenu("1292", false);//Add Row
                oForm.EnableMenu("1293", false);//Delete Row
                oForm.EnableMenu("1285", false);//Restore

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(branchUID).Specific;
                if (isBranchDatabase == "Y")
                {
                    objclsComman.FillCombo(oCombo, "SELECT T0.[BPLId], T0.[BPLName] FROM OBPL T0");
                    objclsComman.SetAutoManagedAttribute_UpdateMode(oCombo.Item);
                }
                else
                {
                    oCombo.Item.Disable();
                }
                string ReportType = objclsComman.SelectRecord("SELECT CODE FROM RTYP WHERE MNU_ID='" + MenuID + "' ");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_7", 1);
                objclsComman.FillCombo(oCombo, "SELECT T1.FLDVALUE,T1.DESCR FROM CUFD T0  INNER JOIN UFD1 T1 ON T0.TABLEID=T1.TABLEID AND T0.FIELDID=T1.FIELDID WHERE ALIASID='DECISION' AND T0.TABLEID='@ORDDIST1'");

                oMatrix.CommonSetting.EnableArrowKey = true;

                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Customer Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("S"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_CARD", "2", "", "", alCondVal);

                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("121"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("124"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                //temp.Add("InvntItem"); //Condition Alias             
                //temp.Add("N"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);
                //StringBuilder sb = new StringBuilder();
                //sb.Append(" SELECT ITEMCODE FROM OITM T0 INNER JOIN OITB T1 ON T0.ITMSGRPCOD=T1.ITMSGRPCOD ");
                //sb.Append("WHERE T1.ITMSGRPNAM LIKE '%SOG FG%' AND InvntItem='N'");

                //objclsComman.AddChooseFromList_WithCond(oForm, "CFL_FG", "4", sb.ToString(), "ItemCode", null);
                //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("ItemCode").Specific;
                //oEdit.ChooseFromListUID = "CFL_FG";
                //oEdit.ChooseFromListAlias = "ItemCode";
                #endregion


            }


            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "ORDDIST_AC").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion

            oForm.DataSources.DBDataSources.Item(0).SetValue("U_Owner", 0, oCompany.UserName);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }


            //oItem = oForm.Items.Item("CardCode");
            //objclsComman.SetAutoManagedAttribute_AddMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Canceled");
            objclsComman.SetAutoManagedAttribute(oItem);


            oItem = oForm.Items.Item("SONO");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("SODate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("DRefNo");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("Status");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("BPLId");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            //oItem = oForm.Items.Item("mtx");
            //objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
            oEdit.String = "t";
            oForm.Select();
        }




        public void Calc_DetailFields(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double NoCrat = 0;
            double TotalNoCrat = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            double Amount = 0;
            double TotalAmount = 0;
            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").Size; i++)
            {
                try
                {
                    //  Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", i)).ToString());
                    NoCrat = double.Parse(oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_NoCrat", i - 1).ToString());
                    TotalNoCrat = TotalNoCrat + NoCrat;

                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_Netwt", i - 1).ToString());
                    TotalNetwt = TotalNetwt + (Netwt * NoCrat);

                    GrsWt = double.Parse(oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_GrsWt", i - 1).ToString());
                    TotalGrsWt = TotalGrsWt + (GrsWt * NoCrat);

                    Amount = double.Parse(oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").GetValue("U_Amount", i - 1).ToString());
                    TotalAmount = TotalAmount + Amount;

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                }
            }
            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").SetValue("U_TotCrat", 0, TotalNoCrat.ToString());
            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());
            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").SetValue("U_Total", 0, TotalAmount.ToString());

        }


        private void Calc_Amount(SAPbouiCOM.Form oForm, int Row)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double Quantity = 0;
            double Rate = 0;
            double Total = 0;
            double TotalAmount = 0;
            oMatrix.FlushToDataSource();
            Quantity = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", Row)).String);
            Rate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", Row)).String);
            Total = Quantity * Rate;
            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC1").SetValue("U_Amount", Row - 1, Total.ToString());
            oMatrix.LoadFromDataSource();

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {

                Quantity = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).String);
                Rate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", i)).String);
                Total = Quantity * Rate;
                //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_1", i)).String = Total.ToString();

                TotalAmount = TotalAmount + Total;
            }

            oForm.DataSources.DBDataSources.Item("@ORDDIST_AC").SetValue("U_Total", 0, TotalAmount.ToString());

        }


        #endregion
    }
}
