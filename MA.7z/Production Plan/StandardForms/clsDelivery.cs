using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Production_PRM
{
    class clsDelivery : Connection
    {
        #region Variables
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        SAPbobsCOM.Recordset oRs;
        SAPbouiCOM.DataTable oDataTable = null;
        SAPbouiCOM.Column oColumn;

        const string branchUDF = "BPLId";
        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btnCRate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string docDate = ((SAPbouiCOM.EditText)oForm.Items.Item("10").Specific).Value;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                int k = oApplication.MessageBox("Do you really want to copy rate?", 1, "Yes", "No", "");
                                if (k == 1)
                                {
                                    for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                    {
                                        string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                        string rateType = objclsComman.SelectRecord("SELECT U_RateType FROM OITM WHERE ItemCode= '" + itemCode + "'");
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT T1.U_RateInKg FROM [@RATE_CHART] T0 ");
                                        sbQuery.Append(" INNER JOIN [@RATE_CHART1] T1 ON T0.Code = T1.Code ");
                                        sbQuery.Append(" WHERE T1.U_RateType = '" + rateType + "' AND U_Select='Y' ");
                                        sbQuery.Append(" AND '" + docDate + "' BETWEEN T1.U_ValidFr AND ISNULL(T1.U_ValidTo,'9999-12-31') ");
                                        string rateInKgs = objclsComman.SelectRecord(sbQuery.ToString());
                                        rateInKgs = rateInKgs == string.Empty ? "0" : rateInKgs;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RATEINKG", i)).String = rateInKgs;
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Delivery Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            clsVariables.BaseForm = oApplication.Forms.Item(pVal.FormUID);

                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.Button oButton;
                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                            oNewItem = oForm.Items.Add("btnCRate", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("10000329");
                            oNewItem.Top = oItem.Top - oItem.Height;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Copy Rate";
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Delivery Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Delivery Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

    }
}
