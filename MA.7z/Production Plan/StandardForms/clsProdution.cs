using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;

namespace Production_PRM
{
    class clsProdution : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        StringBuilder sbQuery = new StringBuilder();

        const string headerTable = "OWOR";
        public const string soItemUID = "U_ODNo";
        public const string soEnItemUID = "U_ODEn";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                string ODEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(soEnItemUID, 0).Trim();
                                if (string.IsNullOrEmpty(ODEntry))
                                {
                                    return;
                                }
                                string PlannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("PlannedQty", 0).Trim();
                                string ItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ItemCode", 0).Trim();
                                sbQuery.Length = 0;
                                sbQuery.Append(" EXEC QUERY_PROD_GET_SO_TAGGING_ITEMS '" + ItemCode + "','" + ODEntry + "' ");
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    string balQty = oRs.Fields.Item("BalanceQty").Value.ToString();
                                    double dblBalQty = balQty == string.Empty ? 0 : double.Parse(balQty);
                                    double dblPlannedQty = PlannedQty == string.Empty ? 0 : double.Parse(PlannedQty);
                                    if (dblPlannedQty > dblBalQty)
                                    {
                                        oApplication.StatusBar.SetText("Planned qty should be equal or less than balance quantity", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = true: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_KEY_DOWN
                        if (pVal.EventType == BoEventTypes.et_KEY_DOWN)
                        {
                            
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }


        #endregion

    }
}
