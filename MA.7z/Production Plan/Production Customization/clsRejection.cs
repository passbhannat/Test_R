using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using General.Classes;

namespace Production_PRM
{
    class clsRejection : Connection
    {
        #region Variables

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        //int iMatrixRowNo = 0;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region Production Order No
                            if (pVal.ColUID == "V_30")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string TranType = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_TranType", 0).ToString().Trim();
                                string Furnace = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_Furnace", 0).ToString().Trim();
                                string DayWise = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_Shift", 0).ToString().Trim();
                                string PODate = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_PODate", 0).ToString().Trim();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                StringBuilder sbQuery = new StringBuilder();

                                if (TranType == "Rejection")
                                {
                                    sbQuery.Append(" SELECT DISTINCT T0.DOCENTRY FROM OWOR T0  ");
                                    sbQuery.Append(" INNER JOIN WOR1 T1 ON T0.DOCENTRY=T1.DOCENTRY  ");
                                    sbQuery.Append(" LEFT JOIN (SELECT U_POEn,SUM(U_QTY) U_QTY FROM [@PROD_PRM_REJ1] GROUP BY U_POEn )T2 ON T0.DocEntry=T2.U_POEn  ");
                                    sbQuery.Append(" WHERE T0.STATUS IN ('R')  AND T0.CmpltQty-ISNULL(T2.U_Qty,0)>0 ");
                                    if (Furnace != String.Empty)
                                    {
                                        sbQuery.Append(" AND U_FURCE_WISE='" + Furnace + "'");
                                    }
                                    if (DayWise != String.Empty)
                                    {
                                        sbQuery.Append(" AND U_SHIFT='" + DayWise + "'");
                                    }
                                    if (PODate != String.Empty)
                                    {
                                        sbQuery.Append(" AND POSTDATE='" + PODate + "'");
                                    }
                                }
                                else
                                {
                                    sbQuery.Append("SELECT '0'");
                                }

                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_PO", "202", sbQuery.ToString(), "DocEntry", alCondVal);


                                //temp = new ArrayList();
                                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                //temp.Add("U_CUSTNAME"); //Condition Alias             
                                //temp.Add(CardName); //Condition Value
                                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                //alCondVal.Add(temp);
                                //objclsComman.AddChooseFromList_WithCond(oForm, "CFL_PORT", "PORT", "", "", alCondVal);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_FrWhs", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("From Warehouse should not be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_ToWhs", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("To Warehouse should not be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_FrWhs", 0).ToString().Trim() == oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_ToWhs", 0).ToString().Trim())
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("From and To Warehouse should not be same.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1");
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        string ItemCode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                                        if (ItemCode == string.Empty)
                                        {
                                            continue;
                                        }
                                        double Qty = double.Parse(oDbDataSource.GetValue("U_Qty", i).ToString());
                                        double InStock = double.Parse(oDbDataSource.GetValue("U_InStock", i).ToString());
                                        if (Qty == 0)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Quantity can't be 0 for Row: " + (i + 1).ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        if (Qty > InStock)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Quantity exceeds from the Instock quantity for Row: " + (i + 1).ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        double BQty = double.Parse(oDbDataSource.GetValue("U_BQty", i).ToString());
                                        if (BQty > 0)
                                        {
                                            if (Qty > BQty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Quantity exceeds from the Base Qty of Production order for Row: " + (i + 1).ToString() + "", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                        }

                                    }

                                    #region Multi User Environment
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        AutoCode(oForm);
                                    }
                                    #endregion
                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region pVal.ItemUID == "btnCreate"
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in OK Mode.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                if (oForm.DataSources.DBDataSources.Item(0).GetValue("U_TrgtSER", 0).Trim() == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Select IT Series.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                                string TrgtDN = objclsComman.SelectRecord("SELECT U_TrgtDN FROM [@PROD_PRM_REJ] WHERE DOCENTRY='" + DocEntry + "'");
                                if (TrgtDN == String.Empty)
                                {
                                    int i = oApplication.MessageBox("Do you really want to create Inventory Tranfer?", 2, "Yes", "No", "");
                                    if (i == 1)
                                    {
                                        string ITDocNum = string.Empty;
                                        string ITDocEntry = string.Empty;

                                        objclsComman.Create_IT(DocEntry, out ITDocEntry, out ITDocNum);
                                        if (ITDocNum != string.Empty)
                                        {
                                            objclsComman.SelectRecord("UPDATE T0 SET U_TrgtDN='" + ITDocNum + "',U_TrgtDE='" + ITDocEntry + "'  FROM [@PROD_PRM_REJ] T0 WHERE DOCENTRY='" + DocEntry + "' ");
                                            objclsComman.RefreshRecord();
                                        }
                                    }
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Inventory Transfer is already created.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("PROD_PRM_REJing Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            #region Vendor Code
                            if (oCFLEvento.ChooseFromListUID == "CFL_CARD")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ");
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                            }
                            #endregion

                            #region From Warehouse
                            else if (oCFLEvento.ChooseFromListUID == "CFL_FRWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ");
                                oDbDataSource.SetValue("U_FrWhs", 0, oDataTable.GetValue("WhsCode", 0).ToString());
                                oMatrix.FlushToDataSource();

                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1");
                                string WhsCode = oDataTable.GetValue("WhsCode", 0).ToString();
                                string ItemCode = string.Empty;
                                SAPbobsCOM.Recordset oRs = null;
                                try
                                {
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue("U_FrWhs", i, WhsCode);
                                        ItemCode = oDbDataSource.GetValue("U_ItemCode", 0).Trim();
                                        oRs = Get_ItemStock(ItemCode, WhsCode);
                                        if (!oRs.EoF)
                                        {
                                            oDbDataSource.SetValue("U_InStock", i, oRs.Fields.Item("InStock").Value.ToString());
                                            oDbDataSource.SetValue("U_TotStock", i, oRs.Fields.Item("TotStock").Value.ToString());
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > Fill In Stock " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > Fill In Stock " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }

                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region To Warehouse
                            else if (oCFLEvento.ChooseFromListUID == "CFL_TOWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ");
                                oDbDataSource.SetValue("U_ToWhs", 0, oDataTable.GetValue("WhsCode", 0).ToString());
                                oMatrix.FlushToDataSource();
                                for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").Size; i++)
                                {
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ToWhs", i, oDataTable.GetValue("WhsCode", 0).ToString());
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region Matrix PO
                            else if (oCFLEvento.ChooseFromListUID == "CFL_PO")
                            {
                                StringBuilder sbQuery = new StringBuilder();

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_PONo", pVal.Row - 1, oDataTable.GetValue("DocNum", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_POEn", pVal.Row - 1, oDataTable.GetValue("DocEntry", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0).ToString());
                                string FrWhs = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_FrWhs", 0).Trim();
                                string ToWhs = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_ToWhs", 0).Trim();
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_FrWhs", pVal.Row - 1, FrWhs);
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ToWhs", pVal.Row - 1, ToWhs);

                                #region Qty
                                sbQuery.Append(" SELECT SUM(U_QTY) U_QTY FROM [@PROD_PRM_REJ1] WHERE U_POEn='" + oDataTable.GetValue("DocEntry", 0).ToString() + "'");
                                string AddedQty = objclsComman.SelectRecord(sbQuery.ToString());
                                double dblAddedQty = AddedQty == string.Empty ? 0 : double.Parse(AddedQty);
                                double dblCmpltQty = double.Parse(oDataTable.GetValue("CmpltQty", 0).ToString());
                                dblCmpltQty = dblCmpltQty - dblAddedQty;
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_Qty", pVal.Row - 1, dblCmpltQty.ToString());
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_BQty", pVal.Row - 1, dblCmpltQty.ToString());

                                #endregion

                                try
                                {
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_StdWgt", pVal.Row - 1, oDataTable.GetValue("U_STANDWT", 0).ToString());
                                }
                                catch { }

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT ItemName, OnHand [TotStock], ");
                                sbQuery.Append(" (SELECT OnHand  FROM OITW A WHERE A.ITEMCODE=T0.ITEMCODE AND A.WHSCODE='" + FrWhs + "') [InStock]");
                                sbQuery.Append(" FROM OITM T0 ");
                                sbQuery.Append(" WHERE ITEMCODE = '" + oDataTable.GetValue("ItemCode", 0).ToString() + "'");

                                SAPbobsCOM.Recordset oRs = Get_ItemStock(oDataTable.GetValue("ItemCode", 0).ToString(), FrWhs);
                                try
                                {
                                    if (!oRs.EoF)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ItemName", pVal.Row - 1, oRs.Fields.Item("ItemName").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_InStock", pVal.Row - 1, oRs.Fields.Item("InStock").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_TotStock", pVal.Row - 1, oRs.Fields.Item("TotStock").Value.ToString());
                                    }

                                    if (pVal.Row == oMatrix.RowCount)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").InsertRecord(oMatrix.VisualRowCount);
                                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").Size; i++)
                                        {
                                            oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("LineId", i, (i + 1).ToString());
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > Item Event Fill Item Data " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > Item Event Item Data  " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }


                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_30").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Matrix ItemCode
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITM")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());
                                string FrWhs = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_FrWhs", 0).Trim();
                                string ToWhs = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_ToWhs", 0).Trim();
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_FrWhs", pVal.Row - 1, FrWhs);
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_ToWhs", pVal.Row - 1, ToWhs);
                                try
                                {
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_StdWgt", pVal.Row - 1, oDataTable.GetValue("SWeight1", 0).ToString());
                                }
                                catch { }

                                SAPbobsCOM.Recordset oRs = Get_ItemStock(oDataTable.GetValue("ItemCode", 0).ToString(), FrWhs);
                                try
                                {
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_InStock", pVal.Row - 1, oRs.Fields.Item("InStock").Value.ToString());
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("U_TotStock", pVal.Row - 1, oRs.Fields.Item("TotStock").Value.ToString());
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > ItemEvent Fill InStock " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > ItemEvent Fill InStock " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }


                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").InsertRecord(oMatrix.VisualRowCount);
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("LineId", i, (i + 1).ToString());
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == "PROD_PRM_REJ")
                            {

                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "PROD_PRM_REJ" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("DocNum", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    //AutoCode(oForm);

                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                oForm = oApplication.Forms.Item(FormUID);

                                #region Series
                                if (pVal.ItemUID == "Series")
                                {
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "PROD_PRM_REJ").ToString();
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                            //AutoCode(oForm);
                                        }
                                    }
                                }
                                #endregion

                                #region Transfer Type
                                else if (pVal.ItemUID == "TranType")
                                {
                                    if (pVal.ItemChanged == true)
                                    {
                                        string TranType = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").GetValue("U_TranType", 0).Trim();
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                        if (oMatrix.VisualRowCount > 1)
                                        {
                                            oMatrix.Clear();
                                            oMatrix.AddRow(1, 1);
                                            oMatrix.FlushToDataSource();

                                            for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").Size; i++)
                                            {
                                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("LineId", i, (i + 1).ToString());
                                            }
                                            oMatrix.LoadFromDataSource();
                                        }
                                        SAPbouiCOM.Column oColumn = oMatrix.Columns.Item("V_30");
                                        if (TranType == "Rejection")
                                        {
                                            oColumn.Editable = true;
                                        }
                                        else
                                        {
                                            oColumn.Editable = false;
                                        }
                                        oForm.Update();
                                    }
                                }
                                #endregion

                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        //#region F_et_VALIDATE
                        //else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_VALIDATE)
                        //{
                        //    if (pVal.ItemUID == "mtx")
                        //    {
                        //        iMatrixRowNo = pVal.Row;
                        //    }
                        //}
                        //#endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region DocDate
                            if (pVal.ItemUID == "DocDate")
                            {
                                string ObjectCode = oForm.DataSources.DBDataSources.Item(0).TableName.Replace("@", string.Empty);
                                objclsComman.FillCombo_Series_Custom(oForm, ObjectCode, "DocDate", "Series", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);
                                }
                            }
                            #endregion

                            #region Target DocDate
                            else if (pVal.ItemUID == "TrgtDT")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, "67", "TrgtDT", "TrgtSER", "Load");
                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("PROD_PRM_REJing Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("PROD_PRM_REJing Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0);
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DuplicateRow))
                    {
                        BubbleEvent = false;
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        int selectedRowNo = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder);
                        if (selectedRowNo == -1)
                        {
                            oApplication.StatusBar.SetText("Please select row.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            return;
                        }
                        oMatrix.FlushToDataSource();
                        oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1");
                        //string lineID = oDbDataSource.GetValue("LineId", row - 1);
                        //lineID = lineID == string.Empty ? "0" : lineID;
                        int rowNo = oMatrix.VisualRowCount - 1;
                        oDbDataSource.InsertRecord(oDbDataSource.Size);
                        oDbDataSource.SetValue("LineId", rowNo, Convert.ToString(rowNo + 1));
                        oDbDataSource.SetValue("U_PONo", rowNo, oDbDataSource.GetValue("U_PONo", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_POEn", rowNo, oDbDataSource.GetValue("U_POEn", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_ItemCode", rowNo, oDbDataSource.GetValue("U_ItemCode", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_ItemName", rowNo, oDbDataSource.GetValue("U_ItemName", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_FrWhs", rowNo, oDbDataSource.GetValue("U_FrWhs", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_ToWhs", rowNo, oDbDataSource.GetValue("U_ToWhs", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_InStock", rowNo, oDbDataSource.GetValue("U_InStock", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_TotStock", rowNo, oDbDataSource.GetValue("U_TotStock", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_StdWgt", rowNo, oDbDataSource.GetValue("U_StdWgt", selectedRowNo - 1));
                        oDbDataSource.SetValue("U_BQty", rowNo, oDbDataSource.GetValue("U_BQty", selectedRowNo - 1));


                        oMatrix.LoadFromDataSource();
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "PROD_PRM_REJ" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").GetValue("U_ItemCode", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").GetValue("U_ItemCode", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DuplicateRow))
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region BusinessObjectInfo.ActionSuccess == true
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    #region T_et_FORM_DATA_ADD ,T_et_FORM_DATA_UPDATE
                    if ((BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE))
                    {
                        string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DOCENTRY", 0);
                        objclsComman.SelectRecord("DELETE FROM [@PROD_PRM_REJ1] WHERE U_ITEMCODE IS NULL AND DOCENTRY='" + DocEntry + "'");
                    }
                    #endregion

                    #region T_et_FORM_DATA_LOAD
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        string TrgtDN = oForm.DataSources.DBDataSources.Item(0).GetValue("U_TrgtDN", 0);

                        if (TrgtDN == string.Empty)
                        {
                            oForm.Items.Item("TrgtDT").SetAutoManagedAttribute(BoAutoManagedAttr.ama_Editable, 1, BoModeVisualBehavior.mvb_Default);
                            oForm.Items.Item("TrgtDT").SetAutoManagedAttribute(BoAutoManagedAttr.ama_Editable, 3, BoModeVisualBehavior.mvb_Default);
                        }
                        else
                        {
                            //oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            objclsComman.SetAutoManagedAttribute_UpdateMode(oForm.Items.Item("TrgtDT"));

                        }
                    }
                    #endregion

                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("FormDataEvent :" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }


        #endregion

        #region Method
        private void LoadForm(string MenuID)
        {
            if (MenuID == "PROD_PRM_REJ")
            {
                clsVariables.boolCFLSelected = false;
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                string query = "SELECT NAME,NAME  FROM [dbo].[@HEATMSTR] ";
                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Furnace").Specific;
                objclsComman.FillCombo(oCombo, query);

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                query = "SELECT NAME,NAME  FROM [dbo].[@REJCT] ";
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_20", 1);
                objclsComman.FillCombo(oCombo, query);

                oMatrix.CommonSetting.EnableArrowKey = true;

                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Vendor Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("S"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_CARD", "2", "", "", alCondVal);
                #endregion


            }

            oForm = oApplication.Forms.ActiveForm;

            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TrgtDT").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "67", "TrgtDT", "TrgtSER", "Load");


                string ObjectCode = oForm.DataSources.DBDataSources.Item(0).TableName.Replace("@", string.Empty);
                objclsComman.FillCombo_Series_Custom(oForm, ObjectCode, "DocDate", "Series", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "PROD_PRM_REJ").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            oItem = oForm.Items.Item("CardCode");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("mtx");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("FrWhs");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("ToWhs");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("PostDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("PODate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("Furnace");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("Shift");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("TranType");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("DocDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oForm.Select();
        }

        private string AutoCode(SAPbouiCOM.Form oForm)
        {
            string Code = objclsComman.SelectRecord(" SELECT ISNULL(MAX( CAST(DocNum AS NUMERIC(19,0))),0) + 1  FROM [@PROD_PRM_REJ] ");
            oForm.DataSources.DBDataSources.Item("@PROD_PRM_REJ").SetValue("DocNum", 0, Code);
            return Code;
        }



        private SAPbobsCOM.Recordset Get_ItemStock(string ItemCode, string WhsCode)
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ItemName, OnHand [TotStock], ");
            sbQuery.Append(" (SELECT OnHand  FROM OITW A WHERE A.ITEMCODE=T0.ITEMCODE AND A.WHSCODE='" + WhsCode + "') [InStock]");
            sbQuery.Append(" FROM OITM T0 ");
            sbQuery.Append(" WHERE ITEMCODE = '" + ItemCode + "'");

            return objclsComman.returnRecord(sbQuery.ToString());

        }
        #endregion
    }
}
