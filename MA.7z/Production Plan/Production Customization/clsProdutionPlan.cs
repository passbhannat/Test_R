using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using System.Threading;

namespace Production_PRM
{
    class clsProdutionPlan : Connection
    {
        #region Variables

        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region 1
                            if (pVal.ItemUID == "1")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.FlushToDataSource();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_PLAN1");
                                    bool boolSelected = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (oDbDataSource.GetValue("U_Select", i).Trim() == "Y")
                                        {
                                            boolSelected = true;
                                            break;
                                        }
                                    }
                                    if (boolSelected == false)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("No Rows selected.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region Browse
                            else if (pVal.ItemUID == "btnBrowse")
                            {

                                Thread thread = new Thread(new ThreadStart(OpenFileLocation));
                                thread.SetApartmentState(System.Threading.ApartmentState.STA);
                                thread.Start();

                            }

                            #endregion

                            #region Copy

                            else if (pVal.ItemUID == "btnCopy")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Path").Specific;
                                if (oEdit.Value.ToString() == "")
                                {
                                    oApplication.StatusBar.SetText("Please Select the file.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                System.Data.DataTable dt = ReadExcelFile(oForm);
                                FillMatrix(oForm, dt);
                            }
                            #endregion

                            #region Select All
                            else if (pVal.ItemUID == "btnSelect")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_PLAN1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "Y");
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region Clear All
                            else if (pVal.ItemUID == "btnClear")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_PLAN1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "N");
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region Create Production
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                }
                                int iMessage = oApplication.MessageBox("Do you really want to create Production Order?", 1, "Yes", "No", "");
                                if (iMessage == 1)
                                {
                                    string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                                    Create_ProdcutionOrder(DocEntry);
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == "PROD_PRM_PLAN" || pVal.MenuUID == "1282")
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (BusinessObjectInfo.ActionSuccess == true)
            {
                if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD ||
                    BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                    StringBuilder sbQuery = new StringBuilder();
                    sbQuery.Append(" DELETE FROM [@PROD_PRM_PLAN1] WHERE DOCENTRY='" + DocEntry + "' and ISNULL(U_SELECT,'N')='N'");
                    objclsComman.SelectRecord(sbQuery.ToString());
                }
            }
        }


        #endregion

        #region Methods

        #region LoadForm
        private void LoadForm(string MenuID)
        {
            if (MenuID == "PROD_PRM_PLAN")
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false); // Cancel
                oForm.EnableMenu("1286", false); // Close

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";


                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
            }

            oForm = oApplication.Forms.ActiveForm;
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("Date").Specific;
            oEdit.String = "t";
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocEntry");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Date");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("mtx");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

        }

        #endregion

        #region OpenFileLocation

        public void OpenFileLocation()
        {
            try
            {

                frmBrowse sd = new frmBrowse();
                sd.ShowDialog();
                sd.Close();

                SAPbouiCOM.Form oFrm = oApplication.Forms.ActiveForm;
                ((SAPbouiCOM.EditText)oFrm.Items.Item("Path").Specific).Value = clsVariables.BrowsePath;

            }
            catch { }
        }

        #endregion

        #region ReadExcelFile
        public System.Data.DataTable ReadExcelFile(SAPbouiCOM.Form oForm)
        {

            string excelSheets = "";
            System.Data.DataTable dtExcelRec = null;
            string FileLocation = ((SAPbouiCOM.EditText)oForm.Items.Item("Path").Specific).Value.ToString();

            System.Data.OleDb.OleDbConnection oconn = new System.Data.OleDb.OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileLocation.ToString() + ";Extended Properties=Excel 12.0");
            oconn.Open();

            System.Data.DataTable dt = oconn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);  //Get the table name

            if (dt == null)
            {

            }

            else
            {

                foreach (DataRow row in dt.Rows)
                {
                    excelSheets = row["TABLE_NAME"].ToString(); // Store the table name in Excelsheet variable which is declare at class level
                    break;
                }

                System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter("select * from [" + excelSheets + "]", oconn);
                dtExcelRec = new System.Data.DataTable();

                da.Fill(dtExcelRec);

                // Cleanup
                oconn.Close();
                da.Dispose();

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return dtExcelRec;
        }

        #endregion

        #region FillMatrix

        private bool FillMatrix(SAPbouiCOM.Form oForm, System.Data.DataTable dt)
        {
            try
            {

                SAPbouiCOM.Matrix oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                oMatrix.Clear();
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_PLAN1");
                int i = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    if (i < dt.Rows.Count)
                    {
                        oDbDataSource.InsertRecord(i);
                    }
                    oDbDataSource.SetValue("LineId", i, Convert.ToString(i));
                    oDbDataSource.SetValue("U_SrNo", i, dr["SL No#"].ToString());

                    oDbDataSource.SetValue("U_Series", i, dr["Series"].ToString());
                    oDbDataSource.SetValue("U_OrdNo", i, dr["Tracking No#"].ToString());
                    oDbDataSource.SetValue("U_StDate", i, dr["Start Date (Planning Date)"].ToString());
                    oDbDataSource.SetValue("U_OrdDate", i, dr["Order Date (Pouring Date)"].ToString());
                    oDbDataSource.SetValue("U_Type", i, dr["Type"].ToString());
                    oDbDataSource.SetValue("U_Status", i, dr["Status"].ToString());
                    oDbDataSource.SetValue("U_PCode", i, dr["Parent Code"].ToString());
                    oDbDataSource.SetValue("U_WhsCode", i, dr["Warehouse"].ToString());
                    oDbDataSource.SetValue("U_PlanQty", i, dr["Planned Qty"].ToString());
                    oDbDataSource.SetValue("U_UOM", i, dr["UOM"].ToString());
                    oDbDataSource.SetValue("U_StWt", i, dr["Standard Weight"].ToString());
                    oDbDataSource.SetValue("U_SONo", i, dr["Sales Order"].ToString());

                    oDbDataSource.SetValue("U_PrdDistF", i, dr["Production Distribution Furnace Wise"].ToString());
                    oDbDataSource.SetValue("U_Line_No", i, dr["Line_No"].ToString());
                    oDbDataSource.SetValue("U_HeatWise", i, dr["Heat Wise"].ToString());
                    oDbDataSource.SetValue("U_Shift", i, dr["Shift"].ToString());
                    oDbDataSource.SetValue("U_ODNo", i, dr["Order Distribution No"].ToString());
                    oDbDataSource.SetValue("U_PrdDist", i, dr["Production Distribution"].ToString());
                    oDbDataSource.SetValue("U_PCodeRow", i, dr["Parent Code"].ToString());

                    oDbDataSource.SetValue("U_CItem", i, dr["Child Item"].ToString());
                    oDbDataSource.SetValue("U_BaseQty", i, dr["Base Qty"].ToString());
                    oDbDataSource.SetValue("U_PQtyRow", i, dr["Planned Qty (Total)"].ToString());
                    oDbDataSource.SetValue("U_UOMRow", i, dr["UOM Row"].ToString());
                    oDbDataSource.SetValue("U_WhsRow", i, dr["Warehouse Row"].ToString());
                    oDbDataSource.SetValue("U_IssMeth", i, dr["Issue Method"].ToString());
                    oDbDataSource.SetValue("U_AnnNo", i, dr["Annexure No"].ToString());
                    oDbDataSource.SetValue("U_CONTR", i, dr["Contractor"].ToString());

                    i = i + 1;
                }
                oMatrix.LoadFromDataSource();
                return true;
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.StackTrace, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                return false;
            }
        }

        #endregion

        #region Create Production Order

        private void Create_ProdcutionOrder(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string OrdNo = string.Empty;
            string orderDataTableUID = "OrdNo";
            string itemsDataTableUID = "Items";

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT U_OrdNo FROM [@PROD_PRM_PLAN1] T0 WHERE DOCENTRY='" + DocEntry + "' AND NOT EXISTS (SELECT 1 FROM OWOR T1 WHERE T0.U_OrdNo=T1.U_UpOrdNo)");
            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }
            try
            {
                oForm.DataSources.DataTables.Add(itemsDataTableUID);
            }
            catch { }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                if (oDataTable.Rows.Count == 0)
                {
                    oApplication.StatusBar.SetText(sbQuery.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    oApplication.MessageBox(" No Production order found to create. ", 1, "Ok", "", "");
                    return;
                }
                StringBuilder sbMessage = new StringBuilder();

                for (int j = 0; j < oDataTable.Rows.Count; j++)
                {
                    OrdNo = oDataTable.GetValue("U_OrdNo", j).ToString();
                    SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.*,T1.Series ");
                    sbQuery.Append(" FROM [@PROD_PRM_PLAN1] T0 ");
                    sbQuery.Append(" LEFT JOIN NNM1 T1 ON T0.U_Series=T1.SeriesName ");
                    sbQuery.Append(" WHERE DOCENTRY='" + DocEntry + "' AND U_OrdNo='" + OrdNo + "'");
                    SAPbouiCOM.DataTable oDataTable_Items = oForm.DataSources.DataTables.Item("Items");
                    oDataTable_Items.Clear();
                    oDataTable_Items.ExecuteQuery(sbQuery.ToString());

                    try
                    {
                        if (oDataTable_Items.Rows.Count > 0)
                        {
                            #region Setting Production Order Headers

                            wo.UserFields.Fields.Item("U_UpOrdNo").Value = OrdNo;
                            wo.Series = Int32.Parse(oDataTable_Items.GetValue("Series", 0).ToString());
                            wo.StartDate = DateTime.Parse(oDataTable_Items.GetValue("U_StDate", 0).ToString());
                            wo.PostingDate = DateTime.Parse(oDataTable_Items.GetValue("U_OrdDate", 0).ToString().Trim());
                            string Type = oDataTable_Items.GetValue("U_Type", 0).ToString().Trim();
                            if (Type == "Special")
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotSpecial;
                            }
                            else if (Type == "Standard")
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotStandard;
                            }
                            else if (Type == "Disassembly")
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotDisassembly;
                            }
                            wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                            wo.ItemNo = oDataTable_Items.GetValue("U_PCode", 0).ToString().Trim();
                            wo.Warehouse = oDataTable_Items.GetValue("U_WhsCode", 0).ToString().Trim();
                            wo.PlannedQuantity = double.Parse(oDataTable_Items.GetValue("U_PlanQty", 0).ToString().Trim());

                            wo.UserFields.Fields.Item("U_FURCE_WISE").Value = oDataTable_Items.GetValue("U_PrdDistF", 0).ToString().Trim();
                            wo.UserFields.Fields.Item("U_HT_WISE").Value = oDataTable_Items.GetValue("U_HeatWise", 0).ToString().Trim();
                            wo.UserFields.Fields.Item("U_SHIFT").Value = oDataTable_Items.GetValue("U_Shift", 0).ToString().Trim();
                            wo.UserFields.Fields.Item("U_CONTR").Value = oDataTable_Items.GetValue("U_CONTR", 0).ToString().Trim();

                            try
                            {
                                wo.UserFields.Fields.Item("U_STANDWT").Value = oDataTable_Items.GetValue("U_StWt", 0).ToString().Trim();
                            }
                            catch { }
                            string PrdDist = oDataTable_Items.GetValue("U_PrdDist", 0).ToString().ToUpper();
                            try
                            {
                                if (PrdDist == "JOB WORK")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "JBW";
                                }
                                else if (PrdDist == "OWN")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "OWN";
                                }
                                else if (PrdDist == "ASSEMBLY")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "ASSEMBLY";
                                }
                                else if (PrdDist == "OTHER")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "OTHER";
                                }
                            }
                            catch { }
                            wo.UserFields.Fields.Item("U_ODNo").Value = oDataTable_Items.GetValue("U_ODNo", 0).ToString().Trim();
                            wo.UserFields.Fields.Item("U_SALODR").Value = oDataTable_Items.GetValue("U_SONo", 0).ToString().Trim();
                            try
                            {
                                wo.UserFields.Fields.Item("U_LINENO").Value = oDataTable_Items.GetValue("U_Line_No", 0).ToString().Trim();
                            }
                            catch { }
                            #endregion

                            #region Setting Child Items 

                            int iRow = 0;

                            for (int k = 0; k < oDataTable_Items.Rows.Count; k++)
                            {
                                wo.Lines.SetCurrentLine(iRow);
                                wo.Lines.ItemNo = oDataTable_Items.GetValue("U_CItem", k).ToString().Trim();
                                wo.Lines.Warehouse = oDataTable_Items.GetValue("U_WhsRow", k).ToString().Trim();
                                if (oDataTable_Items.GetValue("U_IssMeth", k).ToString().Trim() == "Manual")
                                {
                                    wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                                }
                                if (oDataTable_Items.GetValue("U_IssMeth", k).ToString().Trim() == "Backflush")
                                {
                                    wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Backflush;
                                }
                                wo.Lines.BaseQuantity = double.Parse(oDataTable_Items.GetValue("U_BaseQty", k).ToString().Trim());
                                wo.Lines.PlannedQuantity = double.Parse(oDataTable_Items.GetValue("U_PQtyRow", k).ToString().Trim());
                                wo.Lines.UserFields.Fields.Item("U_ANXRE").Value = oDataTable_Items.GetValue("U_AnnNo", k).ToString().Trim().ToUpper();
                                try
                                {
                                    wo.Lines.UserFields.Fields.Item("U_PRM_Line").Value = oDataTable_Items.GetValue("U_Line_No", k).ToString().Trim();
                                }
                                catch
                                {

                                }
                                 
                                wo.Lines.Add();
                                iRow++;
                            }

                            #endregion

                            int retVal = wo.Add();
                            if (retVal != 0)
                            {
                                oApplication.StatusBar.SetText("For Order No : " + OrdNo + " Error : " + oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                sbQuery.Append(oCompany.GetLastErrorDescription());
                                sbQuery.Append(Environment.NewLine);
                            }
                            else
                            {
                                string PODocEntry = oCompany.GetNewObjectKey();
                                string PODocNum = objclsComman.SelectRecord("SELECT DOCNUM FROM OWOR WHERE DOCENTRY='" + PODocEntry + "'");
                                objclsComman.SelectRecord("UPDATE T0 SET U_PrdEn='" + PODocEntry + "',U_PrdNo='" + PODocNum + "' FROM [@PROD_PRM_PLAN1] T0 WHERE DOCENTRY='" + DocEntry + "' AND U_OrdNo='" + OrdNo + "'");
                                oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                        oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    finally
                    {
                        if (oDataTable_Items != null)
                        {
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable_Items);
                        }
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                    }
                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }


        private void Create_ProdcutionOrder_Old(string DocEntry)
        {
            StringBuilder sbMessage = new StringBuilder();
            SAPbobsCOM.Recordset oRs = null;
            SAPbobsCOM.Recordset oRs_Items = null;
            try
            {
                string OrdNo = string.Empty;
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT DISTINCT U_OrdNo FROM [@PROD_PRM_PLAN1] T0 WHERE DOCENTRY='" + DocEntry + "' AND NOT EXISTS (SELECT 1 FROM OWOR T1 WHERE T0.U_OrdNo=T1.U_UpOrdNo)");
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.StatusBar.SetText(sbQuery.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    oApplication.MessageBox(" No Production order found to create. ", 1, "Ok", "", "");
                    return;
                }

                while (!oRs.EoF)
                {
                    OrdNo = oRs.Fields.Item("U_OrdNo").Value.ToString().Trim();
                    SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.*,T1.Series ");
                    sbQuery.Append(" FROM [@PROD_PRM_PLAN1] T0 ");
                    sbQuery.Append(" LEFT JOIN NNM1 T1 ON T0.U_Series=T1.SeriesName ");
                    sbQuery.Append(" WHERE DOCENTRY='" + DocEntry + "' AND U_OrdNo='" + OrdNo + "'");
                    oRs_Items = objclsComman.returnRecord(sbQuery.ToString());
                    try
                    {
                        if (oRs_Items.RecordCount > 0)
                        {
                            wo.UserFields.Fields.Item("U_UpOrdNo").Value = OrdNo;
                            wo.Series = Int32.Parse(oRs_Items.Fields.Item("Series").Value.ToString().Trim());
                            wo.StartDate = DateTime.Parse(oRs_Items.Fields.Item("U_StDate").Value.ToString().Trim());
                            wo.PostingDate = DateTime.Parse(oRs_Items.Fields.Item("U_OrdDate").Value.ToString().Trim());
                            string Type = oRs_Items.Fields.Item("U_Type").Value.ToString().Trim();

                            if (Type == "Special")
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotSpecial;
                            }
                            else if (Type == "Standard")
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotStandard;
                            }
                            else
                            {
                                wo.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotDisassembly;
                            }

                            wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                            wo.ItemNo = oRs_Items.Fields.Item("U_PCode").Value.ToString().Trim();
                            wo.Warehouse = oRs_Items.Fields.Item("U_WhsCode").Value.ToString().Trim();
                            wo.PlannedQuantity = double.Parse(oRs_Items.Fields.Item("U_PlanQty").Value.ToString().Trim());

                            string a = oRs_Items.Fields.Item("U_PrdDistF").Value.ToString().Trim();
                            wo.UserFields.Fields.Item("U_FURCE_WISE").Value = oRs_Items.Fields.Item("U_PrdDistF").Value.ToString().Trim();
                            wo.UserFields.Fields.Item("U_HT_WISE").Value = oRs_Items.Fields.Item("U_HeatWise").Value.ToString().Trim();
                            wo.UserFields.Fields.Item("U_SHIFT").Value = oRs_Items.Fields.Item("U_Shift").Value.ToString().Trim().ToUpper();

                            string PrdDist = oRs_Items.Fields.Item("U_PrdDist").Value.ToString().Trim().ToUpper();
                            try
                            {
                                if (PrdDist == "JOB WORK")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "JBW";
                                }
                                else if (PrdDist == "OWN")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "OWN";
                                }
                                else if (PrdDist == "ASSEMBLY")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "ASSEMBLY";
                                }
                                else if (PrdDist == "OTHER")
                                {
                                    wo.UserFields.Fields.Item("U_PROD_DTRIBUTN").Value = "OTHER";
                                }
                            }
                            catch { }
                            wo.UserFields.Fields.Item("U_ODNo").Value = oRs_Items.Fields.Item("U_ODNo").Value.ToString().Trim();
                            wo.UserFields.Fields.Item("U_SALODR").Value = oRs_Items.Fields.Item("U_SONo").Value.ToString().Trim();
                            try
                            {
                                wo.UserFields.Fields.Item("U_LINENO").Value = oRs_Items.Fields.Item("U_Line_No").Value.ToString().Trim();
                            }
                            catch { }
                            int i = 0;
                            while (!oRs_Items.EoF)
                            {
                                try
                                {
                                    if (i != 0)
                                    {
                                        wo.Lines.SetCurrentLine(i);
                                    }
                                    wo.Lines.ItemNo = oRs_Items.Fields.Item("U_CItem").Value.ToString().Trim();
                                    wo.Lines.Warehouse = oRs_Items.Fields.Item("U_WhsRow").Value.ToString().Trim();
                                    if (oRs_Items.Fields.Item("U_WhsRow").Value.ToString().Trim() == "Manual")
                                    {
                                        wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                                    }
                                    if (oRs_Items.Fields.Item("U_WhsRow").Value.ToString().Trim() == "Backflush")
                                    {
                                        wo.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Backflush;
                                    }
                                    wo.Lines.BaseQuantity = double.Parse(oRs_Items.Fields.Item("U_BaseQty").Value.ToString().Trim());
                                    wo.Lines.PlannedQuantity = double.Parse(oRs_Items.Fields.Item("U_PQtyRow").Value.ToString().Trim());

                                    wo.Lines.UserFields.Fields.Item("U_ANXRE").Value = oRs_Items.Fields.Item("U_AnnNo").Value.ToString().Trim().ToUpper();
                                    try
                                    {
                                        wo.Lines.UserFields.Fields.Item("U_PRM_Line").Value = oRs_Items.Fields.Item("U_Line_No").Value.ToString().Trim().ToUpper();
                                    }
                                    catch { }
                                    wo.Lines.Add();
                                }
                                catch (Exception ex)
                                {
                                    oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                }
                                oRs_Items.MoveNext();
                                i = i + 1;
                            }

                            int retVal = wo.Add();
                            if (retVal != 0)
                            {
                                oApplication.StatusBar.SetText("For Order No : " + OrdNo + " Error : " + oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                sbQuery.Append(oCompany.GetLastErrorDescription());
                                sbQuery.Append(Environment.NewLine);
                            }
                            else
                            {
                                string PODocEntry = oCompany.GetNewObjectKey();
                                string PODocNum = objclsComman.SelectRecord("SELECT DOCNUM FROM OWOR WHERE DOCENTRY='" + PODocEntry + "'");
                                objclsComman.SelectRecord("UPDATE T0 SET U_PrdEn='" + PODocEntry + "',U_PrdNo='" + PODocNum + "' FROM [@PROD_PRM_PLAN1] T0 WHERE DOCENTRY='" + DocEntry + "' AND U_OrdNo='" + OrdNo + "'");
                                oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                            }
                        }
                    }
                    finally
                    {
                        if (oRs_Items != null)
                        {
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs_Items);
                        }
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                    }
                    oRs.MoveNext();
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            if (sbMessage.Length != 0)
            {
                oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
            }
        }

        #endregion

        #endregion

    }
}
