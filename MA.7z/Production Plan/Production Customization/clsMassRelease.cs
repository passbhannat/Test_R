using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using System.Threading;

namespace Production_PRM
{
    class clsMassRelease : Connection
    {
        #region Variables

        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region 1
                            if (pVal.ItemUID == "1")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.FlushToDataSource();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_MREL1");
                                    bool boolSelected = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (oDbDataSource.GetValue("U_Select", i).Trim() == "Y")
                                        {
                                            boolSelected = true;
                                            break;
                                        }
                                    }
                                    if (boolSelected == false)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("No Rows selected.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region Select All
                            else if (pVal.ItemUID == "btnSelect")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_MREL1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "Y");
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region Clear All
                            else if (pVal.ItemUID == "btnClear")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_MREL1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "N");
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                            #region Release Production
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                                Release_PO(DocEntry);
                                objclsComman.RefreshRecord();
                            }
                            #endregion

                            #region Fill Data
                            else if (pVal.ItemUID == "btnFill")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                FillMatrix(oForm, "N");
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == "PROD_PRM_MREL" || pVal.MenuUID == "1282")
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (BusinessObjectInfo.ActionSuccess == true)
            {
                if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD ||
                    BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                    StringBuilder sbQuery = new StringBuilder();
                    sbQuery.Append(" DELETE FROM [@PROD_PRM_MREL1] WHERE DOCENTRY='" + DocEntry + "' and ISNULL(U_SELECT,'N')='N'");
                    objclsComman.SelectRecord(sbQuery.ToString());

                    Release_PO(DocEntry);
                }
            }
        }


        #endregion

        #region Methods

        #region LoadForm
        private void LoadForm(string MenuID)
        {
            if (MenuID == "PROD_PRM_MREL")
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false); // Cancel
                oForm.EnableMenu("1286", false); // Close

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                string query = "SELECT NAME,NAME  FROM [dbo].[@HEATMSTR] ";
                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Furnace").Specific;
                objclsComman.FillCombo(oCombo, query);
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
            }

            oForm = oApplication.Forms.ActiveForm;

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocEntry");
            objclsComman.SetAutoManagedAttribute(oItem);


            oItem = oForm.Items.Item("WhsCode");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("Furnace");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("OFrDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("OToDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("mtx");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

        }

        #endregion

        #region FillMatrix

        private bool FillMatrix(SAPbouiCOM.Form oForm, string Select)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT '" + Select + "' [Select],T1.SeriesName,T0.DocNum,T0.DocEntry,T0.Status,Convert(Varchar(10),T0.PostDate,112) PostDate");
                sbQuery.Append(" ,Convert(Varchar(10),T0.StartDate,112) StartDate,T0.ItemCode,t0.PlannedQty FROM OWOR T0 ");
                sbQuery.Append(" INNER JOIN NNM1 T1 ON T0.Series=T1.Series ");
                sbQuery.Append(" WHERE T0.Status='P' ");

                string WhsCode = oForm.DataSources.DBDataSources.Item(0).GetValue("U_WhsCode", 0).Trim();
                string Furnace = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Furnace", 0).Trim();
                string FromDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_OFrDate", 0).Trim();
                string ToDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_OToDate", 0).Trim();

                if (FromDate != string.Empty)
                {
                    sbQuery.Append(" AND T0.PostDate>='" + FromDate + "' ");
                }
                if (ToDate != string.Empty)
                {
                    sbQuery.Append(" AND T0.PostDate<='" + ToDate + "' ");
                }
                if (WhsCode != string.Empty)
                {
                    sbQuery.Append(" AND T0.Warehouse='" + WhsCode + "' ");
                }
                if (Furnace != string.Empty)
                {
                    sbQuery.Append(" AND T0.U_FURCE_WISE='" + Furnace + "' ");
                }
                SAPbouiCOM.Matrix oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                oMatrix.Clear();
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_PRM_MREL1");
                oRs = objclsComman.returnRecord(sbQuery.ToString());
                int Row = 0;
                while (!oRs.EoF)
                {
                    if (Row > 0)
                    {
                        oDbDataSource.InsertRecord(Row);
                    }
                    oDbDataSource.SetValue("LineId", Row, (Row + 1).ToString());
                    oDbDataSource.SetValue("U_POSer", Row, oRs.Fields.Item("SeriesName").Value.ToString());
                    oDbDataSource.SetValue("U_PODocNum", Row, oRs.Fields.Item("DocNum").Value.ToString());
                    oDbDataSource.SetValue("U_PODocEn", Row, oRs.Fields.Item("DocEntry").Value.ToString());
                    oDbDataSource.SetValue("U_POStatus", Row, oRs.Fields.Item("Status").Value.ToString());
                    oDbDataSource.SetValue("U_PItem", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                    oDbDataSource.SetValue("U_Quantity", Row, oRs.Fields.Item("PlannedQty").Value.ToString());
                    oDbDataSource.SetValue("U_Select", Row, oRs.Fields.Item("Select").Value.ToString());
                    oDbDataSource.SetValue("U_PostDate", Row, oRs.Fields.Item("PostDate").Value.ToString());
                    oDbDataSource.SetValue("U_PlanDate", Row, oRs.Fields.Item("StartDate").Value.ToString());
                    oRs.MoveNext();
                    Row = Row + 1;
                }
                oMatrix.LoadFromDataSource();
                return true;
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > Fill Matrix " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > Fill Matrix " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                return false;
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        #endregion

        #region Release_PO
        private void Release_PO(string DocEntry)
        {
            SAPbobsCOM.Recordset oRs= objclsComman.returnRecord("SELECT T0.U_PODocEn,T0.LineId FROM [@PROD_PRM_MREL1] T0  WHERE T0.U_POStatus='P' AND T0.DOCENTRY='" + DocEntry + "' AND T0.U_SELECT='Y'");
            try
            {
                if (oRs.RecordCount == 0)
                {
                    oApplication.StatusBar.SetText("No Record to Release.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return;
                }
                while (!oRs.EoF)
                {
                    try
                    {
                        string LineId = oRs.Fields.Item("LineId").Value.ToString();
                        Int32 PODocEntry = Int32.Parse(oRs.Fields.Item("U_PODocEn").Value.ToString());
                        SAPbobsCOM.ProductionOrders wo = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);
                        if (wo.GetByKey(PODocEntry) == true)
                        {
                            wo.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposReleased;
                            Int32 iResult = wo.Update();
                            if (iResult == 0)
                            {
                                objclsComman.SelectRecord("UPDATE T0 SET T0.U_POSTATUS='R' FROM [@PROD_PRM_MREL1] T0 WHERE T0.DOCENTRY='" + DocEntry + "' AND T0.LINEID='" + LineId + "'");
                            }
                            else
                            {
                                oApplication.StatusBar.SetText("Release PO DocEntry:" + PODocEntry.ToString() + " Error: " + oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                    oRs.MoveNext();
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            oApplication.StatusBar.SetText("Done", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
        }
        #endregion

        #endregion


    }
}
