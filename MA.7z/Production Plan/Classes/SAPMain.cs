using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;

namespace Production_PRM
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        clsProdutionPlan objclsProdutionPlan = new clsProdutionPlan();
        clsRejection objclsRejection = new clsRejection();
        clsMassRelease objclsMassRelease = new clsMassRelease();
        clsMassClose objclsMassClose = new clsMassClose();
        clsProdution objclsProdution = new clsProdution();
        clsDelivery objclsDelivery = new clsDelivery();
        clsSalesOrder objclsSalesOrder = new clsSalesOrder();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();

            oForm = oApplication.Forms.GetFormByTypeAndCount(169, 1); // Get reference to the Center form
            //oForm.Freeze(true);
            PrepareMenus();
            //oForm.Freeze(false);
            oForm.Update();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));

            string superUser = objclsComman.SelectRecord("SELECT SUPERUSER FROM OUSR WHERE USERID='" + oCompany.UserSignature + "'");
            if (superUser == "Y")
            {
                objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "PROD_PRM_UDO", "Create Production Planned UDO", 0);
            }

            objclsComman.AddMenu(BoMenuType.mt_POPUP, "43520", "PROD_PRM", "Production Planned Customization", 20);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PRM", "PROD_PRM_PLAN", "Production Plan", 0);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PRM", "PROD_PRM_REJ", "Rejection Transfer Process", 1);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PRM", "PROD_PRM_MREL", "Mass Production Order Release", 2);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PRM", "PROD_PRM_MCLOSE", "Mass Production Order Close", 3);
         
        }

        public void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
        }

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;

                }
                catch { }
                switch (pVal.FormTypeEx)
                {
                    case "PROD_PRM_PLAN":
                        objclsProdutionPlan.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "PROD_PRM_MREL":
                        objclsMassRelease.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "PROD_PRM_MCLOSE":
                        objclsMassClose.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "PROD_PRM_REJ":
                        objclsRejection.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "65211":
                    case "-65211":
                        objclsProdution.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "140":
                        objclsDelivery.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    case "139":
                        objclsSalesOrder.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;

                    //case "425":
                    //    objclsDocumentItemSelection.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                    //    break;

                }
            }
            catch { }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "PROD_PRM_UDO")
                {
                    if (pVal.BeforeAction == true)
                    {
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                if (pVal.MenuUID == "PROD_PRM_PLAN" || oForm.TypeEx == "PROD_PRM_PLAN")
                {
                    objclsProdutionPlan.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == "PROD_PRM_REJ" || oForm.TypeEx == "PROD_PRM_REJ")
                {
                    objclsRejection.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == "PROD_PRM_MREL" || oForm.TypeEx == "PROD_PRM_MREL")
                {
                    objclsMassRelease.MenuEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.MenuUID == "PROD_PRM_MCLOSE" || oForm.TypeEx == "PROD_PRM_MCLOSE")
                {
                    objclsMassClose.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message, 1, "Ok", "Cancel", "");
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            switch (BusinessObjectInfo.FormTypeEx)
            {
                case "PROD_PRM_PLAN":
                    objclsProdutionPlan.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;

                case "PROD_PRM_REJ":
                    objclsRejection.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;

                case "PROD_PRM_MREL":
                    objclsMassRelease.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;

                case "PROD_PRM_MCLOSE":
                    objclsMassClose.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;

            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            string ProcessName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(ProcessName + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(ProcessName + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(ProcessName + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(ProcessName + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

      


        #endregion
    }
}
