using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Banking
{
    class clsLodgementBill : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        bool MultiInvoiceSelected = false;

        const string headerTable = "@LODG_BILLS";
        const string rowTable = "@LODG_BILLS1";
        const string branchUDF = "U_BPLId";
        const string branchUID = "BPLId";

        bool closeForm = false;
        string closeFormDocEntry = "";
        const string udsBaseDoc = "BaseDoc";
        const string udsBaseFUID = "BaseFUID";
        const string udsBaseRow = "BaseRow";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {

                            if (pVal.ColUID == "V_5")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_CardCode", 0).ToString().Trim();
                                if (CardCode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Select the customer code.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(branchUDF, 0).ToString();
                                if (branch == string.Empty && isBranchDatabase == "Y")
                                {
                                    oApplication.StatusBar.SetText("Please select branch.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                string query = string.Empty;
                                SAPbouiCOM.Column oColumn = (SAPbouiCOM.Column)oMatrix.Columns.Item("V_5");
                                oColumn.ChooseFromListUID = "CFL_JE";
                                StringBuilder sbQuery = new StringBuilder();
                                if (branch == string.Empty)
                                {
                                    sbQuery.Append(" SELECT TRANSID FROM (SELECT  T0.TransId FROM OJDT T0 INNER JOIN JDT1 T1 ON T0.TransId=T1.TransId WHERE T0.TRANSTYPE='30' AND T1.SHORTNAME='" + CardCode + "' ");
                                    sbQuery.Append(" UNION ALL");
                                    sbQuery.Append(" SELECT  T0.TransId FROM OINV T0  WHERE DOCSTATUS='O' AND CARDCODE='" + CardCode + "') AS A ");
                                    sbQuery.Append(" WHERE NOT EXISTS (SELECT * FROM [@LODG_BILLS1] B WHERE A.TRANSID=B.U_INVDOCE)");
                                }
                                else
                                {
                                    sbQuery.Append(" SELECT TRANSID FROM ( ");
                                    sbQuery.Append(" SELECT  T0.TransId FROM OJDT T0 INNER JOIN JDT1 T1 ON T0.TransId=T1.TransId ");
                                    sbQuery.Append(" INNER JOIN OINV T2 ON T1.TransId=T2.TransId ");
                                    sbQuery.Append(" WHERE T0.TRANSTYPE='30' AND T2.BPLId = '" + branch + "' AND T1.SHORTNAME='" + CardCode + "'  ");

                                    sbQuery.Append(" UNION ALL");

                                    sbQuery.Append(" SELECT  T0.TransId FROM OINV T0  WHERE  T0.BPLId = '" + branch + "' AND  DOCSTATUS='O' AND CARDCODE='" + CardCode + "' ");
                                    sbQuery.Append(" ) AS A ");
                                    sbQuery.Append(" WHERE NOT EXISTS (SELECT * FROM [@LODG_BILLS1] B WHERE A.TRANSID=B.U_INVDOCE)");
                                }
                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_JE", "30", sbQuery.ToString(), "TransId", alCondVal);

                                //if (DocType == "13")
                                //{
                                //    oColumn.ChooseFromListUID = "CFL_INV";
                                //    query = "SELECT DOCENTRY FROM  OINV WHERE DOCSTATUS='O' AND CARDCODE='" + CardCode + "'";
                                //    objclsComman.AddChooseFromList_WithCond(oForm, "CFL_INV", "13", query, "DocEntry", alCondVal);
                                //}
                                //else if (DocType == "30")
                                //{
                                //    oColumn.ChooseFromListUID = "CFL_JE";
                                //    query = "SELECT  T0.TransId FROM OJDT T0 INNER JOIN JDT1 T1 ON T0.TransId=T1.TransId WHERE T0.TRANSTYPE='30' AND T1.SHORTNAME='" + CardCode + "'";
                                //    objclsComman.AddChooseFromList_WithCond(oForm, "CFL_JE", "30", query, "TransId", alCondVal);
                                //}

                            }

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_BankName", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select the bank name.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_CardCode", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_Total", 0).ToString().Trim() == string.Empty ||
                                        Convert.ToDouble(oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_Total", 0).ToString().Trim()) == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Total amount can't be zero.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    if (oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }


                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            else if (pVal.ItemUID == "btnCopySO")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                                string CardCode = oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("U_CardCode", 0).ToString();
                                if (CardCode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please Select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Lodgement of Bills Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_CARD")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@LODG_BILLS");
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_AP")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@LODG_BILLS");
                                oDbDataSource.SetValue("U_PONo", 0, oDataTable.GetValue("DocNum", 0).ToString());
                                oDbDataSource.SetValue("U_POEn", 0, oDataTable.GetValue("DocEntry", 0).ToString());
                                oDbDataSource.SetValue("U_POAmt", 0, oDataTable.GetValue("DocTotal", 0).ToString());
                                try
                                {
                                    DateTime dt = Convert.ToDateTime(oDataTable.GetValue("DocDate", 0).ToString());
                                    string date = dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');
                                    oDbDataSource.SetValue("U_PODate", 0, date);
                                }
                                catch { }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_INV" || oCFLEvento.ChooseFromListUID == "CFL_JE")
                            {
                                if (oDataTable.Rows.Count > 1)
                                {
                                    MultiInvoiceSelected = true;
                                    return;
                                }
                                double DocTotal = 0;
                                double DocRate = 0;
                                string DocCur = string.Empty;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                int i = pVal.Row - 1;

                                string Company_LocalCurrency = objclsComman.SelectRecord("SELECT MAINCURNCY FROM OADM");
                                //string DocType =oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_DocType", i).Trim();
                                DateTime dt;
                                string DueDate = string.Empty;
                                string DocDate = string.Empty;

                                string TransID = oDataTable.GetValue("TransId", 0).ToString();
                                string TransType = oDataTable.GetValue("TransType", 0).ToString();

                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvDocE", i, TransID);
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvNo", i, oDataTable.GetValue("BaseRef", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_DocType", i, oDataTable.GetValue("TransType", 0).ToString());
                                if (TransType == "13")
                                {
                                    StringBuilder sbQuery = new StringBuilder();
                                    sbQuery.Append(" SELECT T0.DocNum, T0.DocRate,T0.DocCur,T0.GroupNum,");
                                    sbQuery.Append(" T0.DocTotal,T0.DocTotalFC,T0.Comments,T1.BeginStr,  T1.EndStr ");
                                    sbQuery.Append(" FROM OINV T0 INNER JOIN NNM1 T1 ON T0.SERIES = T1.SERIES ");
                                    sbQuery.Append(" WHERE T0.TRANSID='" + TransID + "'");
                                    SAPbobsCOM.Recordset oRsInvoice = objclsComman.returnRecord(sbQuery.ToString());
                                    if (oRsInvoice.RecordCount > 0)
                                    {
                                        DocRate = double.Parse(oRsInvoice.Fields.Item("DocRate").Value.ToString());
                                        DocCur = oRsInvoice.Fields.Item("DocCur").Value.ToString();
                                        string DocNum = oRsInvoice.Fields.Item("BeginStr").Value.ToString() + oRsInvoice.Fields.Item("DocNum").Value.ToString() + oRsInvoice.Fields.Item("EndStr").Value.ToString();
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CustRef", i, DocNum);
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Curr", i, DocCur);
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_PayTerm", i, oRsInvoice.Fields.Item("GroupNum").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_ERate", i, DocRate.ToString());


                                        dt = DateTime.Parse(oDataTable.GetValue("DueDate", 0).ToString());
                                        DueDate = dt.ToString("yyyyMMdd");

                                        dt = DateTime.Parse(oDataTable.GetValue("TaxDate", 0).ToString());
                                        DocDate = dt.ToString("yyyyMMdd");

                                        if (DocCur == Company_LocalCurrency)
                                        {
                                            DocTotal = double.Parse(oRsInvoice.Fields.Item("DocTotal").Value.ToString());// oDataTable.GetValue("DocTotal", 0).ToString());
                                        }
                                        else
                                        {
                                            DocTotal = double.Parse(oRsInvoice.Fields.Item("DocTotalFC").Value.ToString()); //oDataTable.GetValue("DocTotalFC", 0).ToString());
                                        }
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Remarks", i, oRsInvoice.Fields.Item("Comments").Value.ToString());
                                    }

                                }
                                else if (TransType == "30")
                                {
                                    DocRate = double.Parse(oDataTable.GetValue("TransRate", 0).ToString());
                                    DocCur = oDataTable.GetValue("OrignCurr", 0).ToString().Trim();

                                    //oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CustRef", i, oDataTable.GetValue("NumAtCard", 0).ToString());// oRs.Fields.Item("NumAtCard").Value.ToString());
                                    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Curr", i, DocCur); //oRs.Fields.Item("DocCur").Value.ToString());
                                    //oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_PayTerm", i, oDataTable.GetValue("GroupNum", 0).ToString());
                                    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_ERate", i, DocRate.ToString());


                                    dt = DateTime.Parse(oDataTable.GetValue("DueDate", 0).ToString());
                                    DueDate = dt.ToString("yyyyMMdd");

                                    dt = DateTime.Parse(oDataTable.GetValue("TaxDate", 0).ToString());
                                    DocDate = dt.ToString("yyyyMMdd");

                                    if (DocCur == Company_LocalCurrency)
                                    {
                                        DocTotal = double.Parse(oDataTable.GetValue("LocTotal", 0).ToString());
                                    }
                                    else
                                    {
                                        DocTotal = double.Parse(oDataTable.GetValue("FcTotal", 0).ToString());
                                    }
                                    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Remarks", i, oDataTable.GetValue("Memo", 0).ToString());

                                }

                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvAmt", i, DocTotal.ToString());
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_OInvAmt", i, DocTotal.ToString());
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_DueDate", i, DueDate);
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_DocDate", i, DocDate);


                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").InsertRecord(oMatrix.VisualRowCount);
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_5").Cells.Item(pVal.Row).Click(BoCellClickType.ct_Regular, 0);
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                if (oPos != null)
                                {
                                    CReportPara.boolCFLSelected = true;
                                    CReportPara.ColNo = oPos.ColumnIndex;
                                    CReportPara.RowNo = oPos.rowIndex;
                                }
                                Calc_TotalAmount(oForm);


                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_VEN")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CardCode", pVal.Row - 1, oDataTable.GetValue("Code", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CardName", pVal.Row - 1, oDataTable.GetValue("Name", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_0").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                CReportPara.boolCFLSelected = true;
                                //SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                //CReportPara.ColNo = oPos.ColumnIndex;
                                //CReportPara.RowNo = oPos.rowIndex;
                            }


                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == "LODG_BILLS")
                            {

                                if (CReportPara.boolCFLSelected)
                                {
                                    CReportPara.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(CReportPara.RowNo, CReportPara.ColNo);
                                    CReportPara.RowNo = 0;
                                    CReportPara.ColNo = 0;
                                }
                                if (MultiInvoiceSelected == true)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                                    //MultiInvoiceSelected = false;
                                    //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    //oMatrix.FlushToDataSource();

                                    //for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size; i++)
                                    //{
                                    //    string InvDocEntry = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvDocE", i).ToString().Trim();
                                    //    string InvDocNum = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvNo", i).ToString().Trim();


                                    //    objclsComman.returnRecord("SELECT * FROM OINV WHERE DOCENTRY='" + InvDocEntry + "'");
                                    //    string NewInvDocNum = oRs.Fields.Item("DocNum").Value.ToString();
                                    //    if (InvDocNum != NewInvDocNum)
                                    //    {
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvNo", i, oRs.Fields.Item("DocNum").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CustRef", i, oRs.Fields.Item("NumAtCard").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Curr", i, oRs.Fields.Item("DocCur").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvAmt", i, oRs.Fields.Item("DocTotal").Value.ToString());

                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_PayTerm", i, oRs.Fields.Item("U_PayTerm").Value.ToString());
                                    //        DateTime dt = DateTime.Parse(oRs.Fields.Item("DocDueDate").Value.ToString());
                                    //        string Date = dt.ToString("yyyyMMdd");
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_DueDate", i, Date);
                                    //    }
                                    //}
                                    //int iFormRowsCount=oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size;
                                    //if (iFormRowsCount == oMatrix.RowCount)
                                    //{
                                    //    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").InsertRecord(oMatrix.VisualRowCount);
                                    //}
                                    //oMatrix.LoadFromDataSource();

                                    //Calc_TotalAmount(oForm);


                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "LODG_BILLS" && pVal.ItemUID == "1")
                            {
                                if (pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                                    #region Close Form when form open from incoming payment
                                    if (closeForm == true)
                                    {
                                        closeForm = false;
                                        string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;
                                        string BaseRow = oForm.DataSources.UserDataSources.Item(udsBaseRow).Value;

                                        oItem = oForm.Items.Item("2");
                                        oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                       
                                        return;
                                    }
                                    #endregion

                                    string Code = oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        return;
                                    }
                                }
                                else if (pVal.FormMode == 1)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;

                                    if (BaseFormUID != string.Empty)
                                    {
                                        string closeFormDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                        string BaseRow = oForm.DataSources.UserDataSources.Item(udsBaseRow).Value;

 
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "LODG_BILLS").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "PostDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "PostDate", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                }

                            }

                            else if (pVal.ItemUID == "BankRef")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string bankRef = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BankRef", 0).Trim();

                                string remarks = "LODGEMENT OF INV. NO. " + " VIDE REF." + bankRef;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Remarks", 0, remarks);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Lodgement Bill Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Lodgement of Bills Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "LODG_BILLS" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvNo", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvNo", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        string DocEntry = oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("DOCENTRY", 0);

                        objclsComman.SelectRecord("DELETE FROM [@LODG_BILLS1] WHERE  (ISNULL(U_INVNO,'')='' OR U_INVNO='0') AND DOCENTRY='" + DocEntry + "'");
                        string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;
                        if (BaseFormUID != string.Empty)
                        {
                            closeForm = true;
                            closeFormDocEntry = DocEntry;
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            CReportPara.boolCFLSelected = false;
            if (MenuID == "LODG_BILLS")
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                oForm = oApplication.Forms.ActiveForm;

                oForm.EnableMenu("1283", false);//Remove
                oForm.EnableMenu("1284", false);//Cancel
                oForm.EnableMenu("1286", false);//Close


                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.DataSources.UserDataSources.Add(udsBaseDoc, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Add(udsBaseRow, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Add(udsBaseFUID, SAPbouiCOM.BoDataType.dt_LONG_TEXT, 40);

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(branchUID).Specific;
                if (isBranchDatabase == "Y")
                {
                    objclsComman.FillCombo(oCombo, "SELECT T0.[BPLId], T0.[BPLName] FROM OBPL T0");
                    objclsComman.SetAutoManagedAttribute_UpdateMode(oCombo.Item);
                }
                else
                {
                    oCombo.Item.Disable();
                }

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("BankName").Specific;
                objclsComman.FillCombo(oCombo, objclsComman.GetBankNameQuery());
                //objclsComman.FillCombo(oCombo, " SELECT BankCode,Max(AcctName)  AcctName FROM DSC1 T0 GROUP BY  BankCode");
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_0", 1);
                objclsComman.FillCombo(oCombo, "SELECT GroupNum,PymntGroup FROM OCTG");
                oMatrix.CommonSetting.EnableArrowKey = true;

                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Customer Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("C"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_CARD", "2", "", "", alCondVal);

                #endregion

                #region JE
                alCondVal = new ArrayList();
                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_JE", "30", "", "", alCondVal);

                SAPbouiCOM.Column oColumn = (SAPbouiCOM.Column)oMatrix.Columns.Item("V_5");
                oColumn.ChooseFromListUID = "CFL_JE";
                #endregion
            }
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Item(udsBaseDoc).Value = "N";
            oForm.DataSources.UserDataSources.Item(udsBaseRow).Value = "-2";
            oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value = "";

            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("PostDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "PostDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "LODG_BILLS").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("DocEntry");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Status");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Canceled");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("mtx");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);


            oItem = oForm.Items.Item("Series");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);


            oItem = oForm.Items.Item("PostDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("CardCode");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);


            oForm.Select();




        }


        private void Calc_TotalAmount(SAPbouiCOM.Form oForm)
        {
            double Amount = 0;
            double TotalAmount = 0;
            for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size; i++)
            {
                Amount = double.Parse(oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvAmt", i).ToString());
                TotalAmount = TotalAmount + Amount;
            }
            oForm.DataSources.DBDataSources.Item("@LODG_BILLS").SetValue("U_Total", 0, TotalAmount.ToString());


        }





        #endregion
    }
}
