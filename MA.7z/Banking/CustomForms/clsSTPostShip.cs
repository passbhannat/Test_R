using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Banking
{
    class clsSTPostShip : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        const string headerTable = "@ST_POSTSHIP";

        const string branchUDF = "U_BPLId";
        const string branchUID = "BPLId";

        bool closeForm = false;
        string closeFormDocEntry = "";
        const string udsBaseDoc = "BaseDoc";
        const string udsBaseFUID = "BaseFUID";
        const string udsBaseRow = "BaseRow";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string query = "";
                            string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(branchUDF, 0).ToString();
                            if (branch == string.Empty && isBranchDatabase == "Y")
                            {
                                oApplication.StatusBar.SetText("Please select branch.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                            if (pVal.ColUID == "V_6")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_CardCode", 0).ToString();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                if (branch == string.Empty)
                                {
                                    query = "SELECT DOCENTRY FROM  OINV WHERE DOCSTATUS='O' AND CARDCODE='" + CardCode + "'";
                                }
                                else
                                {
                                    query = "SELECT DOCENTRY FROM  OINV WHERE DOCSTATUS='O' AND CARDCODE='" + CardCode + "' AND BPLId = '" + branch + "'";
                                }
                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_INV", "13", query, "DocEntry", alCondVal);
                            }
                            else if (pVal.ColUID == "V_10")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                ArrayList alCondVal = new ArrayList();
                                query = "SELECT U_SHPNO FROM  [@OP_POSTSHIP] T0 INNER JOIN [@OP_POSTSHIP1] T1 " +
                                    " ON T0.DOCENTRY=T1.DOCENTRY WHERE   U_OAmtApp>0";
                                if (branch == string.Empty)
                                {
                                    query = "SELECT U_SHPNO FROM  [@OP_POSTSHIP] T0 INNER JOIN [@OP_POSTSHIP1] T1 " +
                                      " ON T0.DOCENTRY=T1.DOCENTRY WHERE   U_OAmtApp>0 ";
                                }
                                else
                                {
                                    query = "SELECT U_SHPNO FROM  [@OP_POSTSHIP] T0 INNER JOIN [@OP_POSTSHIP1] T1 " +
                                     " ON T0.DOCENTRY=T1.DOCENTRY WHERE   U_OAmtApp>0 AND T0.U_BPLId = '" + branch + "'";
                                }

                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_POSH", "OP_POSTSHIP", query, "U_SHPNO", alCondVal);
                            }
                            else if (pVal.ColUID == "V_8")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                string ShpNo = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", pVal.Row)).String;
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                query = "SELECT U_InvDocE FROM  [@OP_POSTSHIP] T0 INNER JOIN [@OP_POSTSHIP1] T1 " +
                                    " ON T0.DOCENTRY=T1.DOCENTRY WHERE  U_SHPNO='" + ShpNo + "' AND U_OAmtApp>0";

                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_INV", "30", query, "TransID", alCondVal);
                            }

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (isBranchDatabase == "Y")
                                    {
                                        string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(branchUDF, 0).ToString();
                                        if (branch == string.Empty)
                                        {
                                            oApplication.StatusBar.SetText("Please select branch.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            BubbleEvent = false;
                                            return;
                                        }
                                    }
                                    if (oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_BankName", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select the bank name.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    else if (oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    //else if (oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("TrPODate", 0).ToString().Trim() == string.Empty)
                                    //{
                                    //    BubbleEvent = false;
                                    //    oApplication.StatusBar.SetText("Please enter Outgoing Payment Post. Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //    return;
                                    //}
                                    else if (oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_Total", 0).ToString().Trim() == string.Empty ||
                                        Convert.ToDouble(oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_Total", 0).ToString().Trim()) == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Amount can't be zero.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1");
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (oDbDataSource.GetValue("U_ShpNo", i).Trim() == string.Empty)
                                        {
                                            continue;
                                        }
                                        if (oDbDataSource.GetValue("U_InvDocE", i).Trim() == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select Trans ID on line " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region pVal.ItemUID == "43" Final Ref No Linked Button Pressed

                            else if (pVal.ItemUID == "43")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                LinkedButton linkedButton = (LinkedButton)oForm.Items.Item(pVal.ItemUID).Specific;
                                string docType = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinObj", 0).Trim();
                                //if (docType == Convert.ToString( (int)Enum.SAPObjectTypeEnum.IncomingPayment))
                                if (docType == Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oIncomingPayments))
                                {
                                    BubbleEvent = false;
                                    linkedButton.LinkedObjectType = docType;
                                    BubbleEvent = true;
                                }
                                else
                                {
                                    BubbleEvent = false;
                                    linkedButton.LinkedObjectType = docType;
                                    BubbleEvent = true;
                                }
                            }

                            #endregion

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Settlement Post Shipment Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_BA")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP");
                                oDbDataSource.SetValue("U_BankANo", 0, oDataTable.GetValue("AcctCode", 0).ToString());
                                oDbDataSource.SetValue("U_BankANm", 0, oDataTable.GetValue("AcctName", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_PS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP");
                                oDbDataSource.SetValue("U_ShpAC", 0, oDataTable.GetValue("AcctCode", 0).ToString());
                                oDbDataSource.SetValue("U_ShpAN", 0, oDataTable.GetValue("AcctName", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_FIACC")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP");
                                oDbDataSource.SetValue("U_FinNo", 0, oDataTable.GetValue("AcctCode", 0).ToString());
                                oDbDataSource.SetValue("U_FinNm", 0, oDataTable.GetValue("AcctName", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_POSH")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific; ;
                                oMatrix.FlushToDataSource();
                                string ShipNo = oDataTable.GetValue("U_ShpNo", 0).ToString();
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_ShpNo", pVal.Row - 1, ShipNo);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_ShpNo", 0, ShipNo);

                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvDocE", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_DocType", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvNo", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_CardName", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_Curr", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_PayTerm", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvAmt", pVal.Row - 1, string.Empty);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_DueDate", pVal.Row - 1, string.Empty);


                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_10").Cells.Item(pVal.Row).Click(BoCellClickType.ct_Regular, 0);
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_INV")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific; ;
                                oMatrix.FlushToDataSource();
                                int i = pVal.Row - 1;
                                string InvDocE = oDataTable.GetValue("TransId", 0).ToString();
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvDocE", i, InvDocE);
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvNo", i, oDataTable.GetValue("BaseRef", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_DocType", i, oDataTable.GetValue("TransType", 0).ToString());

                                if (oDataTable.GetValue("TransType", 0).ToString() == "13")
                                {
                                    string docNum = objclsComman.SelectRecord("SELECT DocNum FROM OINV WHERE TransId = '" + InvDocE + "'");
                                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvNo", i, docNum);
                                }
                                string ShpNo = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").GetValue("U_ShpNo", i).Trim();


                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT U_InvAmt,U_OInvAmt,T1.U_DueDate,U_Curr,U_PayTerm,U_OAmtApp,U_CardName,U_PayTerm,T1.U_DueDate,T1.U_DocDate,T1.U_ERate FROM [@OP_POSTSHIP] T0 INNER JOIN [@OP_POSTSHIP1] T1 ON " +
                                " T0.DOCENTRY=T1.DOCENTRY WHERE T0.U_SHPNO='" + ShpNo + "' and U_InvDocE='" + InvDocE + "'");
                                try
                                {
                                    if (!oRs.EoF)
                                    {

                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_CardName", i, oRs.Fields.Item("U_CardName").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_Curr", i, oRs.Fields.Item("U_Curr").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_PayTerm", i, oRs.Fields.Item("U_PayTerm").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_InvAmt", i, oRs.Fields.Item("U_InvAmt").Value.ToString());// oRs.Fields.Item("DocTotal").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_OAppAmt", i, oRs.Fields.Item("U_OAmtApp").Value.ToString());// oRs.Fields.Item("DocTotal").Value.ToString());
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_ERate", i, oRs.Fields.Item("U_ERate").Value.ToString());

                                        DateTime dt = DateTime.Parse(oRs.Fields.Item("U_DueDate").Value.ToString());
                                        string Date = dt.ToString("yyyyMMdd");
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_DueDate", i, Date);
                                        dt = DateTime.Parse(oRs.Fields.Item("U_DocDate").Value.ToString());
                                        Date = dt.ToString("yyyyMMdd");
                                        oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("U_DocDate", i, Date);

                                    }
                                }
                                catch (Exception ex)
                                {
                                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                }
                                finally
                                {
                                    if (oRs != null)
                                    {
                                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                    }
                                    GC.Collect();
                                    GC.WaitForPendingFinalizers();
                                }

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").InsertRecord(oMatrix.VisualRowCount);
                                }
                                //oMatrix.LoadFromDataSourceEx(true);
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_9").Cells.Item(pVal.Row).Click(BoCellClickType.ct_Regular, 0);
                                // Calc_TotalAmount(oForm);
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                if (oPos != null)
                                {
                                    CReportPara.boolCFLSelected = true;
                                    CReportPara.ColNo = oPos.ColumnIndex;
                                    CReportPara.RowNo = oPos.rowIndex;
                                }
                            }


                        }

                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                if (pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                                    #region Close Form when form open from incoming payment
                                    if (closeForm == true)
                                    {
                                        closeForm = false;
                                        string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;
                                        string BaseRow = oForm.DataSources.UserDataSources.Item(udsBaseRow).Value;

                                        oItem = oForm.Items.Item("2");
                                        oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                        return;
                                    }
                                    #endregion

                                    string Code = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        return;
                                    }
                                }
                                else if (pVal.FormMode == 1)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;

                                    if (BaseFormUID != string.Empty)
                                    {
                                        string closeFormDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                        string BaseRow = oForm.DataSources.UserDataSources.Item(udsBaseRow).Value;
                                         
                                    }
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnCancel"
                            else if (pVal.ItemUID == "btnCancel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    string Canceled = oForm.DataSources.DBDataSources.Item(0).GetValue("Canceled", 0).Trim();
                                    if (Canceled == "Y")
                                    {
                                        oApplication.StatusBar.SetText("Form is already canceled.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                        return;
                                    }
                                    int i = oApplication.MessageBox("Do you really want to cancel the transaction?", 2, "Yes", "No", "");
                                    if (i == 1)
                                    {
                                        string DocEntry = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("DocEntry", 0).Trim();
                                        objclsComman.SelectRecord("UPDATE T0  " +
                                                                  " SET  T0.U_OAmtApp=T0.U_OAmtApp+T1.U_STAmt " +
                                                                   " FROM  [@OP_POSTSHIP] A INNER JOIN   [@OP_POSTSHIP1]  T0 ON A.DOCENTRY=T0.DOCENTRY " +
                                                                   " INNER JOIN [@ST_POSTSHIP1] T1 ON A.U_ShpNo=T1.U_ShpNo AND T0.U_INVDOCE=T1.U_INVDOCE " +
                                                                   " WHERE T1.DOCEnTRY='" + DocEntry + "'");

                                        oForm.DataSources.DBDataSources.Item(0).SetValue("Canceled", 0, "Y");
                                        oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                        oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
                                        return;
                                    }
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Form should be in OK mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "34"
                            else if (pVal.ItemUID == "34")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    string canceled = oForm.DataSources.DBDataSources.Item(0).GetValue("Canceled", 0).Trim();
                                    if (canceled == "Y")
                                    {
                                        oApplication.StatusBar.SetText("Document is canceled!", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    OutgoingPayment(oForm);
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Form should be in OK mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnFinal"
                            else if (pVal.ItemUID == "btnFinal")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    string canceled = oForm.DataSources.DBDataSources.Item(0).GetValue("Canceled", 0).Trim();
                                    if (canceled == "Y")
                                    {
                                        oApplication.StatusBar.SetText("Document is canceled!", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    string finObj = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinObj", 0).Trim();
                                    if (finObj == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Please enter Final Interest Finance Amount", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                        return;
                                    }
                                    if (finObj == Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oIncomingPayments))
                                    {
                                        IncomingPayment_Final(oForm);
                                    }
                                    else
                                    {
                                        OutgoingPayment_Final(oForm);
                                    }
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Form should be in OK mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == "ST_POSTSHIP")
                            {

                                if (CReportPara.boolCFLSelected)
                                {
                                    CReportPara.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(CReportPara.RowNo, CReportPara.ColNo);
                                    CReportPara.RowNo = 0;
                                    CReportPara.ColNo = 0;
                                }

                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "ST_POSTSHIP").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "mtx")
                            {
                                if (pVal.ColUID == "V_3")
                                {
                                    Calc_TotalAmount(oForm);
                                }
                            }
                            else if (pVal.ItemUID == "PostDate")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, "PostDate", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);
                                }

                            }
                            else if (pVal.ItemUID == "TrPODate")
                            {
                                string DocDate = ((SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific).Value;
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("TrSer").Specific;
                                objclsComman.FillCombo_Series_Custom_New(oForm, oCombo, "46", DocDate, "Load");
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_TrSer", 0, string.Empty);
                                }
                            }
                            else if (pVal.ItemUID == "FinPODate")
                            {
                                string DocDate = ((SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific).Value;
                                string finObj = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinObj", 0).Trim();
                                if (finObj == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please Enter finance amout", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("FinSer").Specific;
                                objclsComman.FillCombo_Series_Custom_New(oForm, oCombo, finObj, DocDate, "Load");
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinSer", 0, string.Empty);
                                }
                            }
                            else if (pVal.ItemUID == "FinAmt")
                            {
                                string finAmt = ((SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific).Value;
                                double dblFinAmt = finAmt == string.Empty ? 0 : double.Parse(finAmt);
                                if (dblFinAmt > 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinObj", 0, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oVendorPayments));
                                }
                                else
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinObj", 0, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oIncomingPayments));
                                }
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinPODate", 0, string.Empty);
                                oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinSer", 0, string.Empty);

                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Settlement Post-Shipement Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Settlement of Post-Shipment Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "ST_POSTSHIP" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").GetValue("U_InvNo", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").GetValue("U_InvNo", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {

                        oForm = oApplication.Forms.ActiveForm;
                        string DocEntry = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("DocEntry", 0).Trim();
                        objclsComman.SelectRecord("UPDATE T0  " +
                                                  " SET  T0.U_OAmtApp=T0.U_OAmtApp-T1.U_STAmt " +
                                                   " FROM  [@OP_POSTSHIP] A INNER JOIN   [@OP_POSTSHIP1]  T0 ON A.DOCENTRY=T0.DOCENTRY " +
                                                   " INNER JOIN [@ST_POSTSHIP1] T1 ON A.U_ShpNo=T1.U_ShpNo AND T0.U_INVDOCE=T1.U_INVDOCE " +
                                                   " WHERE T1.DOCEnTRY='" + DocEntry + "'");

                        string BaseFormUID = oForm.DataSources.UserDataSources.Item(udsBaseFUID).Value;
                        if (BaseFormUID != string.Empty)
                        {
                            closeForm = true;
                            closeFormDocEntry = DocEntry;
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");


                        string DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_TrPODate", 0).Trim();
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("TrSer").Specific;
                        objclsComman.FillCombo_Series_Custom_New(oForm, oCombo, "46", DocDate, "View");

                        string finObj = oForm.DataSources.DBDataSources.Item(0).GetValue("U_TrRefNo", 0).Trim();
                        if (finObj != string.Empty)
                        {
                            oForm.Items.Item("BankANo").Disable();
                            oForm.Items.Item("ShpAC").Disable();
                            oForm.Items.Item("TrPODate").Disable();
                            oForm.Items.Item("TrSer").Disable();
                            //oForm.Items.Item("btnCancel").Disable();
                        }
                        else
                        {
                            oForm.Items.Item("BankANo").Enable();
                            oForm.Items.Item("ShpAC").Enable();
                            oForm.Items.Item("TrPODate").Enable();
                            oForm.Items.Item("TrSer").Enable();
                            //oForm.Items.Item("btnCancel").Enable();
                        }

                        finObj = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinObj", 0).Trim();
                        DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinPODate", 0).Trim();
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("FinSer").Specific;
                        if (finObj != string.Empty)
                        {
                            objclsComman.FillCombo_Series_Custom_New(oForm, oCombo, finObj, DocDate, "View");
                            oForm.Items.Item("FinNo").Disable();
                            oForm.Items.Item("FinAmt").Disable();
                            oForm.Items.Item("FinPODate").Disable();
                            oForm.Items.Item("FinSer").Disable();
                        }
                        else
                        {
                            oForm.Items.Item("FinNo").Enable();
                            oForm.Items.Item("FinAmt").Enable();
                            oForm.Items.Item("FinPODate").Enable();
                            oForm.Items.Item("FinSer").Enable();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Methods

        public void LoadForm(string MenuID)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                CReportPara.boolCFLSelected = false;

                if (MenuID == "ST_POSTSHIP")
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1283", false);//Remove
                    oForm.EnableMenu("1284", false);//Cancel
                    oForm.EnableMenu("1286", false);//Close

                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.DataSources.UserDataSources.Add(udsBaseDoc, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Add(udsBaseRow, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Add(udsBaseFUID, SAPbouiCOM.BoDataType.dt_LONG_TEXT, 40);

                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(branchUID).Specific;
                    if (isBranchDatabase == "Y")
                    {
                        objclsComman.FillCombo(oCombo, "SELECT T0.[BPLId], T0.[BPLName] FROM OBPL T0");
                        objclsComman.SetAutoManagedAttribute_UpdateMode(oCombo.Item);
                    }
                    else
                    {
                        oCombo.Item.Disable();
                    }
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("BankName").Specific;
                    objclsComman.FillCombo(oCombo, objclsComman.GetBankNameQuery());
                    //objclsComman.FillCombo(oCombo, "  SELECT BankCode,Max(AcctName)  AcctName FROM DSC1 T0 GROUP BY  BankCode");

                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_2", 1);
                    objclsComman.FillCombo(oCombo, "SELECT GroupNum,PymntGroup FROM OCTG");

                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("FinObj").Specific;
                    objclsComman.FillCombo(oCombo, "SELECT '24','Incoming Payment' UNION ALL SELECT '46','OutGoing Payment' ");


                    oItem = oForm.Items.Item("mtx");
                    objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);


                }


                oForm = oApplication.Forms.ActiveForm;

                #region Series And DocNum
                oForm = oApplication.Forms.ActiveForm;
                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("PostDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, "PostDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "ST_POSTSHIP").ToString();
                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                    #endregion

                }
                catch { }
                #endregion

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }


                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.U_BankAcc,T0.U_ShipAcc ");
                sbQuery.Append(",(SELECT AcctName FROM OACT WHERE AcctCode = T0.U_BankAcc) BankAccN ");
                sbQuery.Append(",(SELECT AcctName FROM OACT WHERE AcctCode = T0.U_ShipAcc) ShipAccN ");
                sbQuery.Append(" FROM [@DEFACCOUNT] T0 ");
                sbQuery.Append(" WHERE T0.Code= '" + (int)Enum.BankingDefaultAccountModuleEnum.SettlementPostShipmentFinance + "' ");

                oRs = objclsComman.returnRecord(sbQuery.ToString());
                oForm.DataSources.DBDataSources.Item(0).SetValue("U_BankANo", 0, oRs.Fields.Item("U_BankAcc").Value.ToString());
                oForm.DataSources.DBDataSources.Item(0).SetValue("U_ShpAC", 0, oRs.Fields.Item("U_ShipAcc").Value.ToString());
                oForm.DataSources.DBDataSources.Item(0).SetValue("U_BankANm", 0, oRs.Fields.Item("BankAccN").Value.ToString());
                oForm.DataSources.DBDataSources.Item(0).SetValue("U_ShpAN", 0, oRs.Fields.Item("ShipAccN").Value.ToString());


                oItem = oForm.Items.Item("DocNum");
                objclsComman.SetAutoManagedAttribute(oItem);

                oItem = oForm.Items.Item("DocEntry");
                objclsComman.SetAutoManagedAttribute(oItem);

                oItem = oForm.Items.Item("Status");
                objclsComman.SetAutoManagedAttribute(oItem);

                oItem = oForm.Items.Item("Canceled");
                objclsComman.SetAutoManagedAttribute(oItem);

                oItem = oForm.Items.Item("PostDate");
                objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

                oForm.Items.Item("BankANo").Enable();
                oForm.Items.Item("ShpAC").Enable();
                oForm.Items.Item("TrPODate").Enable();
                oForm.Items.Item("TrSer").Enable();
                oForm.Items.Item("btnCancel").Enable();

                oItem = oForm.Items.Item("FinNo");
                oItem.Enable();

                oItem = oForm.Items.Item("FinAmt");
                oItem.Enable();

                oForm.Items.Item("FinPODate").Enable();
                oForm.Items.Item("FinSer").Enable();

                oItem = oForm.Items.Item("TrPODate");
                objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

                oItem = oForm.Items.Item("Series");
                objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }


        }



        private void Calc_TotalAmount(SAPbouiCOM.Form oForm)
        {
            double Amount = 0;
            double TotalAmount = 0;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();
            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                try
                {
                    Amount = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_3", i)).String);
                    TotalAmount = TotalAmount + Amount;


                }
                catch { }
            }
            //for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").Size; i++)
            //{
            //    Amount = double.Parse(oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP1").GetValue("U_AmtApp", i).ToString());
            //    TotalAmount = TotalAmount + Amount;
            //}
            oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_Total", 0, TotalAmount.ToString());


        }

        public bool IncomingPayment_Final(SAPbouiCOM.Form oForm)
        {
            try
            {
                string TrDocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinDocE", 0);
                if (TrDocE.Trim() != string.Empty)
                {
                    oApplication.StatusBar.SetText("Incoming payment already created", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }
                string PD = ((SAPbouiCOM.EditText)oForm.Items.Item("FinPODate").Specific).Value;
                if (PD.Trim() == string.Empty)
                {
                    oApplication.StatusBar.SetText("Please enter incoming posting date.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }
                string TrSer = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinSer", 0).Trim();
                if (TrSer == string.Empty)
                {
                    oApplication.StatusBar.SetText("Please select incoming Series.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }

                double dTotalPayment = (-1) * Convert.ToDouble(oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinAmt", 0).Trim());

                string sGLAccount = oForm.DataSources.DBDataSources.Item(0).GetValue("U_BankANo", 0).Trim();
                string sTrustGLAccount = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinNo", 0).Trim();

                DateTime sPostingDate = objclsComman.ConvertStrToDate(PD, "yyyyMMdd");

                SAPbobsCOM.Payments oPayments = (SAPbobsCOM.Payments)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oIncomingPayments);
                oPayments.DocType = SAPbobsCOM.BoRcptTypes.rAccount;

                oPayments.Series = Int32.Parse(TrSer);
                oPayments.DocDate = sPostingDate;
                oPayments.DueDate = sPostingDate;
                oPayments.TransferAccount = sGLAccount;
                oPayments.TransferSum = dTotalPayment;

                #region A/C Payment Line Details
                oPayments.AccountPayments.AccountCode = sTrustGLAccount;
                oPayments.AccountPayments.SumPaid = dTotalPayment;
                #endregion
                oPayments.TransferDate = sPostingDate;
                oPayments.PaymentType = SAPbobsCOM.BoORCTPaymentTypeEnum.bopt_Post;
                oPayments.Remarks = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Remarks2", 0).Trim();
                oPayments.JournalRemarks = "Final Interest Amount document";

                int iResult = oPayments.Add();
                if (iResult != 0)
                {
                    int num2;
                    string str;
                    oCompany.GetLastError(out num2, out str);
                    if (num2 != 0)
                    {
                        oApplication.MessageBox(str, 0, "Ok", "", "");
                    }
                    return false;
                }
                else
                {
                    string newDocEntry = "";
                    oCompany.GetNewObjectCode(out newDocEntry);
                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinDocE", 0, newDocEntry);
                    string DocNum = objclsComman.SelectRecord("SELECT DOCNUM FROM ORCT WHERE DOCENTRY='" + newDocEntry + "'");
                    oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinRefNo", 0, DocNum);

                    oApplication.StatusBar.SetText("Incoming Payment DocNo: " + DocNum + " has been created.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                    oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
                    return true;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
                return false;
            }
        }

        public bool OutgoingPayment_Final(SAPbouiCOM.Form oForm)
        {
            try
            {
                string formDocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();

                string TrDocE = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinDocE", 0).Trim();
                if (TrDocE.Trim() != string.Empty)
                {
                    oApplication.StatusBar.SetText("Outgoing payment already created", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }
                string TrSer = oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinSer", 0).Trim();
                if (TrSer == string.Empty)
                {
                    oApplication.StatusBar.SetText("Please select outgoing Series.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }

                double dTotalPayment = Convert.ToDouble(oForm.DataSources.DBDataSources.Item(0).GetValue("U_FinAmt", 0).Trim());

                string sGLAccount = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_BankANo", 0).Trim();
                string sTrustGLAccount = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_FinNo", 0).Trim();
                string PD = ((SAPbouiCOM.EditText)oForm.Items.Item("FinPODate").Specific).Value;
                DateTime sPostingDate = objclsComman.ConvertStrToDate(PD, "yyyyMMdd");

                SAPbobsCOM.Payments oPayments = (SAPbobsCOM.Payments)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments);
                oPayments.DocType = SAPbobsCOM.BoRcptTypes.rAccount;
                oPayments.Series = Int32.Parse(TrSer);
                oPayments.DocDate = sPostingDate;
                oPayments.TransferAccount = sGLAccount;
                oPayments.TransferSum = dTotalPayment;

                #region A/C Payment Line Details
                oPayments.AccountPayments.AccountCode = sTrustGLAccount;
                oPayments.AccountPayments.SumPaid = dTotalPayment;
                #endregion
                oPayments.TransferDate = sPostingDate;
                oPayments.PaymentType = SAPbobsCOM.BoORCTPaymentTypeEnum.bopt_Post;
                oPayments.Remarks = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Remarks2", 0).Trim();
                oPayments.JournalRemarks = "Final Interest Amount document ";

                int iResult = oPayments.Add();
                if (iResult != 0)
                {
                    int num2;
                    string str;
                    oCompany.GetLastError(out num2, out str);
                    if (num2 != 0)
                    {
                        oApplication.MessageBox(str, 0, "Ok", "", "");
                    }
                    return false;
                }
                else
                {
                    string newDocEntry = "";
                    oCompany.GetNewObjectCode(out newDocEntry);
                    string newDocNum = objclsComman.SelectRecord("SELECT DOCNUM FROM OVPM WHERE DOCENTRY='" + newDocEntry + "'");

                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinDocE", 0, newDocEntry);
                    // string DOCDATE = objclsComman.SelectRecord("SELECT DOCDATE FROM OVPM WHERE DOCENTRY='" + sTrgNo + "'");
                    //DateTime dt = Convert.ToDateTime(DOCDATE);
                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinRefNo", 0, newDocNum);
                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_FinPODate", 0, dt.ToString("yyyyMMdd"));
                    objclsComman.SelectRecord("UPDATE \"" + headerTable + "\" SET U_FinDocE = '" + newDocEntry + "', U_FinRefNo = '" + newDocNum + "' WHERE DocEntry = '" + formDocEntry + "'");

                    oApplication.StatusBar.SetText("Outgoing Payment DocNo: " + newDocNum + " has been created.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    objclsComman.RefreshRecord();
                    //oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                    //oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
                    return true;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
                return false;
            }
        }

        public bool OutgoingPayment(SAPbouiCOM.Form oForm)
        {
            try
            {
                string formDocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();

                string TrDocE = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_TrDocE", 0).Trim();
                if (TrDocE.Trim() != string.Empty)
                {
                    oApplication.StatusBar.SetText("Outgoing payment already created", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }
                string TrSer = oForm.DataSources.DBDataSources.Item(0).GetValue("U_TrSer", 0).Trim();
                if (TrSer == string.Empty)
                {
                    oApplication.StatusBar.SetText("Please select outgoing Series.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return false;
                }
                //double dTotalPayment = -1 * Convert.ToDouble(oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_PreShAm", 0).Trim());
                double dTotalPayment = Convert.ToDouble(oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_Total", 0).Trim());

                string sGLAccount = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_BankANo", 0).Trim();
                string sTrustGLAccount = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_ShpAC", 0).Trim();
                //  string sTrustDocNum = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_ShpNo", 0).Trim();
                string PD = ((SAPbouiCOM.EditText)oForm.Items.Item("PostDate").Specific).Value;
                DateTime sPostingDate = objclsComman.ConvertStrToDate(PD, "yyyyMMdd");


                SAPbobsCOM.Payments oPayments = (SAPbobsCOM.Payments)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oVendorPayments);
                oPayments.DocType = SAPbobsCOM.BoRcptTypes.rAccount;
                oPayments.Series = Int32.Parse(TrSer);
                oPayments.DocDate = sPostingDate;
                //oPayments.DocCurrency = sDocCurrency;
                oPayments.TransferAccount = sGLAccount;
                oPayments.TransferSum = dTotalPayment;

                #region A/C Payment Line Details
                oPayments.AccountPayments.AccountCode = sTrustGLAccount;
                oPayments.AccountPayments.SumPaid = dTotalPayment;
                //oPayments.AccountPayments.Decription = "Bank Charges Posting No - " + sTrustDocNum.ToString();
                #endregion
                oPayments.TransferDate = sPostingDate;
                oPayments.PaymentType = SAPbobsCOM.BoORCTPaymentTypeEnum.bopt_Post;
                oPayments.Remarks = oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").GetValue("U_Remarks", 0).Trim();
                //oPayments.JournalRemarks = "Post-shipment document no. - " + sTrustDocNum.ToString();
                //oPayments.TransferReference = sTrustDocNum.ToString();


                int iResult = oPayments.Add();
                if (iResult != 0)
                {
                    int num2;
                    string str;
                    oCompany.GetLastError(out num2, out str);
                    if (num2 != 0)
                    {
                        oApplication.MessageBox(str, 0, "Ok", "", "");
                    }
                    return false;
                }
                else
                {
                    string newDocEntry = "";
                    oCompany.GetNewObjectCode(out newDocEntry);
                    string newDocNum = objclsComman.SelectRecord("SELECT DOCNUM FROM OVPM WHERE DOCENTRY='" + newDocEntry + "'");
                    string DOCDATE = objclsComman.SelectRecord("SELECT DOCDATE FROM OVPM WHERE DOCENTRY='" + newDocEntry + "'");
                    DateTime dt = Convert.ToDateTime(DOCDATE);
                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_TrDocE", 0, newDocEntry);
                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_TrRefNo", 0, newDocNum);
                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_TrPODate", 0, dt.ToString("yyyyMMdd"));
                    oForm.DataSources.DBDataSources.Item("@ST_POSTSHIP").SetValue("U_TrObj", 0, "46");//46 - Outgoing PAyment

                    objclsComman.SelectRecord("UPDATE \"" + headerTable + "\" SET U_TrDocE = '" + newDocEntry + "', U_TrRefNo = '" + newDocNum + "', U_TrPODate = '" + dt.ToString("yyyyMMdd") + "', U_TrObj = '46' WHERE DocEntry = '" + formDocEntry + "'");

                    oApplication.StatusBar.SetText("Outgoing Payment DocNo: " + newDocNum + " has been created.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    objclsComman.RefreshRecord();
                    //oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                    //oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
                    return true;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
                return false;
            }
        }


        #endregion
    }
}
