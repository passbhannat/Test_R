using System;
using System.Collections.Generic;
using System.Text;

namespace Banking
{
    class CReportPara
    {
    
        #region Global Variable
        private static string sServer;
        private static string sDbName;
        private static string sDbUser;
        private static string sDbPass;
        private static string oBaseFormUID;
        private static bool oboolCFLSelected;
        private static int iRowNo, iColNo;

       #endregion 
         
        # region Login Information 
       
        public static string Server
        {
            get { return sServer; }
            set { sServer = value; }
        }

        public static string DbName
        {
            get { return sDbName; }
            set { sDbName = value; }
        }

        public static string DbUser
        {
            get { return sDbUser; }
            set { sDbUser = value; }
        }

        public static string DbPass
        {
            get { return sDbPass; }
            set { sDbPass = value; }
        }




        #endregion

        #region Variables

        public static string BaseFormUID
        {
            get { return oBaseFormUID; }
            set { oBaseFormUID = value; }
        }
        public static bool boolCFLSelected
        {
            get { return oboolCFLSelected; }
            set { oboolCFLSelected = value; }
        }
        public static int RowNo
        {
            get { return iRowNo; }
            set { iRowNo = value; }
        }
        public static int ColNo
        {
            get { return iColNo; }
            set { iColNo = value; }
        }
        #endregion


    }
}
