﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banking
{
    public class Enum
    {
        public enum BankingDefaultAccountModuleEnum
        {
            OpeningPreShipmentFinance = 1,
            SettlementPreShipmentFinance = 2,
            OpeningPostShipmentFinance = 3,
            SettlementPostShipmentFinance = 4,
        }      

        public enum SAPCommonMaskModeEnum
        {
            All = -1,
            Ok = 1,
            Add = 2,
            Find = 4,
            View = 8
        }
    }
}
