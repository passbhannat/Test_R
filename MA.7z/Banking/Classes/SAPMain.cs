using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;

namespace Banking
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();
         
        SAPbouiCOM.Form oForm;

        clsLodgementBill objclsLodgementBill = new clsLodgementBill();
        clsOpPreShip objclsOpPreShip = new clsOpPreShip();
        clsSTPreShip objclsSTPreShip = new clsSTPreShip();
        clsOpPostShip objclsOpPostShip = new clsOpPostShip();
        clsSTPostShip objclsSTPostShip = new clsSTPostShip();
         
        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            oForm = oApplication.Forms.GetFormByTypeAndCount(169, 1); // Get reference to the Center form

            
            //oForm.Freeze(true);
            PrepareMenus();
            //oForm.Freeze(false);
            //oForm.Update();
            PrepareEvents();         
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            string superUser = objclsComman.SelectRecord("SELECT SUPERUSER FROM OUSR WHERE USERID='" + oCompany.UserSignature + "'");
            if (superUser == "Y")
            {
                objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "BUDO", "Create Banking UDO",string.Empty, 0);
            }

            objclsComman.AddMenu(BoMenuType.mt_POPUP, "43537", "Banking", "Settlement Customization", string.Empty, 16);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "Banking", "LODG_BILLS", "Lodgment of Bills", string.Empty, 0);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "Banking", "OP_PRESHIP", "Opening Pre-Shipment Finance", string.Empty, 1);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "Banking", "ST_PRESHIP", "Settlement Pre-Shipment Finance", string.Empty, 2);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "Banking", "OP_POSTSHIP", "Opening Post-Shipment Finance", string.Empty, 3);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "Banking", "ST_POSTSHIP", "Settlement Post-Shipment Finance", string.Empty, 4);

            //AddMenu(BoMenuType.mt_POPUP, "4352", "PROD", "Production Customization", 16);
            //AddMenu(BoMenuType.mt_STRING, "PROD", "PROD_OIGE", "Multiple Issue For Production", 0);
            //AddMenu(BoMenuType.mt_STRING, "PROD", "PROD_OIGN", "Multiple Receipt From Production", 1);
        }

        public void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));

            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
        }

        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
           
            try
            {                          
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                     
                }
                catch { }
                switch (pVal.FormTypeEx)
                {


                    case "LODG_BILLS":
                        objclsLodgementBill.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                    case "OP_PRESHIP":
                        objclsOpPreShip.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                    case "ST_PRESHIP":
                        objclsSTPreShip.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                    case "OP_POSTSHIP":
                        objclsOpPostShip.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                    case "ST_POSTSHIP":
                        objclsSTPostShip.ItemEvent(FormUID, ref pVal, out BubbleEvent);
                        break;
                }
            }
            catch { }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "BUDO")
                {
                    objclsComman.CreateDataBase();
                    oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                }
                else if (pVal.MenuUID == "CS_RFIELD")
                {
                    objclsComman.LoadFromXML(pVal.MenuUID, "", "");
                }


                if (pVal.MenuUID == "LODG_BILLS" || oForm.TypeEx == "LODG_BILLS")
                {
                    objclsLodgementBill.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "OP_PRESHIP" || oForm.TypeEx == "OP_PRESHIP")
                {
                    objclsOpPreShip.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "ST_PRESHIP" || oForm.TypeEx == "ST_PRESHIP")
                {
                    objclsSTPreShip.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "OP_POSTSHIP" || oForm.TypeEx == "OP_POSTSHIP")
                {
                    objclsOpPostShip.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "ST_POSTSHIP" || oForm.TypeEx == "ST_POSTSHIP")
                {
                    objclsSTPostShip.MenuEvent(ref pVal, out BubbleEvent);
                }
                
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message, 1, "Ok", "Cancel", "");
            }
        }
             
        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            switch (BusinessObjectInfo.FormTypeEx)
            {
                case "LODG_BILLS":
                    objclsLodgementBill.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "OP_PRESHIP":
                    objclsOpPreShip.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "OP_POSTSHIP":
                    objclsOpPostShip.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "ST_PRESHIP":
                    objclsSTPreShip.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                case "ST_POSTSHIP":
                    objclsSTPostShip.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                    break;
                      
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            logger.DebugFormat("> {0}", nameof(oApplication_AppEvent));
            string projectAssemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(projectAssemblyName + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    System.Windows.Forms.Application.Exit();

                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(projectAssemblyName + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(projectAssemblyName + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(projectAssemblyName + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Environment.Exit(0);
                    break;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
