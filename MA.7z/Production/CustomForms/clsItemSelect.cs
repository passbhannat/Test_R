using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Production
{
    class clsItemSelect : Connection
    {
        #region Variables

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {

                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                    oForm = clsVariables.BaseForm;

                                    bool IsSeletedRow = false;
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            IsSeletedRow = true;
                                            break;
                                        }
                                    }
                                    if (IsSeletedRow == false)
                                    {
                                        return;
                                    }
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1");

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.Clear();
                                    oMatrix.FlushToDataSource();

                                    int Row = 0;
                                    string SelectedSO = string.Empty;
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            string SODocEntry = oDataTable.GetValue("DocEntry", i).ToString();
                                            string LineNum = oDataTable.GetValue("LineNum", i).ToString();
                                            string OpenQty = oDataTable.GetValue("OpenQty", i).ToString();


                                            SelectedSO = SelectedSO + "  '" + oDataTable.GetValue("DocEntry", i).ToString() + "' ,";



                                            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(" SELECT T0.*,T1.DOCNUM,T1.NumAtCard,T2.USERTEXT FROM RDR1 T0 " +
                                                  " INNER JOIN ORDR T1 ON T0.DOCENTRY= T1.DOCENTRY " +
                                                  " INNER JOIN OITM T2 ON T0.ITEMCODE = T2.ITEMCODE " +
                                                  " WHERE T0.DOCENTRY='" + SODocEntry + "' AND T0.LINENUM='" + LineNum + "'");
                                            try
                                            {
                                                while (!oRs.EoF)
                                                {
                                                    oDbDataSource.InsertRecord(Row + 1);
                                                    oDbDataSource.SetValue("LineId", Row, (Row + 1).ToString());
                                                    oDbDataSource.SetValue("U_ItemCode", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                                                    oDbDataSource.SetValue("U_ItemName", Row, oRs.Fields.Item("Dscription").Value.ToString());
                                                    oDbDataSource.SetValue("U_MARKING", Row, oRs.Fields.Item("USERTEXT").Value.ToString());
                                                    oDbDataSource.SetValue("U_NumAtCar", Row, oRs.Fields.Item("NumAtCard").Value.ToString());

                                                    oDbDataSource.SetValue("U_Quantity", Row, OpenQty);
                                                    oDbDataSource.SetValue("U_BCOQty", Row, OpenQty);
                                                    oDbDataSource.SetValue("U_OpenQty", Row, OpenQty);
                                                    oDbDataSource.SetValue("U_WhsCode", Row, oRs.Fields.Item("WhsCode").Value.ToString());

                                                    oDbDataSource.SetValue("U_Rate", Row, oRs.Fields.Item("PRICE").Value.ToString());

                                                    oDbDataSource.SetValue("U_Amount", Row, Convert.ToString(double.Parse(OpenQty) * double.Parse(oRs.Fields.Item("PRICE").Value.ToString())));

                                                    oDbDataSource.SetValue("U_Netwt", Row, oRs.Fields.Item("U_NETWT").Value.ToString());

                                                    oDbDataSource.SetValue("U_GrsWt", Row, Math.Round(double.Parse(oRs.Fields.Item("U_GRSWT").Value.ToString()), 2).ToString());//Pravin
                                                    oDbDataSource.SetValue("U_NoCrat", Row, oRs.Fields.Item("PACKQTY").Value.ToString());
                                                    oDbDataSource.SetValue("U_NoPack", Row, oRs.Fields.Item("U_NOPACKING").Value.ToString());

                                                    oDbDataSource.SetValue("U_PCCrate", Row, oRs.Fields.Item("U_CRTWT").Value.ToString());
                                                    oDbDataSource.SetValue("U_WtPack", Row, oRs.Fields.Item("U_TOTCRTWT").Value.ToString());

                                                    oDbDataSource.SetValue("U_BaseRef", Row, oRs.Fields.Item("DOCNUM").Value.ToString());
                                                    oDbDataSource.SetValue("U_BaseKey", Row, oRs.Fields.Item("DOCENTRY").Value.ToString());
                                                    oDbDataSource.SetValue("U_BaseLine", Row, oRs.Fields.Item("LINENUM").Value.ToString());
                                                    oDbDataSource.SetValue("U_BaseType", Row, oRs.Fields.Item("OBJTYPE").Value.ToString());


                                                    Row++;
                                                    oRs.MoveNext();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            }
                                            finally
                                            {
                                                if (oRs != null)
                                                {
                                                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                                                }
                                                GC.Collect();
                                                GC.WaitForPendingFinalizers();
                                            }
                                        }
                                    }
                                    oMatrix.LoadFromDataSource();
                                    if (SelectedSO.Length > 0)
                                    {
                                        SelectedSO = SelectedSO.Remove(SelectedSO.Length - 1, 1);

                                        string TotalExpns = objclsComman.SelectRecord(" SELECT CASE WHEN DocRate=1 THEN SUM(TOTALEXPNS) ELSE SUM(TotalExpFC) END FROM ORDR WHERE DOCENTRY IN (" + SelectedSO + ") GROUP BY DocRate ");
                                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_OthChg", 0, TotalExpns);
                                    }
                                    //clsDispPlan obj = new clsDispPlan();
                                    //obj.Calc_DetailFields(oForm);
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnSel"
                            else if (pVal.ItemUID == "btnSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "Y";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnDSel"
                            else if (pVal.ItemUID == "btnDSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "N";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion
                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Selection Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
