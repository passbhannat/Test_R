using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using General.Classes;

namespace Production
{
    class clsMultipleReceipt : Connection
    {
        #region Variables
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;

        const string headerTable = "@PROD_OIGN";
        const string rowTable = "@PROD_IGN1";

        const string CFL_WHS = "CFL_WHS";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {



                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("U_PrdType", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Select the Production Type.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("U_RecDate", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Enter the Receipt Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("U_RecSer", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Enter the Receipt Series", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGN1");
                                    bool IsSelected = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (oDbDataSource.GetValue("U_Select", i).ToString() == "Y")
                                        {
                                            IsSelected = true;
                                            break;
                                        }
                                    }
                                    if (IsSelected == false)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("No row is selected from Matrix.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region pVal.ItemUID == "btnSel"
                            else if (pVal.ItemUID == "btnSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGN1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "Y");
                                }
                                oMatrix.LoadFromDataSource();
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnUn"
                            else if (pVal.ItemUID == "btnUn")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGN1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "N");
                                }
                                oMatrix.LoadFromDataSource();
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnFill"
                            else if (pVal.ItemUID == "btnFill")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                FillData(oForm);
                            }
                            #endregion

                            #region pVal.ItemUID == "btnCreate"
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string Type = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PrdType", 0).Trim();
                                oApplication.StatusBar.SetText("Please wait...", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                                if (Type == "D")
                                {
                                    GoodsReceipt_Production_DisAssembly(pVal.FormUID);
                                }
                                else
                                {
                                    GoodsReceipt_Production(pVal.FormUID);
                                }
                                oApplication.StatusBar.SetText("Operation Completed.", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);

                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_WHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }

                        }

                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "PROD_OIGN" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("DocNum", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    //AutoCode(oForm);

                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            #region DocDate
                            if (pVal.ItemUID == "RecDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "59", "RecSer", "RecDate", "Load");
                                //oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                //if (oCombo.ValidValues.Count == 0)
                                //{
                                //    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                //}

                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "PROD_OIGN" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("DOCENTRY", 0);
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        objclsComman.SelectRecord("DELETE FROM [@PROD_IGN1] WHERE (U_ProdDE IS NULL OR ISNULL(U_SELECT,'N')='N') AND DOCENTRY='" + Form_DocEntry + "'");


                        // GoodsReceipt_Production(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("RecSer").Specific;
                        oCombo.ValidValues.LoadSeries("59", SAPbouiCOM.BoSeriesMode.sf_View);

                        oItem = oForm.Items.Item("btnFill");
                        oItem.Visible = false;
                        oItem = oForm.Items.Item("btnSel");
                        oItem.Visible = false;
                        oItem = oForm.Items.Item("btnUn");
                        oItem.Visible = false;
                        string Exist = objclsComman.SelectRecord("SELECT 1 FROM [@PROD_IGN1] WHERE U_TrgDocE IS NULL AND U_Select='Y' AND DOCENTRY='" + Form_DocEntry + "'");
                        if (Exist == "1")
                        {
                            oItem = oForm.Items.Item("btnCreate");
                            oItem.Visible = true;
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        }
                        else
                        {
                            oItem = oForm.Items.Item("btnCreate");
                            oItem.Visible = false;
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            if (MenuID == "PROD_OIGN")
            {
                //objclsComman.LoadFromXML(MenuID, "DocEntry", "A");
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                //oForm = oApplication.Forms.Item(MenuID);
                oForm.EnableMenu("5895", true);

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("PrdType").Specific;
                objclsComman.FillCombo_UDFValue(oCombo, "@PROD_OIGN", "PrdType");


                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;



            }

            //oForm = oApplication.Forms.Item("PROD_OIGN");
            oForm = oApplication.Forms.ActiveForm;

            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                //objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "PROD_OIGN").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("PrdType");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            //oItem = oForm.Items.Item("Furnace");
            //objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            //oItem = oForm.Items.Item("Shift");
            //objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("SFrDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("SToDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            //oItem = oForm.Items.Item("mtx");
            //objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("RecSer");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("RecDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("btnFill");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnSel");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnUn");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnCreate");
            oItem.Visible = false;
            oForm.Select();




        }

        private void FillContactPerson(SAPbouiCOM.Form oForm, string CardCode)
        {
            SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("CntCode").Specific;
            objclsComman.FillCombo(oCombo, "SELECT CNTCTCODE,NAME FROM OCPR WHERE CardCode='" + CardCode + "' ORDER BY CNTCTCODE");

            string DefContactPerson = objclsComman.SelectRecord("SELECT T1.CNTCTCODE FROM OCRD T0 INNER JOIN OCPR T1 ON T0.CARDCODE=T1.CARDCODE WHERE T0.CardCode='" + CardCode + "'");
            oForm.DataSources.DBDataSources.Item("@PROD_OIGN").SetValue("U_CntCode", 0, DefContactPerson);

        }

        private void FillData(SAPbouiCOM.Form oForm)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                string Type = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PrdType", 0).Trim();
                string SFrDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SFrDate", 0).Trim();
                string SToDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SToDate", 0).Trim();
                string Furnace = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Furnace", 0).Trim();
                string WhsCode = oForm.DataSources.DBDataSources.Item(0).GetValue("U_WhsCode", 0).Trim();
                if (string.IsNullOrEmpty(WhsCode))
                {
                    oApplication.StatusBar.SetText("Please select the warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    return;
                }
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT * FROM OWOR T0 INNER JOIN NNM1 T1 ON T0.SERIES=T1.SERIES ");
                sbQuery.Append("  WHERE NOT EXISTS( SELECT 1 FROM [@PROD_IGN1] A WHERE T0.DOCENTRY=A.U_ProdDE) AND STATUS='R' ");
               
                oRs = objclsComman.returnRecord(sbQuery.ToString());

                int Row = 0;
                oMatrix.Clear();
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGN1");
                int TotalRows = oRs.RecordCount;
                while (!oRs.EoF)
                {
                    oDbDataSource.SetValue("U_ProdSer", Row, oRs.Fields.Item("SeriesName").Value.ToString());
                    oDbDataSource.SetValue("U_ProdNo", Row, oRs.Fields.Item("DocNum").Value.ToString());
                    oDbDataSource.SetValue("U_ProdDE", Row, oRs.Fields.Item("DocEntry").Value.ToString());
                    oDbDataSource.SetValue("U_ProdDate", Row, Convert.ToDateTime(oRs.Fields.Item("PostDate").Value.ToString()).ToString("yyyyMMdd"));
                    oDbDataSource.SetValue("U_StDate", Row, Convert.ToDateTime(oRs.Fields.Item("DueDate").Value.ToString()).ToString("yyyyMMdd"));
                    oDbDataSource.SetValue("U_PItem", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                    oDbDataSource.SetValue("U_Quantity", Row, oRs.Fields.Item("PlannedQty").Value.ToString());
                    oDbDataSource.SetValue("U_WhsCode", Row, oRs.Fields.Item("Warehouse").Value.ToString());

                    if (TotalRows - 1 != Row)
                    {
                        oDbDataSource.InsertRecord(Row);
                    }
                    oRs.MoveNext();
                    Row++;
                }
                oMatrix.LoadFromDataSource();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        private void GoodsReceipt_Production(string FormUID)
        {
            StringBuilder sbMessage = new StringBuilder();
            oForm = oApplication.Forms.Item(FormUID);
            string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("DOCENTRY", 0);
            SAPbouiCOM.DataTable oPrdDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("PrdDataTable");
            }
            catch { }
            oPrdDataTable = oForm.DataSources.DataTables.Item("PrdDataTable");

            SAPbouiCOM.DataTable oRecDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("RecDataTable");
            }
            catch { }
            oRecDataTable = oForm.DataSources.DataTables.Item("RecDataTable");
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT * FROM [@PROD_IGN1] WHERE DOCENTRY='" + Form_DocEntry + "' AND U_Select='Y' AND ISNULL(U_TrgDocN,'')=''");

            SAPbobsCOM.Recordset oRsRecord = objclsComman.returnRecord(sbQuery.ToString());
            if (oRsRecord.RecordCount == 0)
            {
                oApplication.StatusBar.SetText("No Record found to be Receipt", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                return;
            }
            if (oRsRecord != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsRecord);
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();

            string AnnexureNo = string.Empty;
            oPrdDataTable.ExecuteQuery(sbQuery.ToString());

            for (int i = 0; i < oPrdDataTable.Rows.Count; i++)
            {
                try
                {
                    SAPbobsCOM.Documents IssueToProd = null;
                    IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                    // IssueToProd.DocDate = DateTime.Now;
                    string DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_RecDate", 0).Trim();
                    DateTime dtDocDate = DateTime.ParseExact(DocDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                    IssueToProd.DocDate = dtDocDate; //DateTime.Now;

                    IssueToProd.Series = Int32.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("U_RecSer", 0).Trim());

                    string GRDocEntry = string.Empty;

                    string PrdDocEntry = oPrdDataTable.Columns.Item("U_ProdDE").Cells.Item(i).Value.ToString();  //oRs_Production.Fields.Item("U_ProdDE").Value.ToString();
                    AnnexureNo = objclsComman.SelectRecord("SELECT TOP 1 U_ANXRE FROM WOR1 WHERE DOCENTRY='" + PrdDocEntry + "'");

                    string query = "SELECT ItemCode,PlannedQty,Warehouse,-1 LineNum  FROM OWOR WHERE DOCENTRY='" + PrdDocEntry + "' UNION ALL " +
                                               " SELECT ItemCode,PlannedQty*(-1) PlannedQty,Warehouse,LineNum FROM WOR1 WHERE DOCENTRY='" + PrdDocEntry + "'  AND PlannedQty<0 ";
                    oRecDataTable.ExecuteQuery(query);


                    for (int Row = 0; Row < oRecDataTable.Rows.Count; Row++)
                    {

                        if (Row > 0)
                        {
                            IssueToProd.Lines.Add();
                        }
                        IssueToProd.Lines.BaseType = 202;
                        IssueToProd.Lines.BaseEntry = Int32.Parse(PrdDocEntry);
                        // IssueToProd.Lines.ItemCode = oRecDataTable.Columns.Item("ItemCode").Cells.Item(Row).Value.ToString();
                        int BaseLine = int.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                        if (BaseLine != -1)
                        {
                            IssueToProd.Lines.BaseLine = Int32.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                        }
                        //IssueToProd.Lines.BaseLine = Int32.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                        string Quantity = oRecDataTable.Columns.Item("PlannedQty").Cells.Item(Row).Value.ToString();
                        IssueToProd.Lines.Quantity = double.Parse(Quantity);
                        IssueToProd.Lines.WarehouseCode = oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString();

                        string branch = objclsComman.SelectRecord("SELECT \"BPLid\" FROM OWHS WHERE \"WhsCode\" = '" + oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString() + "'");
                        if (branch != string.Empty)
                        {
                            IssueToProd.BPL_IDAssignedToInvoice = int.Parse(branch);
                        }
                        try
                        {
                            IssueToProd.Lines.UserFields.Fields.Item("U_ANXTR").Value = AnnexureNo;
                        }
                        catch { }
                        IssueToProd.Lines.SetCurrentLine(Row);
                        //Row++;
                        //oRsGI.MoveNext();
                    }


                    long lretcode = IssueToProd.Add();

                    if (lretcode != 0)
                    {
                        int Errcode; string ErrMsg;
                        oCompany.GetLastError(out Errcode, out ErrMsg);
                        oApplication.SetStatusBarMessage("Receipt From Production : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                        // oApplication.MessageBox("Receipt From Production  : " + ErrMsg, 1, "OK", "", "");
                        GRDocEntry = "";
                        sbMessage.Append(Environment.NewLine);
                        sbMessage.Append("For Prd Docentry: " + PrdDocEntry + " : " + ErrMsg);
                    }
                    else
                    {
                        GRDocEntry = oCompany.GetNewObjectKey();
                        string GRDocNum = objclsComman.SelectRecord(" SELECT DOCNUM FROM OIGN WHERE DOCENTRY='" + GRDocEntry + "'");
                        objclsComman.SelectRecord("UPDATE [@PROD_IGN1] SET U_TrgDocE='" + GRDocEntry + "', U_TrgDocN='" + GRDocNum + "', U_TrgObj='59' WHERE DOCENTRY='" + Form_DocEntry + "' AND U_ProdDE='" + PrdDocEntry + "'");

                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }

            if (sbMessage.Length > 0)
            {
                oApplication.MessageBox("Receipt From Production Error : " + sbMessage.ToString(), 1, "OK", "", "");
            }
            else
            {
                oApplication.ActivateMenuItem("1289");
                oApplication.ActivateMenuItem("1288");
            }

        }

        private void GoodsReceipt_Production_DisAssembly(string FormUID)
        {
            oForm = oApplication.Forms.Item(FormUID);

            string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGN").GetValue("DOCENTRY", 0);
            SAPbouiCOM.DataTable oPrdDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("PrdDataTable");
            }
            catch { }
            oPrdDataTable = oForm.DataSources.DataTables.Item("PrdDataTable");

            SAPbouiCOM.DataTable oRecDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("RecDataTable");
            }
            catch { }
            oRecDataTable = oForm.DataSources.DataTables.Item("RecDataTable");

            try
            {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT * FROM [@PROD_IGN1] WHERE DOCENTRY='" + Form_DocEntry + "' AND U_Select='Y' AND ISNULL(U_TrgDocN,'')=''");
                SAPbobsCOM.Recordset oRsRecord = objclsComman.returnRecord(sbQuery.ToString());
                if (oRsRecord.RecordCount == 0)
                {
                    oApplication.StatusBar.SetText("No Record found to be Receipt", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    return;
                }
                if (oRsRecord != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsRecord);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
                oPrdDataTable.ExecuteQuery(sbQuery.ToString());
                string AnnexureNo = string.Empty;
                string GRDocEntry = string.Empty;
                string PrdDocEntry = string.Empty;
                string LineID = string.Empty;

                bool boolSuccess = false;
                for (int i = 0; i < oPrdDataTable.Rows.Count; i++)
                {
                    SAPbobsCOM.Documents IssueToProd = null;
                    IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                    string DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_RecDate", 0).Trim();
                    DateTime dtDocDate = DateTime.ParseExact(DocDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                    IssueToProd.DocDate = dtDocDate;
                    IssueToProd.Series = Int32.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("U_RecSer", 0).Trim());
                    //LineID= Int32.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("U_RecSer", 0).Trim());


                    int iIssuerRow = 0;

                    try
                    {
                        PrdDocEntry = oPrdDataTable.Columns.Item("U_ProdDE").Cells.Item(i).Value.ToString();
                        // AnnexureNo = objclsComman.SelectRecord("SELECT TOP 1 U_ANXRE FROM WOR1 WHERE DOCENTRY='" + PrdDocEntry + "'");
                        oRecDataTable.ExecuteQuery(" SELECT ItemCode, PlannedQty,Warehouse,LineNum,U_ANXRE FROM WOR1 WHERE DOCENTRY='" + PrdDocEntry + "'  AND PlannedQty>0 ");

                        for (int Row = 0; Row < oRecDataTable.Rows.Count; Row++)
                        {
                            if (iIssuerRow > 0)
                            {
                                IssueToProd.Lines.Add();
                            }
                            IssueToProd.Lines.SetCurrentLine(iIssuerRow);
                            iIssuerRow = iIssuerRow + 1;

                            IssueToProd.Lines.BaseType = 202;
                            IssueToProd.Lines.BaseEntry = Int32.Parse(PrdDocEntry);
                            int BaseLine = int.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                            if (BaseLine != -1)
                            {
                                IssueToProd.Lines.BaseLine = Int32.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                            }
                            string Quantity = oRecDataTable.Columns.Item("PlannedQty").Cells.Item(Row).Value.ToString();
                            IssueToProd.Lines.Quantity = double.Parse(Quantity);
                            IssueToProd.Lines.WarehouseCode = oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString();
                            string branch = objclsComman.SelectRecord("SELECT \"BPLid\" FROM OWHS WHERE \"WhsCode\" = '" + oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString() + "'");
                            if (branch != string.Empty)
                            {
                                IssueToProd.BPL_IDAssignedToInvoice = int.Parse(branch);
                            }
                            try
                            {
                                IssueToProd.Lines.UserFields.Fields.Item("U_ANXTR").Value = oRecDataTable.Columns.Item("U_ANXRE").Cells.Item(Row).Value.ToString();
                            }
                            catch { }
                        }

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("For Loop Error: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }

                    long lretcode = IssueToProd.Add();

                    if (lretcode != 0)
                    {
                        int Errcode; string ErrMsg;
                        oCompany.GetLastError(out Errcode, out ErrMsg);
                        oApplication.SetStatusBarMessage("Receipt From Production : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                        oApplication.MessageBox("Receipt From Production  : " + ErrMsg, 1, "OK", "", "");
                        GRDocEntry = "";
                    }
                    else
                    {
                        boolSuccess = true;
                        GRDocEntry = oCompany.GetNewObjectKey();
                        string GRDocNum = objclsComman.SelectRecord(" SELECT DOCNUM FROM OIGN WHERE DOCENTRY='" + GRDocEntry + "'");
                        //string DocNum = oCompany.GetNewObjectCode;
                        objclsComman.SelectRecord("UPDATE [@PROD_IGN1] SET U_TrgDocE='" + GRDocEntry + "', U_TrgDocN='" + GRDocNum + "', U_TrgObj='59' WHERE DOCENTRY='" + Form_DocEntry + "' AND  U_ProdDE='" + PrdDocEntry + "' ");
                        oApplication.StatusBar.SetText("Reciept From Production " + GRDocNum.ToString() + " has been created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        //oApplication.MessageBox("Reciept From Production has been created successfully.", 1, "Ok", "", "");

                        // oApplication.ActivateMenuItem("1281");    
                        //oApplication.ActivateMenuItem("1289");
                        //oApplication.ActivateMenuItem("1288");
                    }
                }
                if (boolSuccess == true)
                {
                    oApplication.ActivateMenuItem("1281");
                }


            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                //oApplication.ActivateMenuItem("1281");
                if (oPrdDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oPrdDataTable);
                    oPrdDataTable = null;
                }
                if (oRecDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecDataTable);
                    oRecDataTable = null;
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        #endregion
    }
}
