using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using General.Classes;

namespace Production
{
    class clsMultipleIssue : Connection
    {
        #region Variables
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;

        const string headerTable = "@PROD_OIGE";
        const string rowTable = "@PROD_IGE1";

        const string CFL_WHS = "CFL_WHS";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {



                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("U_PrdType", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Select the Production Type.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("U_IssDate", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Enter the Issue Date", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    if (oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("U_IssSer", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Enter the Issue Series", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGE1");
                                    bool IsSelected = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (oDbDataSource.GetValue("U_Select", i).ToString() == "Y")
                                        {
                                            IsSelected = true;
                                            break;
                                        }
                                    }
                                    if (IsSelected == false)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("No row is selected from Matrix.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region pVal.ItemUID == "btnSel"
                            else if (pVal.ItemUID == "btnSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGE1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "Y");
                                }
                                oMatrix.LoadFromDataSource();
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnUn"
                            else if (pVal.ItemUID == "btnUn")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGE1");
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue("U_Select", i, "N");
                                }
                                oMatrix.LoadFromDataSource();
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnFill"
                            else if (pVal.ItemUID == "btnFill")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                FillData(oForm);
                            }
                            #endregion

                            #region pVal.ItemUID == "btnRefresh"
                            else if (pVal.ItemUID == "btnRefresh")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should not be in Add Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                Refresh(oForm);
                            }
                            #endregion

                            #region pVal.ItemUID == "btnCreate"
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string Type = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PrdType", 0).Trim();
                                oApplication.StatusBar.SetText("Please wait...", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);

                                if (Type == "D")
                                {
                                    GoodsIssue_Production_DisAssembly(pVal.FormUID);
                                }
                                else
                                {
                                    GoodsIssue_Production(pVal.FormUID);
                                }
                                oApplication.StatusBar.SetText("Operation Completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_WHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }

                        }

                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "PROD_OIGE" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("DocNum", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    //AutoCode(oForm);

                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            #region DocDate
                            if (pVal.ItemUID == "IssDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "60", "IssSer", "IssDate", "Load");
                                //oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                //if (oCombo.ValidValues.Count == 0)
                                //{
                                //    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                //}

                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                    //
                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "PROD_OIGE" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("DOCENTRY", 0);
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {

                        objclsComman.SelectRecord("DELETE FROM [@PROD_IGE1] WHERE (U_ProdDE IS NULL OR ISNULL(U_SELECT,'N')='N') AND DOCENTRY='" + Form_DocEntry + "'");


                        //  GoodsIssue_Production(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("IssSer").Specific;
                        oCombo.ValidValues.LoadSeries("60", SAPbouiCOM.BoSeriesMode.sf_View);

                        oItem = oForm.Items.Item("btnFill");
                        oItem.Visible = false;
                        oItem = oForm.Items.Item("btnSel");
                        oItem.Visible = false;
                        oItem = oForm.Items.Item("btnUn");
                        oItem.Visible = false;
                        string Exist = objclsComman.SelectRecord("SELECT 1 FROM [@PROD_IGE1] WHERE U_TrgDocE IS NULL AND U_Select='Y' AND DOCENTRY='" + Form_DocEntry + "'");
                        if (Exist == "1")
                        {
                            oItem = oForm.Items.Item("btnCreate");
                            oItem.Visible = true;
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        }
                        else
                        {
                            oItem = oForm.Items.Item("btnCreate");
                            oItem.Visible = false;
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            if (MenuID == "PROD_OIGE")
            {
                //objclsComman.LoadFromXML(MenuID, "DocEntry", "A");
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                //oForm = oApplication.Forms.Item(MenuID);
                oForm.EnableMenu("5895", true);

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("PrdType").Specific;
                objclsComman.FillCombo_UDFValue(oCombo, "@PROD_OIGE", "PrdType");


                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;



            }

            //oForm = oApplication.Forms.Item("PROD_OIGE");
            oForm = oApplication.Forms.ActiveForm;

            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                //objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "PROD_OIGE").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            oItem = oForm.Items.Item("PrdType");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("Furnace");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("Shift");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("SFrDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("SToDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            //oItem = oForm.Items.Item("mtx");
            //objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("IssSer");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("IssDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("btnFill");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnSel");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnUn");
            oItem.Visible = true;
            oItem = oForm.Items.Item("btnCreate");
            oItem.Visible = false;
            oForm.Select();




        }

        private void FillContactPerson(SAPbouiCOM.Form oForm, string CardCode)
        {
            SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("CntCode").Specific;
            objclsComman.FillCombo(oCombo, "SELECT CNTCTCODE,NAME FROM OCPR WHERE CardCode='" + CardCode + "' ORDER BY CNTCTCODE");

            string DefContactPerson = objclsComman.SelectRecord("SELECT T1.CNTCTCODE FROM OCRD T0 INNER JOIN OCPR T1 ON T0.CARDCODE=T1.CARDCODE WHERE T0.CardCode='" + CardCode + "'");
            oForm.DataSources.DBDataSources.Item("@PROD_OIGE").SetValue("U_CntCode", 0, DefContactPerson);

        }

        private void Refresh(SAPbouiCOM.Form oForm)
        {
            string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" UPDATE T0 SET T0.U_InStock=T2.OnHand FROM [@PROD_IGE1] T0");
            sbQuery.Append(" INNER JOIN OITW T2 ON T0.U_PITEM=T2.ITEMCODE AND T0.U_WhsCode=T2.WHSCODE ");
            sbQuery.Append(" WHERE T0.DocEntry='" + DocEntry + "' ");

            objclsComman.SelectRecord(sbQuery.ToString());

            oApplication.ActivateMenuItem("1289");
            oApplication.ActivateMenuItem("1288");

        }


        private void FillData(SAPbouiCOM.Form oForm)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                string Type = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PrdType", 0).Trim();
                string Furnace = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Furnace", 0).Trim();
                string Shift = oForm.DataSources.DBDataSources.Item(0).GetValue("U_Shift", 0).Trim();
                string SFrDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SFrDate", 0).Trim();
                string SToDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_SToDate", 0).Trim();
                string WhsCode = oForm.DataSources.DBDataSources.Item(0).GetValue("U_WhsCode", 0).Trim();
                if (string.IsNullOrEmpty(WhsCode))
                {
                    oApplication.StatusBar.SetText("Please select the warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    return;
                }
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T0.*,T1.*,T2.OnHand [InStock] FROM OWOR T0 INNER JOIN NNM1 T1 ON T0.SERIES=T1.SERIES ");
                sbQuery.Append(" INNER JOIN OITW T2 ON T0.ITEMCODE=T2.ITEMCODE AND T0.WAREHOUSE=T2.WHSCODE ");
                sbQuery.Append("  WHERE NOT EXISTS( SELECT 1 FROM [@PROD_IGE1] A WHERE T0.DOCENTRY=A.U_ProdDE) AND STATUS='R' ");
               
                oRs = objclsComman.returnRecord(sbQuery.ToString());


                int Row = 0;
                oMatrix.Clear();
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@PROD_IGE1");
                int TotalRows = oRs.RecordCount;
                while (!oRs.EoF)
                {
                    oDbDataSource.SetValue("U_ProdSer", Row, oRs.Fields.Item("SeriesName").Value.ToString());
                    oDbDataSource.SetValue("U_ProdNo", Row, oRs.Fields.Item("DocNum").Value.ToString());
                    oDbDataSource.SetValue("U_ProdDE", Row, oRs.Fields.Item("DocEntry").Value.ToString());
                    oDbDataSource.SetValue("U_ProdDate", Row, Convert.ToDateTime(oRs.Fields.Item("PostDate").Value.ToString()).ToString("yyyyMMdd"));
                    oDbDataSource.SetValue("U_StDate", Row, Convert.ToDateTime(oRs.Fields.Item("DueDate").Value.ToString()).ToString("yyyyMMdd"));
                    oDbDataSource.SetValue("U_PItem", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                    oDbDataSource.SetValue("U_Quantity", Row, oRs.Fields.Item("PlannedQty").Value.ToString());
                    oDbDataSource.SetValue("U_WhsCode", Row, oRs.Fields.Item("Warehouse").Value.ToString());
                    oDbDataSource.SetValue("U_InStock", Row, oRs.Fields.Item("InStock").Value.ToString());


                    if (TotalRows - 1 != Row)
                    {
                        oDbDataSource.InsertRecord(Row);
                    }
                    oRs.MoveNext();
                    Row++;
                }
                oMatrix.LoadFromDataSource();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        private void GoodsIssue_Production(string FormUID)
        {

            oForm = oApplication.Forms.Item(FormUID);
            string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("DOCENTRY", 0);
            SAPbouiCOM.DataTable oPrdDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("PrdDataTable");
            }
            catch { }
            oPrdDataTable = oForm.DataSources.DataTables.Item("PrdDataTable");

            SAPbouiCOM.DataTable oRecDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("RecDataTable");
            }
            catch { }
            oRecDataTable = oForm.DataSources.DataTables.Item("RecDataTable");

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.* FROM [@PROD_OIGE] T0 INNER JOIN  [@PROD_IGE1] T1 ON T0.DOCENTRY=T1.DOCENTRY ");
            sbQuery.Append(" WHERE T0.DOCENTRY='" + Form_DocEntry + "' AND T1.U_Select='Y' AND ISNULL(T1.U_TrgDocN,'')=''");
            SAPbobsCOM.Recordset oRsRecord = objclsComman.returnRecord(sbQuery.ToString());
            if (oRsRecord.RecordCount == 0)
            {
                oApplication.StatusBar.SetText("No Record found to be issue", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                return;
            }
            if (oRsRecord != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsRecord);
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();


            oPrdDataTable.ExecuteQuery(sbQuery.ToString());

            for (int i = 0; i < oPrdDataTable.Rows.Count; i++)
            {
                try
                {
                    SAPbobsCOM.Documents IssueToProd = null;
                    IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit));

                    string DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_IssDate", 0).Trim();
                    DateTime dtDocDate = DateTime.ParseExact(DocDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                    IssueToProd.DocDate = dtDocDate;
                    IssueToProd.Series = Int32.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("U_IssSer", 0).Trim());

                    string GRDocEntry = string.Empty;
                    string AnnexureNo = string.Empty;
                    string PrdDocEntry = oPrdDataTable.Columns.Item("U_ProdDE").Cells.Item(i).Value.ToString();
                    //string Type = oPrdDataTable.Columns.Item("U_Type").Cells.Item(i).Value.ToString();

                    oRecDataTable.ExecuteQuery("SELECT * FROM WOR1  WHERE DOCENTRY='" + PrdDocEntry + "' AND PlannedQty>0");

                    for (int Row = 0; Row < oRecDataTable.Rows.Count; Row++)
                    {

                        if (Row > 0)
                        {
                            IssueToProd.Lines.Add();
                        }
                        IssueToProd.Lines.SetCurrentLine(Row);
                        IssueToProd.Lines.BaseType = 202;
                        IssueToProd.Lines.BaseEntry = Int32.Parse(PrdDocEntry);
                        IssueToProd.Lines.BaseLine = Int32.Parse(oRecDataTable.Columns.Item("LineNum").Cells.Item(Row).Value.ToString());
                        string Quantity = oRecDataTable.Columns.Item("PlannedQty").Cells.Item(Row).Value.ToString();
                        IssueToProd.Lines.Quantity = double.Parse(Quantity);
                        IssueToProd.Lines.WarehouseCode = oRecDataTable.Columns.Item("wareHouse").Cells.Item(Row).Value.ToString();
                        string branch = objclsComman.SelectRecord("SELECT \"BPLid\" FROM OWHS WHERE \"WhsCode\" = '" + oRecDataTable.Columns.Item("wareHouse").Cells.Item(Row).Value.ToString() + "'");
                        if (branch != string.Empty)
                        {
                            IssueToProd.BPL_IDAssignedToInvoice = int.Parse(branch);
                        }

                        AnnexureNo = oRecDataTable.Columns.Item("U_ANXRE").Cells.Item(Row).Value.ToString();
                        try
                        {
                            IssueToProd.Lines.UserFields.Fields.Item("U_ANXTR").Value = AnnexureNo;
                        }
                        catch { }
                    }





                    long lretcode = IssueToProd.Add();

                    if (lretcode != 0)
                    {
                        int Errcode; string ErrMsg;
                        oCompany.GetLastError(out Errcode, out ErrMsg);
                        oApplication.SetStatusBarMessage("Issue For Production :" + PrdDocEntry + " Error : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                        oApplication.MessageBox("Issue For Production :" + PrdDocEntry + " Error : " + ErrMsg, 1, "OK", "", "");
                        GRDocEntry = "";
                    }
                    else
                    {
                        GRDocEntry = oCompany.GetNewObjectKey();
                        string GRDocNum = objclsComman.SelectRecord(" SELECT DOCNUM FROM OIGE WHERE DOCENTRY='" + GRDocEntry + "'");
                        //string DocNum = oCompany.GetNewObjectCode;
                        objclsComman.SelectRecord("UPDATE [@PROD_IGE1] SET U_TrgDocE='" + GRDocEntry + "', U_TrgDocN='" + GRDocNum + "', U_TrgObj='60' WHERE DOCENTRY='" + Form_DocEntry + "' AND U_ProdDE='" + PrdDocEntry + "'");
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText("Goods Issue Production : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
                //oRs_Production.MoveNext();
            }

        }

        private void GoodsIssue_Production_DisAssembly(string FormUID)
        {
            oForm = oApplication.Forms.Item(FormUID);
            string Form_DocEntry = oForm.DataSources.DBDataSources.Item("@PROD_OIGE").GetValue("DOCENTRY", 0);
            SAPbouiCOM.DataTable oPrdDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("PrdDataTable");
            }
            catch { }
            oPrdDataTable = oForm.DataSources.DataTables.Item("PrdDataTable");

            SAPbouiCOM.DataTable oRecDataTable;
            try
            {
                oForm.DataSources.DataTables.Add("RecDataTable");
            }
            catch { }
            oRecDataTable = oForm.DataSources.DataTables.Item("RecDataTable");

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T1.* FROM [@PROD_OIGE] T0 INNER JOIN  [@PROD_IGE1] T1 ON T0.DOCENTRY=T1.DOCENTRY ");
            sbQuery.Append(" WHERE T0.DOCENTRY='" + Form_DocEntry + "' AND T1.U_Select='Y' AND ISNULL(T1.U_TrgDocN,'')=''");


            SAPbobsCOM.Recordset oRsRecord = objclsComman.returnRecord(sbQuery.ToString());
            if (oRsRecord.RecordCount == 0)
            {
                oApplication.StatusBar.SetText("No Record found to be issue", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                return;
            }
            if (oRsRecord != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsRecord);
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();


            oPrdDataTable.ExecuteQuery(sbQuery.ToString());
            SAPbobsCOM.Documents IssueToProd = null;
            IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit));
            string DocDate = oForm.DataSources.DBDataSources.Item(0).GetValue("U_IssDate", 0).Trim();
            DateTime dtDocDate = DateTime.ParseExact(DocDate, "yyyyMMdd", CultureInfo.InvariantCulture);
            IssueToProd.DocDate = dtDocDate;
            IssueToProd.Series = Int32.Parse(oForm.DataSources.DBDataSources.Item(0).GetValue("U_IssSer", 0).Trim());
            string GRDocEntry = string.Empty;
            string AnnexureNo = string.Empty;
            string PrdDocEntry = string.Empty;
            int iIssuerRow = 0;
            for (int i = 0; i < oPrdDataTable.Rows.Count; i++)
            {
                try
                {

                    PrdDocEntry = oPrdDataTable.Columns.Item("U_ProdDE").Cells.Item(i).Value.ToString();
                    oRecDataTable.ExecuteQuery("SELECT * FROM OWOR T0  WHERE T0.DOCENTRY='" + PrdDocEntry + "' AND T0.PlannedQty>0");
                    for (int Row = 0; Row < oRecDataTable.Rows.Count; Row++)
                    {
                        if (iIssuerRow > 0)
                        {
                            IssueToProd.Lines.Add();
                        }
                        IssueToProd.Lines.SetCurrentLine(iIssuerRow);
                        IssueToProd.Lines.BaseType = 202;
                        IssueToProd.Lines.BaseEntry = Int32.Parse(PrdDocEntry);
                        string Quantity = oRecDataTable.Columns.Item("PlannedQty").Cells.Item(Row).Value.ToString();
                        IssueToProd.Lines.Quantity = double.Parse(Quantity);
                        IssueToProd.Lines.WarehouseCode = oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString();
                        string branch = objclsComman.SelectRecord("SELECT \"BPLid\" FROM OWHS WHERE \"WhsCode\" = '" + oRecDataTable.Columns.Item("Warehouse").Cells.Item(Row).Value.ToString() + "'");
                        if (branch != string.Empty)
                        {
                            IssueToProd.BPL_IDAssignedToInvoice = int.Parse(branch);
                        }
                         
                        AnnexureNo = objclsComman.SelectRecord("SELECT TOP 1 U_ANXRE FROM WOR1 WHERE DOCENTRY='" + PrdDocEntry + "'");
                        try
                        {
                            IssueToProd.Lines.UserFields.Fields.Item("U_ANXTR").Value = AnnexureNo;
                        }
                        catch { }
                        iIssuerRow = iIssuerRow + 1;
                    }


                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText("For Loop Error: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }

            }

            long lretcode = IssueToProd.Add();

            if (lretcode != 0)
            {
                int Errcode; string ErrMsg;
                oCompany.GetLastError(out Errcode, out ErrMsg);
                oApplication.SetStatusBarMessage("Issue For Production :" + PrdDocEntry + " Error : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                oApplication.MessageBox("Issue For Production :" + PrdDocEntry + " Error : " + ErrMsg, 1, "OK", "", "");
                GRDocEntry = "";
            }
            else
            {
                GRDocEntry = oCompany.GetNewObjectKey();
                string GRDocNum = objclsComman.SelectRecord(" SELECT DOCNUM FROM OIGE WHERE DOCENTRY='" + GRDocEntry + "'");
                //string DocNum = oCompany.GetNewObjectCode;
                objclsComman.SelectRecord("UPDATE [@PROD_IGE1] SET U_TrgDocE='" + GRDocEntry + "', U_TrgDocN='" + GRDocNum + "', U_TrgObj='60' WHERE DOCENTRY='" + Form_DocEntry + "'");
                oApplication.StatusBar.SetText("Issue For Production has been created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                oApplication.MessageBox("Issue For Production has been created successfully.", 1, "Ok", "", "");

                //oApplication.ActivateMenuItem("1289");
                //oApplication.ActivateMenuItem("1288");
                oApplication.ActivateMenuItem("1281");

            }

        }

        #endregion
    }
}
