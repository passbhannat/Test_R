using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;

namespace Production
{
    class clsProdution : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        StringBuilder sbQuery = new StringBuilder();

        const string headerTable = "OWOR";
        public const string soItemUID = "U_ODNo";
        public const string soEnItemUID = "U_ODEn";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                        }
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = true: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            if (pVal.FormTypeEx == "65211")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.StaticText oStaticText;
                                SAPbouiCOM.Button oButton;
                                SAPbouiCOM.Item oNewItem;
                                SAPbouiCOM.Item oItem;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                                #region Date
                                oNewItem = oForm.Items.Add("lblDate", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("77");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Date";

                                //oForm.DataSources.UserDataSources.Add("PourDate", SAPbouiCOM.BoDataType.dt_DATE, 10);
                                oNewItem = oForm.Items.Add("PourDate", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("78");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, "OWOR", "U_PDueDate");


                                #endregion

                                #region Furnace
                                oNewItem = oForm.Items.Add("lblFur", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lblDate");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Furnace";

                                // oForm.DataSources.UserDataSources.Add("Furnace", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 100);
                                oNewItem = oForm.Items.Add("Furnace", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("PourDate");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, "OWOR", "U_PFURCE_WISE");


                                #endregion

                                #region Shift
                                oNewItem = oForm.Items.Add("lblShift", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lblFur");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Shift";

                                // oForm.DataSources.UserDataSources.Add("Shift", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 100);
                                oNewItem = oForm.Items.Add("Shift", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                                oItem = oForm.Items.Item("Furnace");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                try
                                {
                                    oCombo = (SAPbouiCOM.ComboBox)oNewItem.Specific;
                                    oCombo.DataBind.SetBound(true, "OWOR", "U_PSHIFT");
                                }
                                catch { }

                                #endregion

                                #region Production Distribution
                                oNewItem = oForm.Items.Add("lblProdDi", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lblDate");
                                oNewItem.Top = oItem.Top;
                                oNewItem.Left = oForm.Items.Item("75").Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Prod. Dist.";

                                //oForm.DataSources.UserDataSources.Add("ProdDi", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 100);
                                oNewItem = oForm.Items.Add("ProdDi", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                                oItem = oForm.Items.Item("lblProdDi");
                                oNewItem.Top = oItem.Top;
                                oNewItem.Left = oForm.Items.Item("76").Left;
                                oNewItem.Width = oItem.Width;
                                oCombo = (SAPbouiCOM.ComboBox)oNewItem.Specific;
                                oCombo.DataBind.SetBound(true, "OWOR", "U_PPROD_DTRIBUTN");


                                #endregion

                                #region Mel Per
                                oNewItem = oForm.Items.Add("lblMelPer", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lblProdDi");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Mel. Per";

                                //oForm.DataSources.UserDataSources.Add("MelQty", SAPbouiCOM.BoDataType.dt_QUANTITY, 100);
                                oNewItem = oForm.Items.Add("MelPer", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("ProdDi");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, "OWOR", "U_PMELTPER");
                                // oNewItem.Enabled = false;

                                #endregion

                                #region Mel Qty
                                oNewItem = oForm.Items.Add("lblMelQty", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lblMelPer");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStaticText.Caption = "Mel. Qty";

                                //oForm.DataSources.UserDataSources.Add("MelQty", SAPbouiCOM.BoDataType.dt_QUANTITY, 100);
                                oNewItem = oForm.Items.Add("MelQty", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("MelPer");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, "OWOR", "U_MelQty");
                                oNewItem.Enabled = false;

                                #endregion



                                oNewItem = oForm.Items.Add("btnCalc", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                                oItem = oForm.Items.Item("lblMelQty");
                                oNewItem.Top = oItem.Top + 20;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oForm.Items.Item("2").Width;
                                oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                                oButton.Caption = "Calculate";
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btnCalc")
                            {
                                CalcMelted(FormUID);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }


        #endregion

        #region CalcMelted
        private void CalcMelted(string FormUID)
        {
            oForm = oApplication.Forms.Item(FormUID);

            string ItemCode = oForm.DataSources.DBDataSources.Item(0).GetValue("ItemCode", 0).Trim();
            string IsMelted = objclsComman.SelectRecord("SELECT 1 FROM OITM WHERE ITEMCODE='" + ItemCode + "' AND U_MELITM='Y'");
            if (IsMelted != "1")
            {
                oApplication.StatusBar.SetText("Item is not Melted..", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                return;
            }

            oApplication.StatusBar.SetText("Please wait...Calculating Melted Quantity.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

            string PourDate = ((SAPbouiCOM.EditText)oForm.Items.Item("PourDate").Specific).Value;
            string Furnace = ((SAPbouiCOM.EditText)oForm.Items.Item("Furnace").Specific).Value;
            string Shift = ((SAPbouiCOM.ComboBox)oForm.Items.Item("Shift").Specific).Value.Trim();
            string ProdDi = ((SAPbouiCOM.ComboBox)oForm.Items.Item("ProdDi").Specific).Value.Trim();
            double MelPer = double.Parse(((SAPbouiCOM.EditText)oForm.Items.Item("MelPer").Specific).Value.Trim());

            string query = "SELECT SUM(T1.PlannedQty) FROM OWOR T0  INNER JOIN WOR1 T1 ON T0.DOCENTRY=T1.DOCENTRY WHERE T1.ITEMCODE='" + ItemCode + "' AND U_FURCE_WISE='" + Furnace + "' AND U_SHIFT='" + Shift + "' AND DUEDATE='" + PourDate + "' AND U_PROD_DTRIBUTN='" + ProdDi + "'";

            string WORQty = objclsComman.SelectRecord(query);
            double dbl_WORQty = WORQty == string.Empty ? 0 : double.Parse(WORQty);
            dbl_WORQty = (dbl_WORQty * MelPer / 100) + dbl_WORQty;


            query = "SELECT SUM(T0.PlannedQty) FROM OWOR T0   WHERE T0.ITEMCODE='" + ItemCode + "' AND U_PFURCE_WISE='" + Furnace + "' AND U_PSHIFT='" + Shift + "' AND U_PDueDate='" + PourDate + "' AND U_PPROD_DTRIBUTN='" + ProdDi + "'";
            string Existing_MelterQty = objclsComman.SelectRecord(query);
            double dblExisting_MelterQty = Existing_MelterQty == string.Empty ? 0 : double.Parse(Existing_MelterQty);

            dbl_WORQty = dbl_WORQty - dblExisting_MelterQty;
            ((SAPbouiCOM.EditText)oForm.Items.Item("MelQty").Specific).String = dbl_WORQty.ToString();

            oApplication.StatusBar.SetText("Operation Completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

        }
        #endregion
    }
}
