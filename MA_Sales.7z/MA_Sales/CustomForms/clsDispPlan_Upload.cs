using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Threading;
using General.Extensions;

namespace Sales
{
    class clsDispPlan_Upload : Connection
    {
        #region Variables
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.ComboBox oCombo;

        SAPbobsCOM.Recordset oRs;
        const string headerTable = "@DISP_PLAN_UPLOAD";
        const string rowTable = "@DISP_PLAN_UPLOAD1";
        const string branchUDF = "U_BPLId";
        const string branchUID = "BPLId";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;

                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_43", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1");
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        double BaseOpenQty = double.Parse(oDbDataSource.GetValue("U_BaseOQty", i).ToString());
                                        double Quantity = double.Parse(oDbDataSource.GetValue("U_Quantity", i).ToString());
                                        if (Quantity > BaseOpenQty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Quantity is greater than base open qty for Row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region btnFill
                            else if (pVal.ItemUID == "btnFill")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Add Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                else
                                {
                                    FillMatrix(oForm, ReadExcelFile(oForm));
                                }

                            }
                            #endregion

                            #region btnRefresh
                            else if (pVal.ItemUID == "btnRefresh")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                RefreshData(oForm);
                            }
                            #endregion

                            #region btnCreate
                            else if (pVal.ItemUID == "btnCreate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                if (isBranchDatabase == "Y")
                                {
                                    string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(branchUDF, 0).ToString();
                                    if (branch == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Select the branch.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                                int iConfirm = oApplication.MessageBox("Do you want to create Dispatch Planning?", 1, "Yes", "No", "");
                                if (iConfirm == 1)
                                {
                                    string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                                    string Exists = objclsComman.SelectRecord("SELECT 1 FROM [@DISP_PLAN_UPLOAD1] WHERE DOCENTRY='" + DocEntry + "' AND ISNULL(U_TrEn,'')!=''");
                                    if (Exists == string.Empty)
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1");
                                        for (int i = 0; i < oDbDataSource.Size; i++)
                                        {
                                            double BaseOpenQty = double.Parse(oDbDataSource.GetValue("U_BaseOQty", i).ToString());
                                            double Quantity = double.Parse(oDbDataSource.GetValue("U_Quantity", i).ToString());
                                            if (Quantity > BaseOpenQty)
                                            {
                                                oApplication.StatusBar.SetText("Quantity is greater than base open qty for Row " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                        }
                                        objclsComman.DisPatchPlanning_Insert(DocEntry);
                                    }
                                    else
                                    {
                                        oApplication.StatusBar.SetText("Dispatch planning already created.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region Browse
                            else if (pVal.ItemUID == "btnBrowse")
                            {

                                Thread thread = new Thread(new ThreadStart(OpenFileLocation));
                                thread.SetApartmentState(System.Threading.ApartmentState.STA);
                                thread.Start();

                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = true: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "DISP_PLAN_UPLOAD" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD").GetValue("DocNum", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = false : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = false : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")//UDF FOrm
                    {
                        BubbleEvent = false;
                        return;
                    }

                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "DISP_PLAN_UPLOAD" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string DocEntry = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("DOCENTRY", 0);
                        string Cancel = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("Canceled", 0);

                        objclsComman.SelectRecord("DELETE FROM [@DISP_PLAN_UPLOAD1] WHERE U_ITEMCODE IS NULL AND DOCENTRY='" + DocEntry + "'");
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method


        private void LoadForm(string MenuID)
        {
            if (MenuID == "DISP_PLAN_UPLOAD")
            {
                //objclsComman.LoadFromXML(MenuID, "DocEntry", "A");
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                //oForm = oApplication.Forms.Item(MenuID);
                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false); // Cancel
                oForm.EnableMenu("1284", false); // Cancel
                oForm.EnableMenu("1286", false); // Close
                oForm.EnableMenu("1292", false); // Close
                oForm.EnableMenu("1293", false); // Close

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(branchUID).Specific;
                if (isBranchDatabase == "Y")
                {
                    objclsComman.FillCombo(oCombo, "SELECT T0.[BPLId], T0.[BPLName] FROM OBPL T0");
                    objclsComman.SetAutoManagedAttribute_UpdateMode(oCombo.Item);
                }
                else
                {
                    oCombo.Item.Disable();
                }

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("UpDate").Specific;
                oEdit.String = "t";

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {

                    oMatrix.AddRow(1, 1);
                }
                Int32 backcolor1 = 15724527;
                Int32 backcolor = 16777060;
                SAPbouiCOM.Column oColumn;
                oColumn = oMatrix.Columns.Item("V_47");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_46");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_45");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_27");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_28");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_4");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_26");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_25");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_43");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_42");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_39");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_38");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_37");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_34");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_33");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_32");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_31");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_24");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_19");
                oColumn.BackColor = backcolor;
                oColumn = oMatrix.Columns.Item("V_18");
                oColumn.BackColor = backcolor;

                //Total Value Field
                oColumn = oMatrix.Columns.Item("V_10");
                oColumn.BackColor = backcolor1;
                oColumn = oMatrix.Columns.Item("V_9");
                oColumn.BackColor = backcolor1;
                oColumn = oMatrix.Columns.Item("V_8");
                oColumn.BackColor = backcolor1;
                oColumn = oMatrix.Columns.Item("V_7");
                oColumn.BackColor = backcolor1;
                oColumn = oMatrix.Columns.Item("V_6");
                oColumn.BackColor = backcolor1;
            }
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            oItem = oForm.Items.Item("DocEntry");
            objclsComman.SetAutoManagedAttribute(oItem);
        }

        public void Calc_TotalFieldsData(SAPbouiCOM.Form oForm)
        {
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;

                string Combine = string.Empty;
                ArrayList ALDispatchNo = new ArrayList();
                string strALDispatchNo = string.Empty;
                string DispatchNo = string.Empty;

                oMatrix.FlushToDataSource();

                #region Get Distinct CardCode in ArrayList
                for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                {
                    if (!(ALDispatchNo.Contains(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1))))
                    {
                        ALDispatchNo.Add(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1));
                    }
                }
                #endregion

                for (int iDispatchRow = 0; iDispatchRow < ALDispatchNo.Count; iDispatchRow++)
                {
                    double NoCrat = 0;
                    double TotalNoCrat = 0;
                    double Netwt = 0;
                    double TotalNetwt = 0;
                    double GrsWt = 0;
                    double TotalGrsWt = 0;
                    double Amount = 0;
                    double TotalAmount = 0;

                    strALDispatchNo = ALDispatchNo[iDispatchRow].ToString().Trim();

                    #region Getting Total Values
                    for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                    {
                        try
                        {
                            #region Checking Matched Dispatch No
                            DispatchNo = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1).ToString().Trim();
                            if (strALDispatchNo != DispatchNo)
                            {
                                continue;
                            }
                            #endregion

                            NoCrat = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_NoCrat", i - 1).ToString());
                            Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Combine", i - 1).ToString().Trim();
                            if (Combine == string.Empty)
                            {
                                TotalNoCrat = TotalNoCrat + NoCrat;
                            }
                            else
                            {

                                if (oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_SkipRow", i - 1).ToString() == "N")
                                {
                                    TotalNoCrat = TotalNoCrat + NoCrat;
                                }
                            }

                            Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Netwt", i - 1).ToString());
                            TotalNetwt = TotalNetwt + (Netwt * NoCrat);

                            GrsWt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_GrsWt", i - 1).ToString());
                            TotalGrsWt = TotalGrsWt + (GrsWt * NoCrat);

                            Amount = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Amount", i - 1).ToString());
                            TotalAmount = TotalAmount + Amount;

                        }
                        catch (Exception ex)
                        {
                            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        }
                    }
                    #endregion

                    #region Setting Total Values
                    for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                    {
                        #region Checking Matched Dispatch No
                        DispatchNo = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1).ToString().Trim();
                        if (strALDispatchNo != DispatchNo)
                        {
                            continue;
                        }
                        #endregion
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_TotCrat", i - 1, TotalNoCrat.ToString());
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_TotNwt", i - 1, TotalNetwt.ToString());
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_TotGrWt", i - 1, TotalGrsWt.ToString());
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_Total", i - 1, TotalAmount.ToString());
                        // TotalAmount = TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_OthChg", i - 1).ToString());
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_GTotal", i - 1,
                            (TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_OthChg", i - 1).ToString())).ToString());
                    }
                    #endregion
                }
                oMatrix.LoadFromDataSource();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calc_TotalFieldsData: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void Calc_Gross(SAPbouiCOM.Form oForm)
        {
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                double Netwt = 0;
                double GrsWt = 0;
                double CrWeight = 0;
                string Combine = string.Empty;
                string InnerLoop_Combine = string.Empty;

                oMatrix.FlushToDataSource();
                ArrayList ALCombine = new ArrayList();
                ArrayList temp = new ArrayList();

                ArrayList ALDispatchNo = new ArrayList();
                string strALDispatchNo = string.Empty;
                string strDispatchNo = string.Empty;


                #region Set Skip Row to Blank
                for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                {
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_SkipRow", i - 1, "");//Pravin
                }
                #endregion

                #region Get Distinct Dispatch No in ArrayList
                for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                {
                    if (!(ALDispatchNo.Contains(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1))))
                    {
                        ALDispatchNo.Add(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1));
                    }
                }
                #endregion

                for (int iDispatchNoRow = 0; iDispatchNoRow < ALDispatchNo.Count; iDispatchNoRow++)
                {
                    strALDispatchNo = ALDispatchNo[iDispatchNoRow].ToString().Trim();

                    #region Checking Matching Combine Rows

                    for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                    {
                        #region Checking Matched Dispatch No
                        strDispatchNo = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1).ToString().Trim();
                        if (strALDispatchNo != strDispatchNo)
                        {
                            continue;
                        }
                        #endregion

                        Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Combine", i - 1).ToString().Trim();

                        if (Combine != string.Empty)
                        {
                            for (int j = i + 1; j <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; j++)
                            {
                                InnerLoop_Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Combine", j - 1).ToString().Trim();
                                if (Combine == InnerLoop_Combine)
                                {
                                    if (temp.Contains(Combine) == false)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_SkipRow", i - 1, "N");//Pravin
                                    }
                                    ALCombine.Add(i.ToString());
                                    temp.Add(Combine);
                                    break;
                                }
                            }
                        }
                    }

                    #endregion

                    #region No Combine Rows
                    if (ALCombine.Count == 0)
                    {
                        for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
                        {
                            #region Checking Matched Dispatch No
                            strDispatchNo = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_DispNo", i - 1).ToString().Trim();
                            if (strALDispatchNo != strDispatchNo)
                            {
                                continue;
                            }
                            #endregion
                            oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + i.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            CrWeight = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_PCCrate", i - 1).ToString());
                            Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Netwt", i - 1).ToString());
                            GrsWt = Netwt + CrWeight;
                            GrsWt = Math.Round(GrsWt, 2);
                            oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_GrsWt", i - 1, GrsWt.ToString());//Pravin

                        }
                        oMatrix.LoadFromDataSource();
                        oApplication.StatusBar.SetText("Gross Weight Calculation completed.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

                        return;
                    }
                    #endregion

                    #region Combine Rows
                    for (int Row = 1; Row <= ALCombine.Count; Row++)
                    {
                        try
                        {
                            oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + Row.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            int i = int.Parse(ALCombine[Row - 1].ToString());
                            Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Netwt", i - 1).ToString());
                            oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_GrsWt", i - 1, Netwt.ToString());
                        }
                        catch (Exception ex)
                        {
                            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        }

                    }
                    #endregion
                }

                oMatrix.LoadFromDataSource();
                oApplication.StatusBar.SetText("Gross Weight Calculation completed.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calc_Gross: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }
        public void Cal_Qty_Rate_Changed(SAPbouiCOM.Form oForm, string ColUID, int FromRow, int ToRow)
        {
            //V_10 Quantity
            //V_9 Rate


            string ItemCode = string.Empty;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();

            //double Totalwt = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double NoCrate = 0;
            double Package = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            string SWeight1 = string.Empty;
            string Quantity = string.Empty;
            double NoPack = 0;
            string CrWeight = string.Empty;
            double Rate = 0;
            double Total = 0;

            for (int i = FromRow; i <= ToRow; i++)
            {
                try
                {
                    // Totalwt = 0;
                    Netwt = 0;
                    TotalNetwt = 0;
                    NoCrate = 0;
                    Package = 0;
                    GrsWt = 0;
                    TotalGrsWt = 0;

                    ItemCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_ItemCode", i - 1).ToString();
                    Quantity = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Quantity", i - 1).ToString();

                    //SWeight1 = objclsComman.SelectRecord(" SELECT SWeight1 from OITM WHERE ITEMCODE='" + ItemCode + "'");
                    SWeight1 = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_StWt", i - 1).ToString();

                    SWeight1 = SWeight1 == string.Empty ? "0" : SWeight1;
                    Quantity = Quantity == string.Empty ? "0" : Quantity;

                    NoPack = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_NoPack", i - 1).ToString());
                    Rate = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Rate", i - 1).ToString());

                    if (NoPack != 0)
                    {
                        Package = double.Parse(Quantity) / NoPack;
                        Package = Math.Ceiling(Package);
                    }
                    NoPack = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_NoPack", i - 1).ToString());
                    CrWeight = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_PCCrate", i - 1).ToString();
                    CrWeight = CrWeight == string.Empty ? "0" : CrWeight;

                    if (ColUID == "V_10")
                    {
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_NoCrat", i - 1, Package.ToString());
                    }
                    else if (ColUID == "V_11")
                    {
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_NoCrat", i - 1, Package.ToString());
                    }

                    NoCrate = Package;

                    //Totalwt = (double.Parse(Quantity) * double.Parse(SWeight1));
                    Netwt = double.Parse(SWeight1) * NoPack;
                    GrsWt = Netwt + double.Parse(CrWeight);
                    GrsWt = Math.Round(GrsWt, 2);
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_Netwt", i - 1, Netwt.ToString());
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_GrsWt", i - 1, GrsWt.ToString());//Pravin
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_OpenQty", i - 1, Quantity);//Apply only Dispatch Planning
                    Total = double.Parse(Quantity) * Rate;
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_Amount", i - 1, Total.ToString());
                }
                catch { }
            }


            oMatrix.LoadFromDataSource();

            double TotalNoCrate = 0;
            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; i++)
            {
                try
                {
                    NoCrate = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_NoCrat", i - 1).ToString());
                    TotalNoCrate = TotalNoCrate + NoCrate; //Pravin

                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_Netwt", i - 1).ToString());
                    TotalNetwt = TotalNetwt + (Netwt * NoCrate); //Pravin

                    GrsWt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_GrsWt", i - 1).ToString());
                    TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                }
            }
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotCrat", 0, TotalNoCrate.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());

            Calc_TotalAmount(oForm);
        }
        private void Calc_TotalAmount(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double Quantity = 0;
            double Rate = 0;
            double Total = 0;
            double TotalAmount = 0;

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                Quantity = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).String);
                Rate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", i)).String);
                Total = Quantity * Rate;
                TotalAmount = TotalAmount + Total;
            }

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_Total", 0, TotalAmount.ToString());
            TotalAmount = TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_OthChg", 0).ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_GTotal", 0, TotalAmount.ToString());
        }
        public void Calc_NoOfCrate_Changed(SAPbouiCOM.Form oForm, int FromRow, int ToRow)
        {
            //V_6 No of Crate

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double TotalAmount = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            double NoCrate = 0;

            oMatrix.FlushToDataSource();
            for (int i = FromRow; i <= ToRow; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);
                double PCPerCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).String);
                oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_WtPack", i - 1, (NoCrate * PCPerCrate).ToString());
            }
            oMatrix.LoadFromDataSource();

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);
                TotalAmount = TotalAmount + NoCrate;

                Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", i)).String);
                TotalNetwt = TotalNetwt + (Netwt * NoCrate);

                GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).String);
                TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
            }
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotCrat", 0, TotalAmount.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());


        }
        public void Calc_PCPerCrate_Changed(SAPbouiCOM.Form oForm, int Row)
        {
            //V_5 PCS Per Crate
            double TotalGrsWt = 0;

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();
            double NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", Row)).String);
            double PCPerCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", Row)).String);
            double Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", Row)).String);

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_WtPack", Row - 1, (NoCrate * PCPerCrate).ToString());
            double GrsWt = Netwt + (PCPerCrate);
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("U_GrsWt", Row - 1, Math.Round(GrsWt, 2).ToString()); //Pravin

            oMatrix.LoadFromDataSource();

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);

                GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).String);
                TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
            }

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());
        }

        #region OpenFileLocation

        public void OpenFileLocation()
        {
            try
            {

                frmBrowse sd = new frmBrowse();
                sd.ShowDialog();
                sd.Close();

                SAPbouiCOM.Form oFrm = oApplication.Forms.ActiveForm;
                ((SAPbouiCOM.EditText)oFrm.Items.Item("UpPath").Specific).Value = clsVariables.BrowsePath;

            }
            catch { }
        }

        #endregion

        #region Read Excel File
        public System.Data.DataTable ReadExcelFile(SAPbouiCOM.Form oForm)
        {

            string excelSheets = "";
            System.Data.DataTable dtExcelRec = null;
            string FileLocation = ((SAPbouiCOM.EditText)oForm.Items.Item("UpPath").Specific).Value.ToString();

            System.Data.OleDb.OleDbConnection oconn = new System.Data.OleDb.OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileLocation.ToString() + ";Extended Properties=Excel 12.0");
            oconn.Open();

            System.Data.DataTable dt = oconn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);  //Get the table name

            if (dt == null)
            {

            }

            else
            {

                foreach (DataRow row in dt.Rows)
                {
                    excelSheets = row["TABLE_NAME"].ToString(); // Store the table name in Excelsheet variable which is declare at class level
                    break;
                }

                System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter("select * from [" + excelSheets + "]", oconn);
                dtExcelRec = new System.Data.DataTable();

                da.Fill(dtExcelRec);

                // Cleanup
                oconn.Close();
                da.Dispose();

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return dtExcelRec;
        }
        #endregion

        #region Fill Matrix

        private bool FillMatrix(SAPbouiCOM.Form oForm, System.Data.DataTable dt)
        {
            try
            {

                SAPbouiCOM.Matrix oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                oMatrix.Clear();
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1");
                int i = 0;
                string soDocNum = "";
                string soSeriesName = "";
                string soDocEntry = "";
                string soLineId = "";

                foreach (DataRow dr in dt.Rows)
                {
                    string DispNo = dr["Doc No"].ToString();
                    string IsExists = objclsComman.SelectRecord(" SELECT 1 FROM [@DISP_PLAN] WHERE U_UPDispNo='" + DispNo + "'");
                    if (IsExists == "1")
                    {
                        oApplication.MessageBox("Data has been already uploaded of Dispatch No " + DispNo, 1, "Ok", "", "");
                        return false;
                    }
                    if (i < dt.Rows.Count)
                    {
                        oDbDataSource.InsertRecord(i);
                    }
                    oDbDataSource.SetValue("LineId", i, Convert.ToString(i + 1));
                    soDocNum = dr["SO No"].ToString();
                    soSeriesName = dr["SO Series"].ToString();
                    soLineId = dr["SO Line ID"].ToString();

                    soDocEntry = objclsComman.SelectRecord("SELECT DocEntry FROM ORDR T0 INNER JOIN NNM1 T1 ON T0.Series = T1.Series WHERE T0.DocNum = '" + soDocNum + "' AND T1.SeriesName = '" + soSeriesName + "'");
                    //IsExists = objclsComman.SelectRecord("SELECT 1 FROM [@DISP_PLAN] T0 INNER JOIN [@DISP_PLAN1] T1 ON T0.DocEntry = T1.DocEntry WHERE T1.U_BaseKey = '" + soDocEntry + "' AND T1.U_BaseLine ='"+ soLineId + "' ");

                    oDbDataSource.SetValue("U_BaseRef", i, soDocNum);
                    oDbDataSource.SetValue("U_SOSeries", i, soSeriesName);
                    oDbDataSource.SetValue("U_BaseKey", i, soDocEntry);

                    oDbDataSource.SetValue("U_SOLineId", i, dr["SO Line ID"].ToString());
                    oDbDataSource.SetValue("U_CardCode", i, dr["CardCode"].ToString());
                    oDbDataSource.SetValue("U_CardName", i, dr["CardName"].ToString());
                    oDbDataSource.SetValue("U_DispNo", i, dr["Doc No"].ToString());
                    oDbDataSource.SetValue("U_DispSer", i, dr["Series"].ToString());
                    try
                    {
                        oDbDataSource.SetValue("U_DispDate", i, dr["Doc Date"].ToString());
                    }
                    catch (Exception ex)
                    {
                        oApplication.SetStatusBarMessage("Fill Matrix Dispatch Date Set Error : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                    }
                    oDbDataSource.SetValue("U_ItemCode", i, dr["ItemCode"].ToString());
                    oDbDataSource.SetValue("U_ItemName", i, dr["Item Description"].ToString());

                    oDbDataSource.SetValue("U_Quantity", i, dr["Qty"].ToString());
                    oDbDataSource.SetValue("U_Rate", i, dr["Rate"].ToString());
                    oDbDataSource.SetValue("U_NoPack", i, dr["No Of PCS/SET Per Crate"].ToString());
                    oDbDataSource.SetValue("U_NoCrat", i, dr["No of Crate"].ToString());
                    oDbDataSource.SetValue("U_PCCrate", i, dr["Weight Per Crate"].ToString());
                    oDbDataSource.SetValue("U_WtPack", i, dr["Wt# of packing"].ToString());
                    oDbDataSource.SetValue("U_Combine", i, dr["Combine"].ToString());
                    oDbDataSource.SetValue("U_SkipRow", i, dr["Skip Row"].ToString());
                    oDbDataSource.SetValue("U_OthChg", i, dr["Other Charges"].ToString());
                    oDbDataSource.SetValue("U_Remarks", i, dr["Remarks"].ToString());

                    i = i + 1;
                }
                oMatrix.LoadFromDataSource();

                oMatrix.FlushToDataSource();

                for (int j = 0; j < oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").Size; j++)
                {
                    string ItmCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").GetValue("U_ItemCode", j).ToString().Trim();
                    if (ItmCode == "")
                    {
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").RemoveRecord(j);
                    }
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1").SetValue("LineId", j, (j + 1).ToString());
                }
                oMatrix.LoadFromDataSource();
                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                }
                return true;
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Fill Matrix: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                return false;
            }
        }

        #endregion

        #region Refresh Data
        private void RefreshData(SAPbouiCOM.Form oForm)
        {
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN_UPLOAD1");
                StringBuilder sbQuery = new StringBuilder();

                double dbl_Rate = 0;
                double dbl_Quantity = 0;
                double dbl_Amount = 0;
                string CrWeight = string.Empty;
                string SWeight1 = "";
                double NoPack = 0;
                double Netwt = 0;
                double GrsWt = 0;

                for (int i = 0; i < oDbDataSource.Size; i++)
                {
                   
                    oApplication.StatusBar.SetText("Row No: "+ (i+1),SAPbouiCOM.BoMessageTime.bmt_Short,SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    dbl_Rate = double.Parse(oDbDataSource.GetValue("U_Rate", i).ToString());
                    dbl_Quantity = double.Parse(oDbDataSource.GetValue("U_Quantity", i).ToString());
                    dbl_Amount = dbl_Rate * dbl_Quantity;
                    oDbDataSource.SetValue("U_Amount", i, dbl_Amount.ToString());
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.DocEntry,T1.LineNum,T1.WhsCode,T2.USERTEXT [Marking],T1.U_STWT,T3.ONHAND ");
                    sbQuery.Append(" ,T1.QUANTITY-  ");
                    sbQuery.Append(" ISNULL((SELECT SUM(U_Quantity) FROM[@DISP_PLAN1] A INNER JOIN[@DISP_PLAN] B ON A.DocEntry = B.DocEntry ");
                    sbQuery.Append(" WHERE A.U_BaseKey = T1.DocEntry AND A.U_BaseLine = T1.LineNum AND B.U_Approved = 'Y' AND B.Canceled = 'N'),0) OpenQty ");
                    sbQuery.Append(" FROM ORDR T0 ");
                    sbQuery.Append(" INNER JOIN RDR1 T1 ON T0.DOCENTRY=T1.DOCENTRY ");
                    sbQuery.Append(" INNER JOIN OITM T2 ON T1.ITEMCODE = T2.ITEMCODE ");
                    sbQuery.Append(" INNER JOIN OITW T3 ON T1.ITEMCODE = T3.ITEMCODE AND T1.WHSCODE=T3.WHSCODE");
                    sbQuery.Append(" INNER JOIN NNM1 T4 ON T0.Series = T4.Series ");

                    sbQuery.Append("  WHERE T0.DocNum ='" + oDbDataSource.GetValue("U_BaseRef", i).ToString().Trim() + "' ");
                    sbQuery.Append(" AND T1.LineNum ='" + oDbDataSource.GetValue("U_SOLineId", i).ToString().Trim() + "'");
                    sbQuery.Append(" AND T4.SeriesName = '" + oDbDataSource.GetValue("U_SOSeries", i).ToString().Trim() + "' ");
                    sbQuery.Append(" AND T1.ItemCode ='" + oDbDataSource.GetValue("U_ItemCode", i).ToString().Trim() + "'");
                    //if (i == 11)
                    //{

                    //}
                    oRs = objclsComman.returnRecord(sbQuery.ToString());
                    if (oRs.RecordCount == 0)
                    {
                        oApplication.StatusBar.SetText(sbQuery.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        continue;
                    }
                    if (oRs.RecordCount > 0)
                    {
                        oDbDataSource.SetValue("U_BaseKey", i, oRs.Fields.Item("DocEntry").Value.ToString());
                        string LineNum = oRs.Fields.Item("LineNum").Value.ToString();
                        oDbDataSource.SetValue("U_BaseLine", i, oRs.Fields.Item("LineNum").Value.ToString());
                        oDbDataSource.SetValue("U_BaseOQty", i, oRs.Fields.Item("OpenQty").Value.ToString());

                        oDbDataSource.SetValue("U_WhsCode", i, oRs.Fields.Item("WhsCode").Value.ToString());
                        oDbDataSource.SetValue("U_Marking", i, oRs.Fields.Item("Marking").Value.ToString());
                        oDbDataSource.SetValue("U_ONHAND", i, oRs.Fields.Item("ONHAND").Value.ToString());
                        oDbDataSource.SetValue("U_STWT", i, oRs.Fields.Item("U_STWT").Value.ToString());
                        CrWeight = oDbDataSource.GetValue("U_PCCrate", i).ToString();
                        NoPack = double.Parse(oDbDataSource.GetValue("U_NoPack", i).ToString());

                        SWeight1 = oRs.Fields.Item("U_STWT").Value.ToString();
                        SWeight1 = SWeight1 == string.Empty ? "0" : SWeight1;

                        Netwt = double.Parse(SWeight1) * NoPack;
                        GrsWt = Netwt + double.Parse(CrWeight);
                        GrsWt = Math.Round(GrsWt, 2);
                        oDbDataSource.SetValue("U_Netwt", i, Netwt.ToString());
                        oDbDataSource.SetValue("U_GrsWt", i, GrsWt.ToString());
                    }
                }
                oMatrix.LoadFromDataSource();

                Calc_Gross(oForm);
                Calc_TotalFieldsData(oForm);
                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("RefreshData: " + ex.Message,SAPbouiCOM.BoMessageTime.bmt_Short,SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
        #endregion

        #endregion
    }
}

