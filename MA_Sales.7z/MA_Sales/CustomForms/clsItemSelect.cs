using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace Sales
{
    class clsItemSelect : Connection
    {
        #region Variables

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbobsCOM.Recordset oRs;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                    oForm = clsVariables.BaseForm;

                                    bool IsSeletedRow = false;
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            IsSeletedRow = true;
                                            break;
                                        }
                                    }
                                    if (IsSeletedRow == false)
                                    {
                                        return;
                                    }
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1");

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    //oMatrix.Clear();
                                    oMatrix.FlushToDataSource();

                                    int row = 0;
                                    row = oMatrix.VisualRowCount-1;
                                    if (oDbDataSource.GetValue("U_ItemCode",row) != string.Empty)
                                    {
                                        row = oMatrix.VisualRowCount;
                                    }

                                    string SelectedSO = string.Empty;

                                    oApplication.StatusBar.SetText("Setting Data To Matrix....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

                                    #region Setting Data to Matrix
                                    for (int i = 0; i < oDataTable.Rows.Count; i++)
                                    {
                                        string Selected = oDataTable.Columns.Item("Selected").Cells.Item(i).Value.ToString();
                                        if (Selected == "Y")
                                        {
                                            string SODocEntry = oDataTable.GetValue("DocEntry", i).ToString();
                                            string LineNum = oDataTable.GetValue("LineNum", i).ToString();
                                            string OpenQty = oDataTable.GetValue("OpenQty", i).ToString();


                                            SelectedSO = SelectedSO + "  '" + oDataTable.GetValue("DocEntry", i).ToString() + "' ,";



                                            oRs = objclsComman.returnRecord(" SELECT T0.*,T1.DOCNUM,T1.NumAtCard,T2.USERTEXT,T1.U_PRTOFLDG,T1.U_PRTOFDSTN ,T3.ONHAND " +
                                                " FROM RDR1 T0  " +
                                                " INNER JOIN ORDR T1 ON T0.DOCENTRY= T1.DOCENTRY " +
                                                " INNER JOIN OITM T2 ON T0.ITEMCODE = T2.ITEMCODE " +
                                                " INNER JOIN OITW T3 ON T0.ITEMCODE = T3.ITEMCODE AND T0.WHSCODE=T3.WHSCODE" +

                                                " WHERE T0.DOCENTRY='" + SODocEntry + "' AND T0.LINENUM='" + LineNum + "'");
                                           
                                            while (!oRs.EoF)
                                            {
                                                oDbDataSource.InsertRecord(row);
                                                oDbDataSource.SetValue("LineId", row, (row + 1).ToString());
                                                oDbDataSource.SetValue("U_ItemCode", row, oRs.Fields.Item("ItemCode").Value.ToString());
                                                oDbDataSource.SetValue("U_ItemName", row, oRs.Fields.Item("Dscription").Value.ToString());
                                                oDbDataSource.SetValue("U_MARKING", row, oRs.Fields.Item("USERTEXT").Value.ToString());
                                                oDbDataSource.SetValue("U_NumAtCar", row, oRs.Fields.Item("NumAtCard").Value.ToString());
                                                oDbDataSource.SetValue("U_StWt", row, oRs.Fields.Item("U_STWT").Value.ToString());

                                                oDbDataSource.SetValue("U_OnHand", row, oRs.Fields.Item("ONHAND").Value.ToString());


                                                oDbDataSource.SetValue("U_Quantity", row, OpenQty);
                                                oDbDataSource.SetValue("U_BCOQty", row, OpenQty);
                                                oDbDataSource.SetValue("U_OpenQty", row, OpenQty);
                                                oDbDataSource.SetValue("U_WhsCode", row, oRs.Fields.Item("WhsCode").Value.ToString());

                                                oDbDataSource.SetValue("U_Rate", row, oRs.Fields.Item("PRICE").Value.ToString());

                                                oDbDataSource.SetValue("U_Amount", row, Convert.ToString(double.Parse(OpenQty) * double.Parse(oRs.Fields.Item("PRICE").Value.ToString())));

                                                oDbDataSource.SetValue("U_Netwt", row, oRs.Fields.Item("U_NETWT").Value.ToString());

                                                oDbDataSource.SetValue("U_GrsWt", row, Math.Round(double.Parse(oRs.Fields.Item("U_GRSWT").Value.ToString()), 2).ToString());//Pravin
                                                oDbDataSource.SetValue("U_NoCrat", row, oRs.Fields.Item("PACKQTY").Value.ToString());
                                                oDbDataSource.SetValue("U_NoPack", row, oRs.Fields.Item("U_NOPACKING").Value.ToString());

                                                oDbDataSource.SetValue("U_PCCrate", row, oRs.Fields.Item("U_CRTWT").Value.ToString());
                                                oDbDataSource.SetValue("U_WtPack", row, oRs.Fields.Item("U_TOTCRTWT").Value.ToString());

                                                oDbDataSource.SetValue("U_BaseRef", row, oRs.Fields.Item("DOCNUM").Value.ToString());
                                                oDbDataSource.SetValue("U_BaseKey", row, oRs.Fields.Item("DOCENTRY").Value.ToString());
                                                oDbDataSource.SetValue("U_BaseLine", row, oRs.Fields.Item("LINENUM").Value.ToString());
                                                oDbDataSource.SetValue("U_BaseType", row, oRs.Fields.Item("OBJTYPE").Value.ToString());


                                                row++;
                                                oRs.MoveNext();
                                            }
                                        }
                                    }
                                    oMatrix.LoadFromDataSource();

                                    #endregion

                                   
                                    if (SelectedSO.Length > 0)
                                    {
                                        SelectedSO = SelectedSO.Remove(SelectedSO.Length - 1, 1);

                                        string TotalExpns = objclsComman.SelectRecord(" SELECT CASE WHEN DocRate=1 THEN SUM(TOTALEXPNS) ELSE SUM(TotalExpFC) END FROM ORDR WHERE DOCENTRY IN (" + SelectedSO + ") GROUP BY DocRate ");
                                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_OthChg", 0, TotalExpns);
                                    }
                                    clsDispPlan obj = new clsDispPlan();
                                    obj.Calc_DetailFields(oForm);
                                    obj.Cal_Qty_Rate_Changed(oForm, "V_10", 1, oMatrix.VisualRowCount);
                                    obj.Calc_NoOfCrate_Changed(oForm, 1, oMatrix.VisualRowCount);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                    }
                                    oApplication.StatusBar.SetText("Done.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);


                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnSel"
                            else if (pVal.ItemUID == "btnSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "Y";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region pVal.ItemUID == "btnDSel"
                            else if (pVal.ItemUID == "btnDSel")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    oDataTable.Columns.Item("Selected").Cells.Item(i).Value = "N";
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=true: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Selection Item Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

    }
}
