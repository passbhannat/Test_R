using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General.Extensions;
using System.Linq;

namespace Sales
{
    class clsDispPlan : Connection
    {
        #region Variables

        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbobsCOM.Recordset oRs;

        const string headerTable = "@DISP_PLAN";
        const string rowTable = "@DISP_PLAN1";
        const string branchUDF = "U_BPLId";
        const string branchUID = "BPLId";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {

                            #region btnCopySO
                            if (pVal.ItemUID == "btnCopySO")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = string.Empty;
                                CardCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_CardCode", 0).ToString().Trim();
                                string Port = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_PORT", 0).ToString().Trim();
                                string branch = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue(branchUDF, 0).ToString().Trim();

                                StringBuilder sbQuery = new StringBuilder();
                                sbQuery.Append(" EXEC DISP_GET_SO '" + CardCode + "','" + Port + "','" + branch + "'");
                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_SO", "17", sbQuery.ToString(), "DocEntry", null);
                            }
                            #endregion

                            #region Port
                            else if (pVal.ItemUID == "Port")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardName = string.Empty;
                                CardName = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_CardCode", 0).ToString();

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_CUSTNAME"); //Condition Alias             
                                temp.Add(CardName); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_PORT", "PORT", "", "", alCondVal);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_CardCode", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    if (oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    //List<string> list = new List<string>();
                                    //for (int i = 0; i < oDbDataSource.Size; i++)
                                    //{
                                    //    list.Add(oDbDataSource.GetValue("U_BaseLine", i).Trim());
                                    //}
                                    //var query = list.GroupBy(x => x)
                                    //          .Where(g => g.Count() > 1)
                                    //          .Select(y => y.Key)
                                    //          .ToList();
                                    //if (query.Count > 0)
                                    //{
                                    //    BubbleEvent = false;
                                    //    oApplication.StatusBar.SetText("There are duplicate sales order items in document. Please remove it", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //    return;
                                    //}
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        int i = oApplication.MessageBox("Do you really want to add document? Please check the calculation before adding document.", 2, "Yes", "No", "");
                                        if (i == 2)
                                        {
                                            BubbleEvent = false;
                                        }
                                    }
                                    //Calc_Gross(oForm);
                                    //Calc_DetailFields(oForm);
                                }

                            }
                            if ((pVal.ItemUID == "1" && pVal.FormMode == 1) || pVal.ItemUID == "2")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = "Y";//Close
                            }

                            #endregion

                            #region btnCopySO
                            else if (pVal.ItemUID == "btnCopySO")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                                string CardCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_CardCode", 0).ToString();
                                if (CardCode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please Select the customer.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (isBranchDatabase == "Y")
                                {
                                    string branch = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue(branchUDF, 0).ToString();
                                    if (branch == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please Select the branch.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            #endregion

                            #region btnCalcGr
                            else if (pVal.ItemUID == "btnCalcGr")
                            {
                                oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                Cal_Qty_Rate_Changed(oForm, "V_10", 1, oMatrix.VisualRowCount);
                                Calc_Gross(oForm);
                                Calc_DetailFields(oForm);
                            }
                            #endregion


                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = true : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_CARD")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN");
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0).ToString());
                                StringBuilder sbQuery = new StringBuilder();
                                sbQuery.Append("SELECT U_PORTNAME FROM [@PORT] WHERE U_CUSTNAME = '" + oDataTable.GetValue("CardCode", 0).ToString() + "'");
                                oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount == 1)
                                {
                                    oDbDataSource.SetValue("U_PORT", 0, oRs.Fields.Item("U_PORTNAME").Value.ToString());
                                }
                                else
                                {
                                    oDbDataSource.SetValue("U_PORT", 0, string.Empty);
                                }
                                objclsComman.ReleaseObject(oRs);
                                FillContactPerson(oForm, oDataTable.GetValue("CardCode", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_PORT")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN");
                                oDbDataSource.SetValue("U_PORT", 0, oDataTable.GetValue("U_PORTNAME", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITM")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue("ItemName", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_SO")
                            {
                                clsVariables.BaseForm = oForm;
                                //objclsComman.LoadFromXML("DISP_PLAN_ITEMSEL", "", "");
                                objclsComman.LoadXML("DISP_PLAN_ITEMSEL", "", string.Empty, "O");
                                string SODocEntry = string.Empty;
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    SODocEntry = SODocEntry + "  " + oDataTable.GetValue("DocEntry", i).ToString() + " ,";

                                }
                                if (SODocEntry.Length > 0)
                                {
                                    SODocEntry = SODocEntry.Remove(SODocEntry.Length - 1, 1);
                                }
                                string Query = " EXEC DISP_GET_SO_ITEMS '" + SODocEntry + "'";
                                oForm = oApplication.Forms.ActiveForm;

                                oForm.DataSources.DataTables.Add("SODataTable");

                                oForm.DataSources.DataTables.Item(0).ExecuteQuery(Query);
                                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item("grd1").Specific;
                                oGrid.DataTable = oForm.DataSources.DataTables.Item("SODataTable");
                                oGrid.AutoResizeColumns();

                                for (int i = 0; i < oGrid.DataTable.Columns.Count; i++)
                                {
                                    if (i == 0)
                                    {
                                        oGrid.Columns.Item("Selected").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
                                    }
                                    else
                                    {
                                        oGrid.Columns.Item(i).Editable = false;
                                        oGrid.Columns.Item(i).TitleObject.Sortable = true;
                                    }
                                }



                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_SO1")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1");

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.Clear();
                                oMatrix.FlushToDataSource();

                                int Row = 0;
                                string SODocEntry = string.Empty;
                                double Quantity = 0;
                                double StdWeight = 0;
                                double TotalPCs = 0;
                                double PCCrate = 0;

                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    SODocEntry = oDataTable.GetValue("DocEntry", i).ToString();
                                    oRs = objclsComman.returnRecord(" SELECT T0.*,T1.DOCNUM,T2.USERTEXT FROM RDR1 T0 " +
                                        " INNER JOIN ORDR T1 ON T0.DOCENTRY= T1.DOCENTRY " +
                                        " INNER JOIN OITM T2 ON T0.ITEMCODE = T2.ITEMCODE " +

                                        " WHERE T0.DOCENTRY='" + SODocEntry + "'");
                                    while (!oRs.EoF)
                                    {
                                        oDbDataSource.InsertRecord(Row + 1);
                                        oDbDataSource.SetValue("LineId", Row, (Row + 1).ToString());
                                        oDbDataSource.SetValue("U_ItemCode", Row, oRs.Fields.Item("ItemCode").Value.ToString());
                                        oDbDataSource.SetValue("U_ItemName", Row, oRs.Fields.Item("Dscription").Value.ToString());
                                        oDbDataSource.SetValue("U_MARKING", Row, oRs.Fields.Item("USERTEXT").Value.ToString());
                                        Quantity = oRs.Fields.Item("OPENQTY").Value.ToString() == string.Empty ? 0 : double.Parse(oRs.Fields.Item("OPENQTY").Value.ToString());
                                        //Pravin
                                        StdWeight = oRs.Fields.Item("OPENQTY").Value.ToString() == string.Empty ? 0 : double.Parse(oRs.Fields.Item("OPENQTY").Value.ToString());

                                        oDbDataSource.SetValue("U_Quantity", Row, oRs.Fields.Item("OPENQTY").Value.ToString());
                                        oDbDataSource.SetValue("U_OpenQty", Row, oRs.Fields.Item("OPENQTY").Value.ToString());

                                        oDbDataSource.SetValue("U_Rate", Row, oRs.Fields.Item("PRICE").Value.ToString());

                                        oDbDataSource.SetValue("U_Amount", Row, Convert.ToString(Quantity * double.Parse(oRs.Fields.Item("PRICE").Value.ToString())));

                                        oDbDataSource.SetValue("U_Netwt", Row, oRs.Fields.Item("U_NETWT").Value.ToString());
                                        double GrsWt = Math.Round(double.Parse(oRs.Fields.Item("U_GRSWT").Value.ToString()), 2);
                                        oDbDataSource.SetValue("U_GrsWt", Row, GrsWt.ToString());//Pravin

                                        //Pravin
                                        TotalPCs = oRs.Fields.Item("OPENQTY").Value.ToString() == string.Empty ? 0 : double.Parse(oRs.Fields.Item("OPENQTY").Value.ToString());
                                        PCCrate = oRs.Fields.Item("OPENQTY").Value.ToString() == string.Empty ? 0 : double.Parse(oRs.Fields.Item("OPENQTY").Value.ToString());
                                        //if (PCCrate > 0)
                                        //{
                                        //    oDbDataSource.SetValue("U_NoCrat", Row, (TotalPCs / PCCrate).ToString());
                                        //}
                                        oDbDataSource.SetValue("U_NoCrat", Row, oRs.Fields.Item("PACKQTY").Value.ToString());
                                        oDbDataSource.SetValue("U_NoPack", Row, oRs.Fields.Item("U_NOPACKING").Value.ToString());

                                        oDbDataSource.SetValue("U_PCCrate", Row, oRs.Fields.Item("U_CRTWT").Value.ToString());
                                        oDbDataSource.SetValue("U_WtPack", Row, oRs.Fields.Item("U_TOTCRTWT").Value.ToString());

                                        oDbDataSource.SetValue("U_BaseRef", Row, oRs.Fields.Item("DOCNUM").Value.ToString());
                                        oDbDataSource.SetValue("U_BaseKey", Row, oRs.Fields.Item("DOCENTRY").Value.ToString());
                                        oDbDataSource.SetValue("U_BaseLine", Row, oRs.Fields.Item("LINENUM").Value.ToString());
                                        oDbDataSource.SetValue("U_BaseType", Row, oRs.Fields.Item("OBJTYPE").Value.ToString());


                                        Row++;
                                        oRs.MoveNext();
                                    }

                                }



                                //if (pVal.Row == oMatrix.RowCount)
                                //{
                                //    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                //    int RowNo = 1;
                                //    for (int i = 0; i < oDbDataSource.Size; i++)
                                //    {
                                //        oDbDataSource.SetValue("LineId", i, RowNo.ToString());
                                //        RowNo = RowNo + 1;
                                //    }
                                //}
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_4").Cells.Item(oMatrix.VisualRowCount - 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);

                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                Calc_DetailFields(oForm);
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_VEN")
                            {

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                oMatrix.FlushToDataSource();
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_CardCode", pVal.Row - 1, oDataTable.GetValue("Code", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_CardName", pVal.Row - 1, oDataTable.GetValue("Name", 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
                                    {
                                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("LineId", i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item("V_0").Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == "DISP_PLAN")
                            {

                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.Action_Success == true)
                            {
                                if (pVal.FormTypeEx == "DISP_PLAN" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    string Code = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("DocNum", 0).ToString();
                                    if (Code.Trim() == string.Empty)
                                    {
                                        LoadForm("1282");
                                        return;
                                    }
                                }

                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(0);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), "DISP_PLAN").ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                            //AutoCode(oForm);
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            #region DocDate
                            if (pVal.ItemUID == "DocDate")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, string.Empty);

                                }

                            }
                            #endregion

                            #region OthChg
                            if (pVal.ItemUID == "OthChg")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                double TotalAmount = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_Total", 0).ToString());
                                TotalAmount = TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_OthChg", 0).ToString());
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_GTotal", 0, TotalAmount.ToString());

                            }
                            #endregion

                            #region pVal.ColUID == "V_10" Quantity || pVal.ColUID == "V_9" Rate || pVal.ColUID == "V_11" No Pack

                            if (pVal.ColUID == "V_10" || pVal.ColUID == "V_9" || pVal.ColUID == "V_11")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                Cal_Qty_Rate_Changed(oForm, pVal.ColUID, pVal.Row, pVal.Row);

                            }
                            #endregion

                            #region pVal.ColUID == V_6  No of Crate
                            else if (pVal.ColUID == "V_6") //Pravin
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                Calc_NoOfCrate_Changed(oForm, pVal.Row, pVal.Row);
                            }
                            #endregion

                            #region pVal.ColUID == "V_5" PCS Per Crate
                            else if (pVal.ColUID == "V_5")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                Calc_PCPerCrate_Changed(oForm, pVal.Row);
                            }
                            #endregion


                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = false : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before_Action = false : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == "1282")
                    {
                        #region fm_ADD_MODE
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                        #endregion
                    }
                    else if (pVal.MenuUID == "6913")
                    {
                        BubbleEvent = false;
                        return;
                    }

                    #region Cancel
                    else if (pVal.MenuUID == "1284")//Cancel
                    {
                        int i = oApplication.MessageBox("Do you really want to cancel the transaction?", 1, "Yes", "No");
                        if (i == 1)
                        {
                            string DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0).Trim();
                            string Exists = objclsComman.SelectRecord("IF EXISTS(SELECT 1 FROM [@DISP_PLAN1] WHERE DOCENTRY='" + DocEntry + "' AND U_QUANTITY!=U_OPENQTY) BEGIN SELECT '1' END ");
                            if (Exists == "1")
                            {
                                oApplication.StatusBar.SetText("Target document has been created .You can't cancel document. ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                        }
                        if (i == 2)
                        {
                            BubbleEvent = false;
                            return;
                        }
                    }
                    #endregion

                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0);
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "DISP_PLAN" || pVal.MenuUID == "1282")
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == "1292")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1");

                        string Value;
                        Value = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_ItemCode", oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, Value);
                    }
                    else if (pVal.MenuUID == "1293")
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_ItemCode", i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();

                        #region Refresh
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                        Cal_Qty_Rate_Changed(oForm, "V_10", 1, oMatrix.VisualRowCount);
                        Calc_Gross(oForm);
                        Calc_DetailFields(oForm);
                        #endregion

                    }

                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string DocEntry = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("DOCENTRY", 0);
                        string Cancel = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("Canceled", 0);


                        objclsComman.SelectRecord("DELETE FROM [@DISP_PLAN1] WHERE U_ITEMCODE IS NULL AND DOCENTRY='" + DocEntry + "'");


                        string query = "EXEC DISP_GET_SO_ITEMS '" + DocEntry + "'";
                        if (query == string.Empty)
                        {

                        }

                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            objclsComman.SelectRecord(" UPDATE [@DISP_PLAN1] SET U_OpenQty=U_Quantity  WHERE DOCENTRY='" + DocEntry + "'");

                            StringBuilder sbQuery = new StringBuilder();
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_DispQty = ISNULL(T0.U_DispQty,0) + T1.U_Quantity ");
                            sbQuery.Append(" FROM RDR1 T0");
                            sbQuery.Append(" INNER JOIN [@DISP_PLAN1] T1 ON T0.DocEntry =T1.U_BaseKey AND T0.LineNum =T1.U_BaseLine ");
                            sbQuery.Append(" WHERE T1.DocEntry = '" + DocEntry + "' ");

                            objclsComman.SelectRecord(sbQuery.ToString());

                        }
                        if (Cancel == "Y")
                        {
                            objclsComman.SelectRecord(" UPDATE [@DISP_PLAN] SET Canceled='Y' WHERE DOCENTRY='" + DocEntry + "'");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");
                        string CardCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_CardCode", 0);
                        string canceled = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("Canceled", 0);
                        FillContactPerson(oForm, CardCode);

                        string U_Approved = oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_Approved", 0);
                        oItem = oForm.Items.Item("mtx");
                        SAPbouiCOM.Item oItem1 = oForm.Items.Item("OthChg");

                        if (U_Approved == "Y")
                        {
                            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
                            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem1);
                        }
                        else
                        {
                            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_Default);
                            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_Default);

                            oItem1.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_Default);
                            oItem1.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_Default);
                        }
                        if (canceled == "Y")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Method


        private void LoadForm(string MenuID)
        {
            if (MenuID == "DISP_PLAN")
            {
                //objclsComman.LoadFromXML(MenuID, "DocEntry", "A");
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, "A");
                clsVariables.boolCFLSelected = false;
                oForm = oApplication.Forms.ActiveForm;
                //oForm = oApplication.Forms.Item(MenuID);
                oForm.EnableMenu("5895", true);
                oForm.EnableMenu("1283", false); // Cancel
                oForm.EnableMenu("1286", false); // Close

                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(branchUID).Specific;
                if (isBranchDatabase == "Y")
                {
                    objclsComman.FillCombo(oCombo, "SELECT T0.[BPLId], T0.[BPLName] FROM OBPL T0");
                    objclsComman.SetAutoManagedAttribute_UpdateMode(oCombo.Item);
                }
                else
                {
                    oCombo.Item.Disable();
                }

                string Appr = objclsComman.SelectRecord("SELECT U_DPApp FROM OUSR WHERE USERID='" + oCompany.UserSignature + "'");
                if (Appr.Trim() != "Y")
                {
                    oItem = oForm.Items.Item("chkApp");
                    oItem.Visible = false;
                }

                string ReportType = objclsComman.SelectRecord("SELECT CODE FROM RTYP WHERE MNU_ID='" + MenuID + "' AND ADD_NAME='SALES'");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;

                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Customer Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("C"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_CARD", "2", "", "", alCondVal);

                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("121"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_OR); //Condition RelationShip (And/Or)
                //temp.Add("ItmsGrpCod"); //Condition Alias             
                //temp.Add("124"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);

                //temp = new ArrayList();
                //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                //temp.Add("InvntItem"); //Condition Alias             
                //temp.Add("N"); //Condition Value
                //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                //alCondVal.Add(temp);
                //StringBuilder sb = new StringBuilder();
                //sb.Append(" SELECT ITEMCODE FROM OITM T0 INNER JOIN OITB T1 ON T0.ITMSGRPCOD=T1.ITMSGRPCOD ");
                //sb.Append("WHERE T1.ITMSGRPNAM LIKE '%SOG FG%' AND InvntItem='N'");

                //objclsComman.AddChooseFromList_WithCond(oForm, "CFL_FG", "4", sb.ToString(), "ItemCode", null);
                //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("ItemCode").Specific;
                //oEdit.ChooseFromListUID = "CFL_FG";
                //oEdit.ChooseFromListAlias = "ItemCode";
                #endregion

            }

            //oForm = oApplication.Forms.Item("DISP_PLAN");
            oForm = oApplication.Forms.ActiveForm;

            #region Series And DocNum
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(0).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), "DISP_PLAN").ToString();
                oForm.DataSources.DBDataSources.Item(0).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion

            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }


            oItem = oForm.Items.Item("CardCode");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);
            oItem = oForm.Items.Item("DocNum");
            objclsComman.SetAutoManagedAttribute(oItem);
            oItem = oForm.Items.Item("DocDate");
            objclsComman.SetAutoManagedAttribute_UpdateMode(oItem);

            oItem = oForm.Items.Item("Status");
            objclsComman.SetAutoManagedAttribute(oItem);

            oItem = oForm.Items.Item("Canceled");
            objclsComman.SetAutoManagedAttribute(oItem);
            oForm.Select();




        }
        private void FillContactPerson(SAPbouiCOM.Form oForm, string CardCode)
        {
            SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("CntCode").Specific;
            objclsComman.FillCombo(oCombo, "SELECT CNTCTCODE,NAME FROM OCPR WHERE CardCode='" + CardCode + "' ORDER BY CNTCTCODE");

            string DefContactPerson = objclsComman.SelectRecord("SELECT T1.CNTCTCODE FROM OCRD T0 INNER JOIN OCPR T1 ON T0.CARDCODE=T1.CARDCODE WHERE T0.CardCode='" + CardCode + "'");
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_CntCode", 0, DefContactPerson);
            //oCombo.Select(DefContactPerson, BoSearchKey.psk_ByValue);

            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("NumAtCar").Specific;
            //oEdit.Active = true;
        }
        public void Calc_DetailFields(SAPbouiCOM.Form oForm)
        {

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double NoCrat = 0;
            double TotalNoCrat = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            double Amount = 0;
            double TotalAmount = 0;
            string Combine = string.Empty;
            oMatrix.FlushToDataSource();
            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
            {
                try
                {
                    //  Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", i)).ToString());
                    NoCrat = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_NoCrat", i - 1).ToString());
                    Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Combine", i - 1).ToString().Trim();
                    if (Combine == string.Empty)
                    {
                        TotalNoCrat = TotalNoCrat + NoCrat;
                    }
                    else
                    {

                        if (oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_SkipRow", i - 1).ToString() == "N")
                        {
                            TotalNoCrat = TotalNoCrat + NoCrat;
                        }
                    }

                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Netwt", i - 1).ToString());
                    TotalNetwt = TotalNetwt + (Netwt * NoCrat);

                    GrsWt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_GrsWt", i - 1).ToString());
                    TotalGrsWt = TotalGrsWt + (GrsWt * NoCrat);

                    Amount = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Amount", i - 1).ToString());
                    TotalAmount = TotalAmount + Amount;

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                }
            }
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotCrat", 0, TotalNoCrat.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_Total", 0, TotalAmount.ToString());
            TotalAmount = TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_OthChg", 0).ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_GTotal", 0, TotalAmount.ToString());


        }
        public void Calc_Gross(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double Netwt = 0;
            double GrsWt = 0;
            double CrWeight = 0;
            string Combine = string.Empty;
            string InnerLoop_Combine = string.Empty;

            oMatrix.FlushToDataSource();

            ArrayList ALCombine = new ArrayList();
            ArrayList temp = new ArrayList();

            #region Set Skip Row to Blank
            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
            {
                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_SkipRow", i - 1, "");//Pravin
            }
            #endregion

            #region Checking Matching Combine Rows


            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
            {
                Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Combine", i - 1).ToString().Trim();

                if (Combine != string.Empty)
                {
                    for (int j = i + 1; j <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; j++)
                    {
                        InnerLoop_Combine = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Combine", j - 1).ToString().Trim();
                        if (Combine == InnerLoop_Combine)
                        {
                            if (temp.Contains(Combine) == false)
                            {
                                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_SkipRow", i - 1, "N");//Pravin
                            }
                            ALCombine.Add(i.ToString());
                            temp.Add(Combine);
                            break;
                        }
                    }
                }
            }
            #endregion


            if (ALCombine.Count == 0)
            {
                for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
                {
                    oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + i.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    CrWeight = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_PCCrate", i - 1).ToString());
                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Netwt", i - 1).ToString());
                    GrsWt = Netwt + CrWeight;
                    GrsWt = Math.Round(GrsWt, 2);
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_GrsWt", i - 1, GrsWt.ToString());//Pravin

                }
                oMatrix.LoadFromDataSource();
                oApplication.StatusBar.SetText("Gross Weight Calculation completed.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

                return;
            }

            #region Setting Gross Weight
            for (int Row = 1; Row <= ALCombine.Count; Row++)
            {
                try
                {

                    oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + Row.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    int i = int.Parse(ALCombine[Row - 1].ToString());
                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Netwt", i - 1).ToString());
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_GrsWt", i - 1, Netwt.ToString());
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                }

            }
            #endregion

            oMatrix.LoadFromDataSource();
            oApplication.StatusBar.SetText("Gross Weight Calculation completed.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

        }
        public void Cal_Qty_Rate_Changed(SAPbouiCOM.Form oForm, string ColUID, int FromRow, int ToRow)
        {
            //V_10 Quantity
            //V_9 Rate


            string ItemCode = string.Empty;
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();

            double Totalwt = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double NoCrate = 0;
            double Package = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            string SWeight1 = string.Empty;
            string Quantity = string.Empty;
            double NoPack = 0;
            string CrWeight = string.Empty;
            double Rate = 0;
            double Total = 0;

            for (int i = FromRow; i <= ToRow; i++)
            {
                try
                {
                    Totalwt = 0;
                    Netwt = 0;
                    TotalNetwt = 0;
                    NoCrate = 0;
                    Package = 0;
                    GrsWt = 0;
                    TotalGrsWt = 0;

                    ItemCode = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_ItemCode", i - 1).ToString();
                    Quantity = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Quantity", i - 1).ToString();

                    //SWeight1 = objclsComman.SelectRecord(" SELECT SWeight1 from OITM WHERE ITEMCODE='" + ItemCode + "'");
                    SWeight1 = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_StWt", i - 1).ToString();

                    SWeight1 = SWeight1 == string.Empty ? "0" : SWeight1;
                    Quantity = Quantity == string.Empty ? "0" : Quantity;

                    NoPack = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_NoPack", i - 1).ToString());
                    Rate = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Rate", i - 1).ToString());

                    if (NoPack != 0)
                    {
                        Package = double.Parse(Quantity) / NoPack;
                        Package = Math.Ceiling(Package);
                    }
                    NoPack = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_NoPack", i - 1).ToString());
                    CrWeight = oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_PCCrate", i - 1).ToString();
                    CrWeight = CrWeight == string.Empty ? "0" : CrWeight;

                    if (ColUID == "V_10")
                    {
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_NoCrat", i - 1, Package.ToString());
                    }
                    else if (ColUID == "V_11")
                    {
                        oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_NoCrat", i - 1, Package.ToString());
                    }

                    NoCrate = Package;

                    Totalwt = (double.Parse(Quantity) * double.Parse(SWeight1));
                    Netwt = double.Parse(SWeight1) * NoPack;
                    GrsWt = Netwt + double.Parse(CrWeight);
                    GrsWt = Math.Round(GrsWt, 2);
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_Netwt", i - 1, Netwt.ToString());
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_GrsWt", i - 1, GrsWt.ToString());//Pravin
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_OpenQty", i - 1, Quantity);//Apply only Dispatch Planning
                    Total = double.Parse(Quantity) * Rate;
                    oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_Amount", i - 1, Total.ToString());
                }
                catch { }
            }


            oMatrix.LoadFromDataSource();

            double TotalNoCrate = 0;
            for (int i = 1; i <= oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").Size; i++)
            {
                try
                {
                    NoCrate = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_NoCrat", i - 1).ToString());
                    TotalNoCrate = TotalNoCrate + NoCrate; //Pravin

                    Netwt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_Netwt", i - 1).ToString());
                    TotalNetwt = TotalNetwt + (Netwt * NoCrate); //Pravin

                    GrsWt = double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").GetValue("U_GrsWt", i - 1).ToString());
                    TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                }
            }
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotCrat", 0, TotalNoCrate.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());

            Calc_TotalAmount(oForm);
        }
        private void Calc_TotalAmount(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double Quantity = 0;
            double Rate = 0;
            double Total = 0;
            double TotalAmount = 0;

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                Quantity = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_10", i)).String);
                Rate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_9", i)).String);
                Total = Quantity * Rate;
                TotalAmount = TotalAmount + Total;
            }

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_Total", 0, TotalAmount.ToString());
            TotalAmount = TotalAmount + double.Parse(oForm.DataSources.DBDataSources.Item("@DISP_PLAN").GetValue("U_OthChg", 0).ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_GTotal", 0, TotalAmount.ToString());
        }
        public void Calc_NoOfCrate_Changed(SAPbouiCOM.Form oForm, int FromRow, int ToRow)
        {
            //V_6 No of Crate

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            double TotalAmount = 0;
            double Netwt = 0;
            double TotalNetwt = 0;
            double GrsWt = 0;
            double TotalGrsWt = 0;
            double NoCrate = 0;

            oMatrix.FlushToDataSource();
            for (int i = FromRow; i <= ToRow; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);
                double PCPerCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", i)).String);
                oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_WtPack", i - 1, (NoCrate * PCPerCrate).ToString());
            }
            oMatrix.LoadFromDataSource();

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);
                TotalAmount = TotalAmount + NoCrate;

                Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", i)).String);
                TotalNetwt = TotalNetwt + (Netwt * NoCrate);

                GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).String);
                TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
            }
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotCrat", 0, TotalAmount.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotNwt", 0, TotalNetwt.ToString());
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());


        }
        public void Calc_PCPerCrate_Changed(SAPbouiCOM.Form oForm, int Row)
        {
            //V_5 PCS Per Crate
            double TotalGrsWt = 0;

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
            oMatrix.FlushToDataSource();
            double NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", Row)).String);
            double PCPerCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_5", Row)).String);
            double Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_8", Row)).String);

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_WtPack", Row - 1, (NoCrate * PCPerCrate).ToString());
            double GrsWt = Netwt + (PCPerCrate);
            oForm.DataSources.DBDataSources.Item("@DISP_PLAN1").SetValue("U_GrsWt", Row - 1, Math.Round(GrsWt, 2).ToString()); //Pravin

            oMatrix.LoadFromDataSource();

            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_6", i)).String);

                GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_7", i)).String);
                TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
            }

            oForm.DataSources.DBDataSources.Item("@DISP_PLAN").SetValue("U_TotGrWt", 0, TotalGrsWt.ToString());
        }


        #endregion
    }
}

