using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace Sales
{
    class clsCommon : Connection
    {

        #region Constructor
        public clsCommon()
        {
        }
        #endregion

        #region Methods



        #region Add Menu

        public void AddMenu(SAPbouiCOM.BoMenuType boMenuType, string FatherID, string UniqueID, string Name, int Position)
        {
            try
            {
                SAPbouiCOM.Menus oMenus = null;
                SAPbouiCOM.MenuItem oMenuItem = null;

                oMenus = oApplication.Menus;

                SAPbouiCOM.MenuCreationParams oCreationPackage = null;
                oCreationPackage = ((SAPbouiCOM.MenuCreationParams)oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_MenuCreationParams));
                oMenuItem = oApplication.Menus.Item(FatherID);
                oCreationPackage.Type = boMenuType;
                oCreationPackage.UniqueID = UniqueID;
                oCreationPackage.String = Name;
                oCreationPackage.Position = Position;
                oCreationPackage.Enabled = true;
                oMenus = oMenuItem.SubMenus;
                if (oMenus.Exists(UniqueID) == false)
                    oMenus.AddEx(oCreationPackage);
            }
            catch { }
        }

        #endregion

        #region Database

        public bool CreateDataBase()
        {
            try
            {
                string ProcessName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

                oApplication.StatusBar.SetText("Please Wait....creating UDO of " + ProcessName + " addon", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                CreateTables();

                CreateUserObject("DISP_PLAN_UPLOAD", "Dispatch Planning Upload", "DISP_PLAN_UPLOAD", "DISP_PLAN_UPLOAD1", "", "", false);
                CreateUserObject("DISP_PLAN", "Dispatch Planning", "DISP_PLAN", "DISP_PLAN1", "", "", false);
                CreateUserObjectMASTER("PORT", "Port Master", "PORT", "", "", "", false);
                CreateUserObject("DEL_ORDER", "Delivery Order", "DEL_ORDER", "DEL_ORDER1", "", "", false);
                CreateUserObject("STUFF", "Stuffing", "STUFF", "STUFF1", "", "", false);

                //CreateUserObject("CS_PRDREC", "CostSheet Prod Recording", "CS_PRDREC", "CS_PRDREC1", "", "", false);
                CreateFields();
                ReportService();




                return true;
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message.ToString(), 1, "ok", "", "");
                return false;
            }
        }

        public Boolean FieldDetails(string TableName, string FieldName, string FieldDesc, string FieldType, bool Mandatory, int FieldSize, string DefaultVal, string LinkedTable, string LinkedUDO, string TableType)
        {
            string ErrMsg;
            int errCode;
            int IRetCode;
            SAPbobsCOM.UserFieldsMD oUserFieldsMD = null;
            SAPbobsCOM.Recordset oRs = null;

            try
            {
                oRs = (SAPbobsCOM.Recordset)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                string sqlQuery = string.Empty;
                if (TableType == "C")
                {
                    sqlQuery = string.Format("SELECT T0.TableID, T0.FieldID FROM CUFD T0 WHERE T0.TableID = '@{0}' AND T0.AliasID = '{1}'", TableName, FieldName);
                }
                else
                {
                    sqlQuery = string.Format("SELECT T0.TableID, T0.FieldID FROM CUFD T0 WHERE T0.TableID = '{0}' AND T0.AliasID = '{1}'", TableName, FieldName);
                }
                oRs.DoQuery(sqlQuery);

                bool retflag = false;

                if (oRs.RecordCount == 1)
                {
                    retflag = true;
                }

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                oRs = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();

                if (retflag == true) return true;

                if (oUserFieldsMD == null)
                {
                    oUserFieldsMD = ((SAPbobsCOM.UserFieldsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)));
                }
                oUserFieldsMD.TableName = TableName;
                oUserFieldsMD.Name = FieldName;
                oUserFieldsMD.Description = FieldDesc;
                switch (FieldType)
                {
                    case "Alpha":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;
                        if (LinkedTable != string.Empty)
                        {
                            oUserFieldsMD.LinkedTable = LinkedTable;
                        }
                        if (LinkedUDO != string.Empty)
                        {
                            oUserFieldsMD.LinkedUDO = LinkedUDO;
                        }
                        break;
                    case "Text":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo; // alphanumeric type                   
                        // oUserFieldsMD.EditSize = FieldSize;

                        break;
                    case "Integer":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Numeric; //  Integer type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case "Date":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date; // Date type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        break;

                    case "Time":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date; // Time type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Time;
                        break;

                    case "Amount":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Sum; // Amount type
                        break;
                    case "Quantity":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Quantity; // Amount type
                        break;
                    case "Percent":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Percentage; // Amount type
                        break;
                    case "UnitTotal":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Measurement; // Amount type
                        break;
                    case "Measure":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Measurement; // Amount type
                        break;
                    case "YN":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Y";
                        oUserFieldsMD.ValidValues.Description = "Y";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "N";
                        oUserFieldsMD.ValidValues.Description = "N";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "Crate":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "WOOD";
                        oUserFieldsMD.ValidValues.Description = "WOOD";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "IRON";
                        oUserFieldsMD.ValidValues.Description = "IRON";
                        oUserFieldsMD.ValidValues.Add();


                        break;


                    case "QCStatus":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "N";
                        oUserFieldsMD.ValidValues.Description = "Not Started";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "P";
                        oUserFieldsMD.ValidValues.Description = "Pending";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "H";
                        oUserFieldsMD.ValidValues.Description = "On Hold";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "C";
                        oUserFieldsMD.ValidValues.Description = "Completed";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "R";
                        oUserFieldsMD.ValidValues.Description = "Reject";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "SItmType_NA":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "MA";
                        oUserFieldsMD.ValidValues.Description = "Material";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "PK";
                        oUserFieldsMD.ValidValues.Description = "Packing";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "NA";
                        oUserFieldsMD.ValidValues.Description = "NA";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "SItmType":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "MA";
                        oUserFieldsMD.ValidValues.Description = "Material";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "PK";
                        oUserFieldsMD.ValidValues.Description = "Packing";
                        oUserFieldsMD.ValidValues.Add();

                        break;


                    case "Importance":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "High";
                        oUserFieldsMD.ValidValues.Description = "High";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Medium";
                        oUserFieldsMD.ValidValues.Description = "Medium";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "Low";
                        oUserFieldsMD.ValidValues.Description = "Low";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "PrjtName":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "CS";
                        oUserFieldsMD.ValidValues.Description = "Cost Sheet";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "BO";
                        oUserFieldsMD.ValidValues.Description = "Base Oil";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case "VCType":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "V";
                        oUserFieldsMD.ValidValues.Description = "Vat";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "C";
                        oUserFieldsMD.ValidValues.Description = "CST";
                        oUserFieldsMD.ValidValues.Add();


                        break;


                    case "Rate":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Rate;
                        break;
                    case "Price":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Price;
                        break;
                    case "Link":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo; // alphanumeric type 
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Link;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case "YesNo":
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Yes";
                        oUserFieldsMD.ValidValues.Description = "Yes";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "No";
                        oUserFieldsMD.ValidValues.Description = "No";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.DefaultValue = "No";
                        break;

                }
                //if (Mandatory)
                //{
                //    oUserFieldsMD.Mandatory = SAPbobsCOM.BoYesNoEnum.tYES;

                //}
                if (DefaultVal != "")
                {
                    oUserFieldsMD.DefaultValue = DefaultVal;

                }

                // Add the field to the table
                IRetCode = oUserFieldsMD.Add();
                if (IRetCode != 0)
                {
                    oCompany.GetLastError(out errCode, out ErrMsg);
                }
                return true;
            }
            finally
            {
                if (oUserFieldsMD != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldsMD);

                if (oRs != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);

                oUserFieldsMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                //return false ;
            }
        }

        public Boolean CreateFields()
        {
            try
            {

                #region Marketing Documents

                FieldDetails("ORDR", "PRTOFLDG", "Port of Loading", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "PRTOFDSHG ", "Port of Discharge", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "PRTOFDSTN ", "Port of Destination", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "RATETYP ", "Payment Type", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "PRECRGBY ", "Pre Carriage By", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "VESSEL ", "Vessel", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "CONTERNO ", "Container No.", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "FNLCNTY ", "FNLCNTY", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "shpingMARK ", "Shipping Marks", "Alpha", false, 200, "", "", "", "S");

                FieldDetails("ORDR", "TotCrat", "Total Crates", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "TotNwt", "Total Net Wt", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("ORDR", "TotGrWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "S");


                FieldDetails("RDR1", "TESTBAR ", "TESTBAR", "Alpha", false, 200, "", "", "", "S");
                FieldDetails("RDR1", "PNTUNPNT ", "TESTBAR", "Alpha", false, 200, "", "", "", "S");

                FieldDetails("RDR1", "NOPACKING", "Packing Qty.", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("RDR1", "NETWT", "Net Wt", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("RDR1", "GRSWT", "Total Gross Wt", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("RDR1", "CRTWT", "PCs Per Crate", "Quantity", false, 200, "", "", "", "S");
                FieldDetails("RDR1", "TOTCRTWT", "Wt. of Packing", "Quantity", false, 200, "", "", "", "S");

                FieldDetails("RDR1", "BaseLine", "BaseLine", "Alpha", false, 5, "", "", "", "S");
                FieldDetails("RDR1", "BaseEntry", "BaseEntry", "Alpha", false, 15, "", "", "", "S");
                FieldDetails("RDR1", "BaseType", "BaseType", "Alpha", false, 15, "", "", "", "S");
                FieldDetails("RDR1", "SODocEn", "SO DocEntry", "Alpha", false, 15, "", "", "", "S");
                FieldDetails("RDR1", "SOLine", "SO Line No.", "Alpha", false, 10, "", "", "", "S");

                FieldDetails("RDR1", "Combine", "Combine", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("RDR1", "SkipRow", "SkipRow", "Alpha", false, 1, "", "", "", "C");
                FieldDetails("RDR1", "DispQty", "Dispatch Quantity", "Quantity", false, 1, "", "", "", "C");

                //FieldDetails("DLN1", "FOB", "FOB", "Amount", false, 40, "", "", "");
                //FieldDetails("DLN1", "INRATE", "IN RATE", "Amount", false, 40, "", "", "");

                FieldDetails("DLN1", "FOBVALUE", "FOB Value", "Amount", false, 40, "", "", "", "S");
                FieldDetails("DLN1", "RATEININR", "IN RATE", "Rate", false, 40, "", "", "", "S");


                FieldDetails("OUSR", "DPApp", "Dispatch Approval", "YN", false, 1, "", "", "", "S");
                FieldDetails("OUSR", "SPApp", "Stuffing Approval", "YN", false, 1, "", "", "", "S");

                FieldDetails("DATABASE", "SqlPwd", "Sql Password", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("PKL1", "DONo", "Delivery Order No", "ALpha", false, 15, "", "", "", "S");
                FieldDetails("PKL1", "FOB", "FOB", "Amount", false, 40, "", "", "", "S");
                FieldDetails("PKL1", "INRATE", "IN RATE", "Amount", false, 40, "", "", "", "S");


                #endregion

                #region Port
                FieldDetails("PORT", "PORTNAME", "Port Name", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("PORT", "CUSTNAME", "Customer Name", "Alpha", false, 200, "", "", "", "C");
                #endregion

                #region Dispatch Planning Upload
                FieldDetails("DISP_PLAN_UPLOAD", "UpDate", "Upload Date", "Date", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD", "UpPath", "Upload Path", "Alpha", false, 250, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD", "BPLId", "Branch", "Alpha", false, 10, "", "", "", "C");

                FieldDetails("DISP_PLAN_UPLOAD1", "BaseRef", "SO DocNum", "c", false, 20, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "SOLineId", "SO Line ID", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "SOSeries", "SO Series", "Alpha", false, 50, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "CardCode", "Customer Code", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "CardName", "Customer Name", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Branch", "Branch", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "DispNo", "Dispatch Planning No", "Alpha", false, 20, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "DispSer", "Dispatch Planning Series", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "DispDate", "Dispatch Planning Date", "Date", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "ItemCode", "ItemCode", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "ItemName", "ItemName", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Quantity", "Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Rate", "Rate", "Rate", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Amount", "Amount", "Amount", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN_UPLOAD1", "NoPack", "PCs Per Crate", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "NoCrat", "No of Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "PCCrate", "Weight Per Crate", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "WtPack", "Wt. of Packing", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "SkipRow", "SkipRow", "Alpha", false, 1, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Combine", "Combine", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "OthChg", "Other Charges", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Remarks", "Remarks", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "TrEn", "Target Entry", "Alpha", false, 20, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "TrLine", "Target Line", "Alpha", false, 10, "", "", "", "C");

                FieldDetails("DISP_PLAN_UPLOAD1", "BaseKey", "BaseKey", "Alpha", false, 20, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "BaseLine", "BaseLine", "Alpha", false, 4, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "BaseOQty", "Base Open Quantity", "Quantity", false, 4, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "WhsCode", "WhsCode", "Alpha", false, 16, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "OnHand", "OnHand", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Marking", "Marking", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "StWt", "Standard Weight", "Measure", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "Netwt", "Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "GrsWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN_UPLOAD1", "Total", "Total", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "TotCrat", "Total Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "TotNwt", "Total Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "TotGrWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN_UPLOAD1", "GTotal", "Grand Total", "Amount", false, 200, "", "", "", "C");

                #endregion

                #region Dispatch Planning

                FieldDetails("DISP_PLAN", "CardCode", "Customer Code", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN", "CardName", "Customer Name", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "CntCode", "Contact Person Code", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "NumAtCar", "Customer Reference No.", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DISP_PLAN", "DocDate", "DocDate", "Date", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "Port", "Port of Discharge", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "BPLId", "Branch", "Alpha", false, 10, "", "", "", "C");

                //FieldDetails("DISP_PLAN", "PortLDG", "Port of Loading", "Alpha", false, 200, "", "", "");
                //FieldDetails("DISP_PLAN", "PortDST", "Port of Destination", "Alpha", false, 200, "", "", "");
                FieldDetails("DISP_PLAN", "Total", "Total", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "OthChg", "Other Charges", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "GTotal", "Grand Total", "Amount", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN", "TotCrat", "Total Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "TotNwt", "Total Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "TotGrWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN", "Remarks", "Remarks", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DISP_PLAN", "Approved", "Approved", "YN", false, 1, "", "", "", "C");
                FieldDetails("DISP_PLAN", "UPDispNo", "Upload Dispatch No", "Alpha", false, 20, "", "", "", "C");

                FieldDetails("DISP_PLAN1", "ItemCode", "ItemCode", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "ItemName", "ItemName", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "Marking", "Marking", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "Quantity", "Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "OpenQty", "Open Quantity", "Quantity", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN1", "BCOQty", "Base Copied Qty", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "OnHand", "On Hand", "Quantity", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN1", "Rate", "Rate", "Rate", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "NoPack", "No of Pack", "Quantity", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN1", "Netwt", "Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "GrsWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "NoCrat", "No of Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "PCCrate", "PCs Per Crate", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "WtPack", "Wt. of Packing", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "StWt", "Standard Weight", "Measure", false, 200, "", "", "", "C");

                FieldDetails("DISP_PLAN1", "Amount", "Amount", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "BaseRef", "BaseRef", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "BaseKey", "BaseKey", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "BaseLine", "BaseLine", "Alpha", false, 4, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "BaseType", "BaseType", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "WhsCode", "WhsCode", "Alpha", false, 16, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "NumAtCar", "Reference No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "Combine", "Combine", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DISP_PLAN1", "SkipRow", "SkipRow", "Alpha", false, 1, "", "", "", "C");


                #endregion

                #region Delivery Order

                #region General Tab
                FieldDetails("DEL_ORDER", "CardCode", "Customer Code", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER", "CardName", "Customer Name", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "CntCode", "Contact Person Code", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "NumAtCar", "Customer Reference No.", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DEL_ORDER", "DocDate", "DocDate", "Date", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Port", "Port of Discharge", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "BPLId", "Branch", "Alpha", false, 10, "", "", "", "C");

                //FieldDetails("DEL_ORDER", "PortLDG", "Port of Loading", "Alpha", false, 200, "", "", "", "C");
                //FieldDetails("DEL_ORDER", "PortDST", "Port of Destination", "Alpha", false, 200, "", "", "", "C");

                FieldDetails("DEL_ORDER", "Total", "Total", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "OthChg", "Other Charges", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TotCrat", "Total Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TotNwt", "Total Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TotGrWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Remarks", "Remarks", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DEL_ORDER", "GTotal", "Grand Total", "Amount", false, 254, "", "", "", "C");
                FieldDetails("DEL_ORDER", "MTFOBRs", "Matrix Total FOB in. Rs", "Amount", false, 254, "", "", "", "C");

                FieldDetails("DEL_ORDER1", "ItemCode", "ItemCode", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "ItemName", "ItemName", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Marking", "Marking", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Quantity", "Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "OpenQty", "Open Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "InStock", "InStock", "Quantity", false, 200, "", "", "", "C");

                FieldDetails("DEL_ORDER1", "BCOQty", "Base Copied Qty", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Rate", "Rate", "Rate", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "NoPack", "No of Pack", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Netwt", "Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "GrsWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "NoCrat", "No of Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "PCCrate", "PCs Per Crate", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "WtPack", "Wt. of Packing", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Amount", "Amount", "Amount", false, 200, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "SONo", "Sales Order No.", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "SODocEn", "Sales Order DocEntry", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "SOLine", "Sales Line No.", "Alpha", false, 10, "", "", "", "C");

                FieldDetails("DEL_ORDER1", "FOBValue", "FOB Value", "Amount", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "InrRate", "Rate In Inr", "Rate", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "StWt", "Standard Weight", "Measure", false, 200, "", "", "", "C");

                FieldDetails("DEL_ORDER1", "BaseRef", "BaseRef", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "BaseKey", "BaseKey", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "BaseLine", "BaseLine", "Alpha", false, 4, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "BaseType", "BaseType", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Curr", "Currency", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "WhsCode", "WhsCode", "Alpha", false, 16, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "NumAtCar", "Reference No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "Combine", "Combine", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER1", "SkipRow", "SkipRow", "Alpha", false, 1, "", "", "", "C");
                #endregion

                #region Logistics

                FieldDetails("DEL_ORDER", "PreCarBy", "Pre Carriage By", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PlaceRec", "Place of Receipts", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Vessels", "Vessels", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PortLoad", "Port of Loading", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PortDisc", "Port of Discharge", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "FinDest", "Final Destination", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TermsPay", "Terms of Payment", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TermsDel", "Terms of Delivery", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("DEL_ORDER", "VesName", "Vessel Name", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "ShpMarks", "Shipping Marks", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "ShpAgent", "Shipping Agent", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PayType", "Payment Type", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "FactAddr", "Factory Address", "Alpha", false, 254, "", "", "", "C");

                FieldDetails("DEL_ORDER", "ShpBiNo", "Shipping Bill No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "ShpBiDt", "Shipping Bill Date", "Date", false, 4, "", "", "", "C");
                FieldDetails("DEL_ORDER", "MateReNo", "Mate Rect No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "MateReDt", "Mate Rect Date", "Date", false, 4, "", "", "", "C");
                FieldDetails("DEL_ORDER", "VoyNo", "Voyage No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PayTerms", "Payment Terms", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("DEL_ORDER", "PayDay", "Payment Day", "Alpha", false, 10, "", "", "", "C");

                #endregion

                #region Miscellaneous
                FieldDetails("DEL_ORDER", "TotCIFF", "Total C.I.F in Foreign", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Freight", "Freight", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Insurance", "Insurance", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "AgntComm", "Agent Commission", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Disc", "Discount", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TotFOBF", "Total F.O.B in Foreign", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "TotFOBRs", "Total F.O.B in Rs", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "RateType", "Rate Type", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER", "Curr", "Currency", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("DEL_ORDER", "GRExch", "G.R. Exchange", "Amount", false, 10, "", "", "", "C");
                FieldDetails("DEL_ORDER", "SFBFOB", "SFB F.O.B", "Amount", false, 254, "", "", "", "C");

                #endregion

                #endregion

                #region Stuffing

                FieldDetails("STUFF", "CardCode", "Customer Code", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("STUFF", "CardName", "Customer Name", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "CntCode", "Contact Person Code", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "NumAtCar", "Customer Reference No.", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("STUFF", "SealNo", "Seal No.", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("STUFF", "DocDate", "DocDate", "Date", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "Port", "Port of Discharge", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "PortLoad", "Port of Loading", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "PortDST", "Port of Destination", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "ContNo", "Container No", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "ShpAgnt", "Shipping Agent", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "VehNo", "Vehicle No", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("STUFF", "Total", "Total", "Amount", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "PayLWt", "Pay Load Weight", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "TrWt", "Tare Weight", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "OthChg", "Other Charges", "Amount", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "TotCrat", "Total Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "TotNwt", "Total Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "TotGrWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF", "Remarks", "Remarks", "Alpha", false, 254, "", "", "", "C");
                FieldDetails("STUFF", "Approved", "Approved", "YN", false, 1, "", "", "", "C");
                FieldDetails("STUFF", "GRExch", "G.R. Exchange", "Amount", false, 10, "", "", "", "C");
                FieldDetails("STUFF", "BPLId", "Branch", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("STUFF", "PortDisc", "Port of Discharge", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "FinDest", "Final Destination", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "PayType", "Payment Type", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "PayTerms", "Payment Terms", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "VesName", "Vessel Name", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "Curr", "Currency", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("STUFF", "ESealNo", "E-Seal No", "Alpha", false, 50, "", "", "", "C");
                FieldDetails("STUFF", "Funigat", "Funigation", "Alpha", false, 50, "", "", "", "C");
                FieldDetails("STUFF", "PlaceRec", "Place of Receipts", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "ShpMarks", "Shipping Marks", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF", "PreCarBy", "Pre Carriage By", "Alpha", false, 100, "", "", "", "C");

                FieldDetails("STUFF1", "ItemCode", "ItemCode", "Alpha", false, 40, "", "", "", "C");
                FieldDetails("STUFF1", "ItemName", "ItemName", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Marking", "Marking", "Alpha", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Quantity", "Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "OpenQty", "Open Quantity", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "StWt", "Standard Weight", "Measure", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "BCOQty", "Base Copied Qty", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Rate", "Rate", "Rate", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "NoPack", "No of Pack", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Netwt", "Net Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "GrsWt", "Total Gross Wt", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "NoCrat", "No of Crates", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "PCCrate", "PCs Per Crate", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "WtPack", "Wt. of Packing", "Quantity", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Amount", "Amount", "Amount", false, 200, "", "", "", "C");

                FieldDetails("STUFF1", "Rocking", "Rocking", "YN", false, 1, "", "", "", "C");
                FieldDetails("STUFF1", "Stuffing", "Stuffing", "YN", false, 1, "", "", "", "C");
                FieldDetails("STUFF1", "Crate", "Crate", "Crate", false, 6, "", "", "", "C");
                FieldDetails("STUFF1", "Plastic", "Plastic", "YN", false, 200, "", "", "", "C");
                FieldDetails("STUFF1", "Packing", "Packing", "Alpha", false, 10, "", "", "", "C");


                FieldDetails("STUFF1", "FOBValue", "FOB Value", "Amount", false, 40, "", "", "", "C");
                FieldDetails("STUFF1", "InrRate", "Rate In Inr", "Rate", false, 40, "", "", "", "C");
                FieldDetails("STUFF1", "SONo", "Sales Order No.", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("STUFF1", "SODocEn", "Sales Order DocEntry", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("STUFF1", "SOLine", "Sales Line No.", "Alpha", false, 10, "", "", "", "C");

                FieldDetails("STUFF1", "BaseRef", "BaseRef", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("STUFF1", "BaseKey", "BaseKey", "Alpha", false, 15, "", "", "", "C");
                FieldDetails("STUFF1", "BaseLine", "BaseLine", "Alpha", false, 4, "", "", "", "C");
                FieldDetails("STUFF1", "BaseType", "BaseType", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("STUFF1", "WhsCode", "WhsCode", "Alpha", false, 16, "", "", "", "C");
                FieldDetails("STUFF1", "NumAtCar", "Reference No.", "Alpha", false, 100, "", "", "", "C");
                FieldDetails("STUFF1", "Combine", "Combine", "Alpha", false, 10, "", "", "", "C");
                FieldDetails("STUFF1", "SkipRow", "SkipRow", "Alpha", false, 1, "", "", "", "C");
                #endregion

                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateTables()
        {
            try
            {
                CreateTable("DATABASE", "Database Configuration", "Object");
                CreateTable("PORT", "Port Master", "Master");

                CreateTable("DISP_PLAN_UPLOAD", "Dispatch Planning Upload", "Document");
                CreateTable("DISP_PLAN_UPLOAD1", "Dispatch Planning Upload-Rows", "DocLine");

                CreateTable("DISP_PLAN", "Dispatch Planning", "Document");
                CreateTable("DISP_PLAN1", "Dispatch Planning-Rows", "DocLine");

                CreateTable("DEL_ORDER", "Delivery Order", "Document");
                CreateTable("DEL_ORDER1", "Delivery Order-Rows", "DocLine");

                CreateTable("STUFF", "Stuffing", "Document");
                CreateTable("STUFF1", "Stuffing-Rows", "DocLine");

                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateTable(string TableName, string TableDesc, string TableType)
        {
            SAPbobsCOM.UserTablesMD oUserTablesMD = null;
            try
            {

                if (oUserTablesMD == null)
                {
                    oUserTablesMD = ((SAPbobsCOM.UserTablesMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables)));
                }
                if (oUserTablesMD.GetByKey(TableName) == true)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    return true;
                }
                oUserTablesMD.TableName = TableName;
                oUserTablesMD.TableDescription = TableDesc;
                if (TableType == "Master")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterData;
                }
                else if (TableType == "Child")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterDataLines;
                }
                else if (TableType == "Document")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_Document;
                }
                else if (TableType == "DocLine")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_DocumentLines;
                }
                else if (TableType == "Object")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_NoObject;
                }
                int err = oUserTablesMD.Add();
                string errMsg = "";
                oCompany.GetLastError(out err, out errMsg);
                if (err == 0)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                else
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create Table: " + TableName + " " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateUserObjectMASTER(string CodeID, string Name, string TableName, string Child, string Child1, string Child2, Boolean DefaultForm)
        {
            int lRetCode = 0;
            string sErrMsg = null;
            SAPbobsCOM.UserObjectsMD oUserObjectMD = null;
            if (oUserObjectMD == null)
                oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

            if (oUserObjectMD.GetByKey(CodeID) == true)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
                oUserObjectMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                return true;
            }

            oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.Code = CodeID;
            oUserObjectMD.Name = Name;

            oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.FindColumns.SetCurrentLine(0);
            oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_MasterData;
            oUserObjectMD.FindColumns.ColumnAlias = "Code";
            oUserObjectMD.FindColumns.ColumnDescription = "Code";
            oUserObjectMD.FindColumns.Add();
            //oUserObjectMD.FindColumns.SetCurrentLine(1);
            //oUserObjectMD.FindColumns.ColumnAlias = "DocNum";
            //oUserObjectMD.FindColumns.ColumnDescription = "Doc Num";
            //oUserObjectMD.FindColumns.Add();


            oUserObjectMD.TableName = TableName;

            if (Child != "")
            {
                oUserObjectMD.ChildTables.TableName = Child;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child1 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child1;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child2 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child2;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (DefaultForm == true)
            {
                oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            }

            lRetCode = oUserObjectMD.Add();

            // check for errors in the process
            if (lRetCode != 0)
                if (lRetCode == -1)
                { }
                else
                { oCompany.GetLastError(out lRetCode, out sErrMsg); }
            else
            { }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
            oUserObjectMD = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }

        private Boolean CreateUserObject(string CodeID, string Name, string TableName, string Child, string Child1, string Child2, Boolean DefaultForm)
        {
            int lRetCode = 0;
            string sErrMsg = null;
            SAPbobsCOM.UserObjectsMD oUserObjectMD = null;
            if (oUserObjectMD == null)
                oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

            if (oUserObjectMD.GetByKey(CodeID) == true)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
                oUserObjectMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                return true;
            }

            oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.Code = CodeID;
            oUserObjectMD.Name = Name;

            oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.FindColumns.SetCurrentLine(0);
            oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_Document;
            oUserObjectMD.FindColumns.ColumnAlias = "DocEntry";
            oUserObjectMD.FindColumns.ColumnDescription = "DocEntry";
            oUserObjectMD.FindColumns.Add();
            oUserObjectMD.FindColumns.SetCurrentLine(1);
            oUserObjectMD.FindColumns.ColumnAlias = "DocNum";
            oUserObjectMD.FindColumns.ColumnDescription = "Doc Num";
            oUserObjectMD.FindColumns.Add();


            oUserObjectMD.TableName = TableName;

            if (Child != "")
            {
                oUserObjectMD.ChildTables.TableName = Child;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child1 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child1;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child2 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child2;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (DefaultForm == true)
            {
                oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            }

            lRetCode = oUserObjectMD.Add();

            // check for errors in the process
            if (lRetCode != 0)
                if (lRetCode == -1)
                { }
                else
                { oCompany.GetLastError(out lRetCode, out sErrMsg); }
            else
            { }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
            oUserObjectMD = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }

        #endregion

        public void LoadXML(string XMLFile, string BrowseBy, string Title, string FormMode)
        {
            try
            {
                System.Xml.XmlDocument xmldoc = new System.Xml.XmlDocument();
                //string XMLLoadfullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Path.Combine("XMLFiles", XMLFile + ".xml"));

                string file = "Sales.XMLFiles." + XMLFile + ".xml";
                System.IO.Stream Streaming = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(file);
                System.IO.StreamReader StreamRead = new System.IO.StreamReader(Streaming, true);
                xmldoc.LoadXml(StreamRead.ReadToEnd());
                StreamRead.Close();
                Random r = new Random();
                r.Next(1000);

                if ((xmldoc.SelectSingleNode("//form") != null))
                {
                    xmldoc.SelectSingleNode("//form").Attributes.GetNamedItem("uid").Value =
                    xmldoc.SelectSingleNode("//form").Attributes.GetNamedItem("uid").Value.ToString() + "_" + r.Next().ToString();
                    string sXML = xmldoc.InnerXml.ToString();
                    oApplication.LoadBatchActions(ref sXML);

                    SAPbouiCOM.Form oForm = oApplication.Forms.ActiveForm;
                    if (Title != "")
                    {
                        oForm.Title = Title;
                    }
                    oForm.SupportedModes = -1;

                    oForm.EnableMenu("1281", true);
                    oForm.EnableMenu("1282", true);
                    oForm.EnableMenu("1288", true);
                    oForm.EnableMenu("1289", true);
                    oForm.EnableMenu("1290", true);
                    oForm.EnableMenu("1291", true);
                    oForm.EnableMenu("1292", true); //Activate Add row menu required for transactions
                    oForm.EnableMenu("1293", true); //Activate delete row menu required for transactions
                    oForm.EnableMenu("6913", false);
                    oForm.EnableMenu("4870", false); // Filter Table
                    oForm.EnableMenu("1283", false);//Remove
                    oForm.EnableMenu("1285", false); // Restore
                    if (BrowseBy != "")
                    {
                        oForm.DataBrowser.BrowseBy = BrowseBy;
                    }
                    if (FormMode == "A")
                    {
                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                    }
                    else if (FormMode == "U")
                    {
                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                    }
                    else if (FormMode == "F")
                    {
                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                    }
                    else if (FormMode == "O")
                    {
                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                    }
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }


        #region LoadFromXML
        public void LoadFromXML(string FileName, string BrowseBy, out string FormUID, string Title, string FormMode)
        {
            FormUID = "";
            try
            {

                System.Xml.XmlDocument oXmlDoc = null;
                string sPath = null;
                oXmlDoc = new System.Xml.XmlDocument();

                sPath = System.Windows.Forms.Application.StartupPath + "\\Forms\\" + FileName + ".srf";
                oXmlDoc.Load(sPath);

                string sXML = oXmlDoc.InnerXml.ToString();
                oApplication.LoadBatchActions(ref sXML);

                SAPbouiCOM.Form oForm = oApplication.Forms.ActiveForm;
                FormUID = oForm.UniqueID;
                if (Title != "")
                {
                    oForm.Title = Title;
                }
                oForm.SupportedModes = -1;

                oForm.EnableMenu("1281", true);
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);


                oForm.EnableMenu("1292", true); //Activate Add row menu required for transactions
                oForm.EnableMenu("1293", true); //Activate delete row menu required for transactions
                if (BrowseBy != "")
                {
                    oForm.DataBrowser.BrowseBy = BrowseBy;
                }
                if (FormMode == "A")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                }
                else
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                }

                //return (oXmlDoc.InnerXml);

            }
            catch
            {

            }

        }

        public string LoadFromXML(string FileName, string BrowseBy, string FormMode)
        {
            try
            {
                System.Xml.XmlDocument oXmlDoc = null;
                string sPath = null;
                oXmlDoc = new System.Xml.XmlDocument();
                sPath = System.Windows.Forms.Application.StartupPath + "\\Forms\\" + FileName + ".srf";
                oXmlDoc.Load(sPath);
                string sXML = oXmlDoc.InnerXml.ToString();
                oApplication.LoadBatchActions(ref sXML);
                SAPbouiCOM.Form oForm = oApplication.Forms.Item(FileName);
                oForm.SupportedModes = -1;
                oForm.EnableMenu("1281", true);
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);
                oForm.EnableMenu("1292", true); //Activate Add row menu required for transactions
                oForm.EnableMenu("1293", true); //Activate delete row menu required for transactions
                oForm.EnableMenu("6913", false);

                if (BrowseBy != "")
                {
                    oForm.DataBrowser.BrowseBy = BrowseBy;
                }
                if (FormMode == "A")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                }
                else if (FormMode == "F")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                }
                return (oXmlDoc.InnerXml);

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
            return "";
        }

        #endregion

        #region LoadDefaultForm
        public void LoadDefaultForm(string udoID)
        {
            SAPbouiCOM.MenuItem menu = oApplication.Menus.Item("47616"); // Link to the Default Forms menu
            try
            {
                if (menu.SubMenus.Count > 0)
                {
                    for (int i = 0; i <= menu.SubMenus.Count - 1; i++)
                    {
                        if (menu.SubMenus.Item(i).String.Contains(udoID))
                        {
                            menu.SubMenus.Item(i).Activate();
                        }

                    }

                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("ERROR: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Long, true);
            }

        }
        #endregion

        #region AddChooseFromList

        public void AddChooseFromList(SAPbouiCOM.Form oForm, string UniqueID, string CondVal)
        {
            try
            {

                SAPbouiCOM.ChooseFromListCollection oCFLs = null;

                oCFLs = oForm.ChooseFromLists;

                SAPbouiCOM.ChooseFromList oCFL = null;
                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));

                oCFLCreationParams.MultiSelection = false;
                oCFLCreationParams.ObjectType = CondVal;
                oCFLCreationParams.UniqueID = UniqueID;
                oCFL = oCFLs.Add(oCFLCreationParams);
            }
            catch
            {

            }
        }

        public void AddCondOnCFLCodeWise(SAPbouiCOM.Form frmRFQ, string objectid, string query, string Alias, string CondVal)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            SAPbouiCOM.Conditions oCons = null;
            SAPbouiCOM.Condition oCon = null;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                oCFL = frmRFQ.ChooseFromLists.Item(objectid);

                oRs = returnRecord(query);

                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();
                if (query == "")
                {
                    if (oCons.Count > 0) //'If there are already user conditions.
                    {
                        oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;
                    }
                    oCon = oCons.Add();
                    oCon.BracketOpenNum = 1;
                    oCon.Alias = Alias;
                    oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    oCon.CondVal = CondVal;
                    oCon.BracketCloseNum = 1;
                    oCFL.SetConditions(oCons);
                }
                else if (oRs.RecordCount == 0)
                {
                    oCon = oCons.Add();
                    oCon.Alias = Alias;
                    oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    oCon.CondVal = "1";
                    oCFL.SetConditions(oCons);
                }
                else
                {
                    while (!oRs.EoF)
                    {
                        if (oCons.Count > 0) //'If there are already user conditions.
                        {
                            oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                        }
                        oCon = oCons.Add();
                        oCon.Alias = Alias;
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = oRs.Fields.Item(0).Value.ToString();
                        oRs.MoveNext();
                        oCFL.SetConditions(oCons);
                    }
                }

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        public void AddChooseFromList_NoCond(SAPbouiCOM.Form oFormChoose, string cflID, string objectid)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            try
            {
                SAPbouiCOM.ChooseFromListCollection oCFLs = null;
                oCFLs = oFormChoose.ChooseFromLists;
                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));
                oCFLCreationParams.MultiSelection = true;
                oCFLCreationParams.ObjectType = objectid;
                oCFLCreationParams.UniqueID = cflID;
                oCFL = oCFLs.Add(oCFLCreationParams);
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        public void AddChooseFromList_WithCond(SAPbouiCOM.Form oForm, string cflID, string objectid, string query, string Alias, ArrayList alCond)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            SAPbouiCOM.Conditions oCons = null;
            SAPbouiCOM.Condition oCon = null;
            SAPbobsCOM.Recordset oRs = null;

            try
            {
                try
                {
                    SAPbouiCOM.ChooseFromListCollection oCFLs = null;
                    oCFLs = oForm.ChooseFromLists;
                    SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                    oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));
                    oCFLCreationParams.MultiSelection = false;
                    oCFLCreationParams.ObjectType = objectid;
                    oCFLCreationParams.UniqueID = cflID;
                    oCFL = oCFLs.Add(oCFLCreationParams);
                }
                catch
                {
                    oCFL = oForm.ChooseFromLists.Item(cflID);
                }
                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();



                #region Filter CFL values using ArrayList
                if (query == string.Empty)
                {
                    for (int i = 0; i < alCond.Count; i++)
                    {
                        if (oCons.Count > 0) //'If there are already user conditions.
                        {
                            oCons.Item(oCons.Count - 1).Relationship = (SAPbouiCOM.BoConditionRelationship)((alCond[i] as ArrayList)[0]);
                        }
                        oCon = oCons.Add();
                        oCon.BracketOpenNum = 1;
                        oCon.Alias = (alCond[i] as ArrayList)[1].ToString();
                        oCon.CondVal = (alCond[i] as ArrayList)[2].ToString();
                        oCon.Operation = (SAPbouiCOM.BoConditionOperation)((alCond[i] as ArrayList)[3]); //SAPbouiCOM.BoConditionOperation.co_EQUAL;                      
                        oCon.BracketCloseNum = 1;
                        oCFL.SetConditions(oCons);
                    }
                }
                #endregion

                #region Filter CFL values using recordset
                else
                {
                    oRs = returnRecord(query);
                    if (oRs.RecordCount == 0)
                    {
                        oCon = oCons.Add();
                        oCon.Alias = Alias;
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "0";
                        oCFL.SetConditions(oCons);
                    }
                    else
                    {
                        while (!oRs.EoF)
                        {
                            if (oCons.Count > 0) //'If there are already user conditions.
                            {
                                oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                            }
                            oCon = oCons.Add();
                            oCon.Alias = Alias;
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = oRs.Fields.Item(0).Value.ToString();
                            oRs.MoveNext();
                            oCFL.SetConditions(oCons);
                        }
                    }
                }
                #endregion


            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }


        #endregion

        #region AddRow And DeleteRow


        public void AddRow(SAPbouiCOM.Matrix oMatrix, SAPbouiCOM.DBDataSource oDbDataSource, string Value)
        {
            oMatrix.FlushToDataSource();
            if (oMatrix.VisualRowCount == 0)
                oMatrix.AddRow(1, oMatrix.RowCount);
            else
            {

                if (Value != string.Empty)
                {
                    oDbDataSource.InsertRecord(oMatrix.RowCount);
                    oMatrix.LoadFromDataSource();
                }
            }
        }


        #endregion

        #region Allocate Batch
        public void AllocateBatch_41(SAPbouiCOM.Form Base_Form, SAPbouiCOM.Form oForm, SAPbouiCOM.Matrix Base_Matrix, SAPbouiCOM.Matrix Batch_Matrix1, SAPbouiCOM.Matrix Batch_Matrix2)
        {
            try
            {
                SAPbouiCOM.Item oItem;
                SAPbouiCOM.EditText oEdit;
                string Base_ItemCode, Base_Batch, Batch_Managed, Batch_Matrix1_Item;
                int Batch_Row = 1;
                for (int i = 1; i < Base_Matrix.VisualRowCount; i++)
                {
                    oEdit = ((SAPbouiCOM.EditText)(Base_Matrix.GetCellSpecific("1", i)));
                    Base_ItemCode = oEdit.String;
                    oEdit = ((SAPbouiCOM.EditText)(Base_Matrix.GetCellSpecific("U_Batch", i)));
                    Base_Batch = oEdit.String;

                    Batch_Managed = SelectRecord("SELECT T2.[ManBtchNum] FROM  OITM T2  where  T2.Itemcode='" + Base_ItemCode + "'");
                    if (Batch_Managed == "Y")
                    {
                        for (; Batch_Row <= Batch_Matrix1.VisualRowCount;)
                        {
                            oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix1.GetCellSpecific("5", Batch_Row)));
                            Batch_Matrix1_Item = oEdit.String;
                            try
                            {
                                Batch_Matrix1.Columns.Item("5").Cells.Item(Batch_Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            }
                            catch { }
                            oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("2", 1)));
                            if (oEdit.String == "")
                            {
                                oEdit.String = Base_Batch;

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("7", 1))); //Batch Att 1
                                //try
                                //{
                                //    oEdit.String = Base_Att1;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("8", 1)));//Batch Att 2
                                //try
                                //{
                                //    oEdit.String = Base_Att2;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("10", 1)));//Exp Date
                                //try
                                //{
                                //    oEdit.String = Base_Exp_Date;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("11", 1)));//Manf Date
                                //try
                                //{
                                //    oEdit.String = Base_Man_Date;
                                //}
                                //catch { }

                                oItem = oForm.Items.Item("1");
                                oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                if (Batch_Row == Batch_Matrix1.VisualRowCount)
                                {
                                    oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    oItem = Base_Form.Items.Item("1");
                                    oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                Batch_Row++;
                                break;
                            }
                            else
                            {
                                Batch_Row++;
                                break;
                            }
                        }
                    }
                }
            }
            catch
            {

            }
        }
        #endregion

        #region Select Records
        public string SelectRecord(string Querry)
        {
            string value = string.Empty;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRs.DoQuery(Querry);

                if (oRs.EoF == false)
                {
                    value = oRs.Fields.Item(0).Value.ToString();
                }
                return value;
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return value;
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public SAPbobsCOM.Recordset returnRecord(string Query)
        {
            SAPbobsCOM.Recordset oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
            try
            {
                oRs.DoQuery(Query);
                return oRs;
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return null;
            }
        }
        #endregion

        #region FillCombo
        public void FillCombo(SAPbouiCOM.ComboBox oCombo, string query)
        {
            SAPbobsCOM.Recordset oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
            try
            {
                try
                {
                    oCombo.ValidValues.Remove("", SAPbouiCOM.BoSearchKey.psk_ByValue);
                }
                catch
                {

                }
                int Count = oCombo.ValidValues.Count;
                for (int i = 0; i < Count; i++)
                {
                    try
                    {
                        oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                    }
                    catch { }
                }
                oRs.DoQuery(query);

                //if (iType != 5)
                //{
                oCombo.ValidValues.Add("", "");
                // }
                if (!oRs.EoF)
                {
                    for (int i = 0; i < oRs.RecordCount; i++)
                    {
                        if (oRs.Fields.Item(1).Value.ToString().Length <= 5)
                        {
                            // ADD SPACE TO AVOID VALIDATION ERROR 
                            oCombo.ValidValues.Add(oRs.Fields.Item(0).Value.ToString(), "    " + oRs.Fields.Item(1).Value.ToString());
                            // oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");

                        }
                        else if (oRs.Fields.Item(1).Value.ToString().Length > 50)
                        {
                            // REMOVE EXCESS CHARACTER TO AVOID VALIDATION ERROR
                            oCombo.ValidValues.Add(oRs.Fields.Item(0).Value.ToString(), oRs.Fields.Item(1).Value.ToString().Substring(0, 49));
                            //oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");
                        }
                        else
                        {
                            //oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");
                            oCombo.ValidValues.Add(oRs.Fields.Item(0).Value.ToString(), oRs.Fields.Item(1).Value.ToString());

                        }
                        oRs.MoveNext();
                    }
                }
            }

            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }
        #endregion

        #region Bind_Radio  & Checkbox

        public void Bind_Radio(SAPbouiCOM.Form oForm, int NoOfRButton)
        {
            SAPbouiCOM.OptionBtn opt;
            SAPbouiCOM.UserDataSource oUserdatasource;
            SAPbouiCOM.Item oItem;

            try
            {
                if (NoOfRButton == 2)
                {
                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");


                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 3)
                {
                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 4)
                {
                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 5)
                {
                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");
                    opt.Selected = true;
                }



                else if (NoOfRButton == 6)
                {
                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt6");

                    //oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    //opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");
                    opt.Selected = true;
                }

                else if (NoOfRButton == 7)
                {
                    oItem = oForm.Items.Item("opt7");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt7");

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt6");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 23)
                {
                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 22)
                {
                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 232)
                {
                    oItem = oForm.Items.Item("opt7");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD3", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD3");

                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt7");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
            }
            catch
            { }

        }

        public void Bind_CheckBox(SAPbouiCOM.Form oForm, string ItemUID)
        {
            SAPbouiCOM.UserDataSource oUserdatasource;
            SAPbouiCOM.Item oItem;
            try
            {
                oItem = oForm.Items.Item(ItemUID);
                SAPbouiCOM.CheckBox chk = (SAPbouiCOM.CheckBox)(oItem.Specific);

                oUserdatasource = oForm.DataSources.UserDataSources.Add("CHK", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 1);
                chk.DataBind.SetBound(true, "", "CHK");
            }
            catch
            { }

        }

        #endregion

        #region Return Proper Date Format

        public string GetDateFormat(string sDate)
        {
            try
            {
                string sDateFormat = sDate.Substring(0, 4) + "/" + sDate.Substring(4, 2) + "/" + sDate.Substring(6, 2);
                return sDateFormat;
            }
            catch { return ""; }
        }

        #endregion

        #region GetDefaultSeries

        public int GetDefaultSeries(string ObjectType)
        {
            SAPbobsCOM.CompanyService oCmpSrv = null;
            SAPbobsCOM.SeriesService oSeriesService = null;
            SAPbobsCOM.DocumentTypeParams oDocumentTypeParams = null;
            SAPbobsCOM.Series oSeries = null;

            //'get company service
            oCmpSrv = (SAPbobsCOM.CompanyService)oCompany.GetCompanyService();
            //'get series service
            oSeriesService = (SAPbobsCOM.SeriesService)oCmpSrv.GetBusinessService(SAPbobsCOM.ServiceTypes.SeriesService);
            //'get new series
            oSeries = (SAPbobsCOM.Series)oSeriesService.GetDataInterface(SAPbobsCOM.SeriesServiceDataInterfaces.ssdiSeries);
            //'get DocumentTypeParams for filling the document type
            oDocumentTypeParams = (SAPbobsCOM.DocumentTypeParams)oSeriesService.GetDataInterface(SAPbobsCOM.SeriesServiceDataInterfaces.ssdiDocumentTypeParams);
            //'set the document type (e.g. A/R Invoice=13)
            oDocumentTypeParams.Document = ObjectType;
            //'get the default series of the SaleOrder documentset the document type
            oSeries = oSeriesService.GetDefaultSeries(oDocumentTypeParams);
            return oSeries.Series;
        }

        #endregion

        #region GoodsIssue_Production

        public void GoodsIssue_PO_Datatable(System.Data.DataTable dt, out string GRDocEntry, string PODocEntry, string WODocEntry)
        {
            //Goods Issue object. 60        
            int lretcode;
            string ItemCode, WhsCode;
            double Quantity;

            SAPbobsCOM.Documents IssueToProd = null;
            IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit));

            IssueToProd.DocDate = DateTime.Now;
            string BaseDoc = SelectRecord("SELECT DOCNUM FROM OWOR WHERE DOCENTRY=" + PODocEntry + "");
            IssueToProd.JournalMemo = "Issue for Production " + BaseDoc;
            IssueToProd.Comments = "Issue for Production " + BaseDoc;
            //oRsGI = returnReocord("SELECT T0.ItemCode,WareHouse,T0.DocEntry,PlannedQty [Quantity],LineNum FROM WOR1 T0 " +
            //                        "INNER JOIN OITM T1 ON T0.ItemCode=T1.ItemCode " +
            //                        "WHERE T0.DocEntry=" + BaseDoc + " AND T1.IssueMthd='M' ");
            //oRsGI = returnReocord("SELECT ItemCode,WareHouse,DocEntry,PlannedQty [Quantity],LineNum FROM WOR1 WHERE DocEntry=" + BaseDoc + " ");

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IssueToProd.Lines.SetCurrentLine(i);
                ItemCode = dt.Rows[i]["Itemcode"].ToString();
                WhsCode = dt.Rows[i]["WareHouse"].ToString();
                Quantity = double.Parse(dt.Rows[i]["Quantity"].ToString());

                IssueToProd.Lines.BaseType = 202;
                IssueToProd.Lines.BaseEntry = int.Parse(PODocEntry);
                IssueToProd.Lines.BaseLine = i;
                IssueToProd.Lines.Quantity = Quantity;
                IssueToProd.Lines.WarehouseCode = WhsCode;

                IssueToProd.Lines.BatchNumbers.SetCurrentLine(0);
                IssueToProd.Lines.BatchNumbers.BatchNumber = dt.Rows[i]["Batch"].ToString();
                IssueToProd.Lines.BatchNumbers.Quantity = Quantity;
                IssueToProd.Lines.BatchNumbers.Add();
                IssueToProd.Lines.Add();
            }

            lretcode = IssueToProd.Add();

            if (lretcode != 0)
            {
                int Errcode; string ErrMsg;
                oCompany.GetLastError(out Errcode, out ErrMsg);
                oApplication.MessageBox("Issue for Production : " + ErrMsg, 1, "OK", "", "");
                oApplication.StatusBar.SetText("Issue for Production : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = "";
            }
            else
            {
                oApplication.StatusBar.SetText("Issue for Production created successfully.....!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = oCompany.GetNewObjectKey();
            }

        }

        #endregion

        #region GetPeriod
        public void GetPeriod()
        {
            try
            {
                SAPbouiCOM.Company company = oApplication.Company;
                int Period = company.CurrentPeriod;
                SAPbobsCOM.CompanyService oCompanyService = oCompany.GetCompanyService();
                SAPbobsCOM.FinancePeriodParams diPeriodParams = (SAPbobsCOM.FinancePeriodParams)oCompanyService.GetDataInterface(SAPbobsCOM.CompanyServiceDataInterfaces.csdiFinancePeriodParams);

                diPeriodParams.AbsoluteEntry = Period;
                SAPbobsCOM.FinancePeriod finPeriod = oCompanyService.GetFinancePeriod(diPeriodParams);

            }
            catch { }
        }
        #endregion

        #region Remove_UDF
        public void Remove_UDF(string sTableID, string sFieldName)
        {
            SAPbobsCOM.UserFieldsMD oUserFieldsMD = (SAPbobsCOM.UserFieldsMD)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);
            try
            {
                int iFieldID = GetFieldID(sTableID, sFieldName);
                if (oUserFieldsMD.GetByKey(sTableID, iFieldID))
                {
                    if (oUserFieldsMD.Remove() != 0) oApplication.SetStatusBarMessage("Error removing UDF: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, true);
                }
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldsMD);
                oUserFieldsMD = null;
                GC.Collect();
            }
        }

        private int GetFieldID(string sTableID, string sAliasID)
        {
            int iRetVal = 0;
            SAPbobsCOM.Recordset oRs = (SAPbobsCOM.Recordset)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            try
            {
                oRs.DoQuery("select FieldID from CUFD where TableID = '" + sTableID + "' and AliasID = '" + sAliasID + "'");
                if (!oRs.EoF) iRetVal = Convert.ToInt32(oRs.Fields.Item("FieldID").Value.ToString());
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                oRs = null;
                GC.Collect();
            }
            return iRetVal;
        }
        #endregion

        #region SetAutoManagedAttribute

        public void SetAutoManagedAttribute_AddMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, -1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute_UpdateMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_False);

        }

        #endregion

        #region ConvertStrToDate
        public DateTime ConvertStrToDate(string strDate, string strFormat)
        {
            DateTime oDate = default(DateTime);
            try
            {

                System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo("en-GB", false);
                System.Globalization.CultureInfo newCi = (System.Globalization.CultureInfo)ci.Clone();

                System.Threading.Thread.CurrentThread.CurrentCulture = newCi;
                oDate = DateTime.ParseExact(strDate, strFormat, ci.DateTimeFormat);


            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, true);
            }
            finally
            {

            }
            return oDate;

        }
        #endregion

        #region DBConnection

        public SqlConnection DBConnection()
        {
            SqlConnection conn = null;

            SAPbobsCOM.Recordset oRs = null;
            string QueryString = null;
            //--
            try
            {
                //SetConnection
                QueryString = "SELECT U_DBPwd FROM [@TIS_DATABASE]";
                oRs= ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRs.DoQuery(QueryString);

                if (!oRs.EoF)
                {
                    clsVariables.DbPass = oRs.Fields.Item("U_DBPwd").Value.ToString();
                }
                else
                    oApplication.MessageBox("Database Connection details missing in user defined table!", 1, "OK", "", "");
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            try
            {
                clsVariables.Server = oCompany.Server;
                clsVariables.DbName = oCompany.CompanyDB;
                clsVariables.DbUser = oCompany.DbUserName;


                string strConn = "SERVER='" + oCompany.Server + "';DATABASE='" + oCompany.CompanyDB + "';USER ID='" + oCompany.DbUserName + "';Password='" + clsVariables.DbPass + "'";
                conn = new SqlConnection(strConn);
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return null;
            }
            return conn;
        }

        #endregion


        #region Form_Duplicate

        public void Form_Duplicate(SAPbouiCOM.Form oForm, string Code)
        {
            SAPbobsCOM.UserObjectsMD udo = (SAPbobsCOM.UserObjectsMD)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD);
            string value = string.Empty;
            if (udo.GetByKey(oForm.BusinessObject.Type) == true)
            {
                string[] str_tables = new string[udo.ChildTables.Count + 1];
                str_tables[0] = "@" + udo.TableName;

                for (int iPos = 0, tableCount = udo.ChildTables.Count; iPos < tableCount; iPos++)
                {
                    udo.ChildTables.SetCurrentLine(iPos);
                    value = "@" + udo.ChildTables.TableName;
                    str_tables[iPos + 1] = "@" + udo.ChildTables.TableName;
                }

                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(udo);
                udo = null;

                SAPbouiCOM.DBDataSources dbSources = oForm.DataSources.DBDataSources;
                foreach (SAPbouiCOM.DBDataSource datasource in dbSources)
                {
                    for (int i = 0; i < str_tables.Length; i++)
                    {
                        if (str_tables[i].Contains(datasource.TableName))
                        {
                            for (int iPos = 0, recordCount = datasource.Size; iPos < recordCount; iPos++)
                            {
                                datasource.SetValue("Code", iPos, Code);
                            }
                            break;
                        }
                    }
                }

                foreach (SAPbouiCOM.Item oItem in oForm.Items)
                {
                    if (SAPbouiCOM.BoFormItemTypes.it_MATRIX == oItem.Type)
                    {
                        SAPbouiCOM.Matrix oMatrix = (SAPbouiCOM.Matrix)oItem.Specific;
                        oMatrix.LoadFromDataSourceEx(true);
                    }
                }
            }
        }

        #endregion

        #region ModifyForm

        public void ModifyForm(SAPbouiCOM.Form oForm)
        {

            try
            {
                SAPbouiCOM.Item oItem;
                SAPbouiCOM.Item xItem;
                SAPbouiCOM.Button oButton;

                #region Pick List
                if (oForm.TypeEx == "85")
                {
                    xItem = oForm.Items.Item("4");
                    oItem = oForm.Items.Add("btnFill", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                    oItem.Left = xItem.Left + xItem.Width + 2;
                    oItem.Top = xItem.Top;

                    oItem.Width = oItem.Width + oItem.Width;
                    oItem.Height = xItem.Height;

                    oButton = (SAPbouiCOM.Button)(oItem.Specific);
                    oButton.Caption = "Fill Rate";
                    //oItem.Width = 60;

                }
                #endregion


            }
            catch (Exception e)
            {
                oApplication.StatusBar.SetText(e.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion


        #region FillCombo_Series_Custom

        public void FillCombo_Series_Custom(SAPbouiCOM.Form oForm, string SeriesUDF, string Mode)
        {
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                string ObjectCode = oForm.DataSources.DBDataSources.Item(0).TableName.Replace("@", string.Empty);

                if (Mode == "Load")
                {
                    string DOCDATE = ((SAPbouiCOM.EditText)oForm.Items.Item(SeriesUDF).Specific).Value;
                    StringBuilder sbQuery = new StringBuilder();

                    sbQuery.Append(" SELECT T0.SERIES, T0.SERIESNAME  FROM NNM1 T0  ");
                    sbQuery.Append(" INNER JOIN OFPR T1 ON T0.INDICATOR = T1.INDICATOR  ");
                    sbQuery.Append(" WHERE OBJECTCODE='" + ObjectCode + "'  AND     LOCKED = 'N'  ");
                    sbQuery.Append(" AND F_REFDATE <='" + DOCDATE + "'  AND T_REFDATE >= '" + DOCDATE + "'  ");
                    sbQuery.Append(" GROUP BY T0.SERIES, T0.SERIESNAME  ");


                    int Count = oCombo.ValidValues.Count;
                    for (int i = 0; i < Count; i++)
                    {
                        try
                        {
                            oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                        }
                        catch { }
                    }
                    oRs = returnRecord(sbQuery.ToString());
                    while (!oRs.EoF)
                    {
                        try
                        {
                            oCombo.ValidValues.Add(oRs.Fields.Item("SERIES").Value.ToString(), oRs.Fields.Item("SERIESNAME").Value.ToString());
                        }
                        catch { }
                        oRs.MoveNext();
                    }

                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

                }
                else
                {
                    oCombo.ValidValues.LoadSeries(ObjectCode, SAPbouiCOM.BoSeriesMode.sf_View);

                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion


        #region ReportService

        public void ReportService()
        {
            SAPbobsCOM.ReportTypesService rptTypeService = (SAPbobsCOM.ReportTypesService)oCompany.GetCompanyService().GetBusinessService(SAPbobsCOM.ServiceTypes.ReportTypesService);
            SAPbobsCOM.ReportType newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Delivery Order";  //Name of SubMenu
            newType.MenuID = "DEL_ORDER";
            string AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }

            newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Dispatch Planning";  //Name of SubMenu
            newType.MenuID = "DISP_PLAN";
            AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }


            newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Stuffing";  //Name of SubMenu
            newType.MenuID = "STUFF";
            AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }
        }

        #endregion

        #region DisPatch Planning

        public void DisPatchPlanning_Insert(string DocEntry)
        {
            SAPbobsCOM.Recordset oRs = null;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT DISTINCT U_DispNo FROM [@DISP_PLAN_UPLOAD1] ");
            sbQuery.Append(" WHERE DOCENTRY='" + DocEntry + "' ");
            SAPbobsCOM.Recordset oRs_DispNo = returnRecord(sbQuery.ToString());
            try
            {
                string DispNo = string.Empty;

                while (!oRs_DispNo.EoF)
                {
                    DispNo = oRs_DispNo.Fields.Item("U_DispNo").Value.ToString();

                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.U_BPLId,T4.SERIES [DISP_SER],T1.U_CardCode,T1.U_CardName,T3.CNTCTCODE,T3.NUMATCARD,T3.U_PRTOFDSHG  ");
                    sbQuery.Append(" ,T1.U_Total,T1.U_OthChg,T1.U_GTotal,T1.U_TotCrat ,T1.U_TotNwt, T1.U_TotGrWt,T1.U_Remarks");
                    sbQuery.Append(" ,T1.U_ItemCode,T1.U_ItemName, T1.U_Marking,T1.U_Quantity ,T1.U_Rate,T1.U_NoPack,T1.U_Netwt,T1.U_GrsWt");
                    sbQuery.Append(" ,T1.U_NoCrat,T1.U_PCCrate,T1.U_WtPack,T1.U_StWt ,T1.U_Amount,T1.U_BaseRef, T1.U_BaseKey");
                    sbQuery.Append(",T1.U_BaseLine,T1.U_WhsCode, T1.U_Combine,T1.U_SkipRow,T1.U_OnHand,T1.U_DispNo,T1.U_DispDate");

                    sbQuery.Append(" FROM [@DISP_PLAN_UPLOAD] T0 ");
                    sbQuery.Append(" INNER JOIN [@DISP_PLAN_UPLOAD1] T1 ON T0.DOCENTRY=T1.DOCENTRY");
                    sbQuery.Append(" INNER JOIN RDR1 T2 ON T1.U_BASEKEY=T2.DOCENTRY AND T1.U_BASELINE=T2.LINENUM");
                    sbQuery.Append(" INNER JOIN ORDR T3 ON T2.DOCENTRY=T3.DOCENTRY");
                    sbQuery.Append(" INNER JOIN NNM1 T4 ON T1.U_DispSer=T4.SERIESNAME AND T4.OBJECTCODE='DISP_PLAN'");
                    sbQuery.Append(" WHERE T0.DOCENTRY='" + DocEntry + "' AND T1.U_DispNo='" + DispNo + "'");
                    sbQuery.Append(" AND ISNULL(T1.U_TrEn,'') = '' ");

                    #region Adding Record in UDO
                    try
                    {

                        oRs = returnRecord(sbQuery.ToString());
                        if (oRs.RecordCount == 0)
                        {
                            oApplication.StatusBar.SetText("DispatchPlanning_Insert: No Data found", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            oApplication.StatusBar.SetText(sbQuery.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            return;
                        }

                        SAPbobsCOM.GeneralService oGeneralService;
                        SAPbobsCOM.GeneralData oGeneralData;

                        SAPbobsCOM.GeneralData oChild;
                        SAPbobsCOM.GeneralDataCollection oChildren;
                        SAPbobsCOM.GeneralDataParams oGeneralParams;

                        SAPbobsCOM.CompanyService oCompService;
                        oCompService = oCompany.GetCompanyService();
                        oGeneralService = oCompService.GetGeneralService("DISP_PLAN");
                        oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
                        oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                        string soDocEntry = "";
                        string SoLineId = "";

                        oGeneralData.SetProperty("Series", oRs.Fields.Item("DISP_SER").Value);
                        oGeneralData.SetProperty("U_CardCode", oRs.Fields.Item("U_CardCode").Value);
                        oGeneralData.SetProperty("U_CardName", oRs.Fields.Item("U_CardName").Value);
                        oGeneralData.SetProperty("U_CntCode", oRs.Fields.Item("CNTCTCODE").Value.ToString());
                        oGeneralData.SetProperty("U_NumAtCar", oRs.Fields.Item("NUMATCARD").Value);
                        oGeneralData.SetProperty("U_BPLId", oRs.Fields.Item("U_BPLId").Value);

                        try
                        {
                            oGeneralData.SetProperty("U_DocDate", DateTime.Parse(oRs.Fields.Item("U_DispDate").Value.ToString()));
                        }
                        catch { }
                        oGeneralData.SetProperty("U_Port", oRs.Fields.Item("U_PRTOFDSHG").Value);
                        oGeneralData.SetProperty("U_Total", oRs.Fields.Item("U_Total").Value);
                        oGeneralData.SetProperty("U_OthChg", oRs.Fields.Item("U_OthChg").Value);
                        oGeneralData.SetProperty("U_GTotal", oRs.Fields.Item("U_GTotal").Value);
                        oGeneralData.SetProperty("U_TotCrat", oRs.Fields.Item("U_TotCrat").Value);
                        oGeneralData.SetProperty("U_TotNwt", oRs.Fields.Item("U_TotNwt").Value);
                        oGeneralData.SetProperty("U_TotGrWt", oRs.Fields.Item("U_TotGrWt").Value);
                        oGeneralData.SetProperty("U_Remarks", oRs.Fields.Item("U_Remarks").Value);
                        oGeneralData.SetProperty("U_UPDispNo", oRs.Fields.Item("U_DispNo").Value);

                        // Adding data to Detail Line

                        oChildren = oGeneralData.Child("DISP_PLAN1");
                        while (!oRs.EoF)
                        {
                            oChild = oChildren.Add();
                            oChild.SetProperty("U_ItemCode", oRs.Fields.Item("U_ItemCode").Value);
                            oChild.SetProperty("U_ItemName", oRs.Fields.Item("U_ItemName").Value);
                            oChild.SetProperty("U_Marking", oRs.Fields.Item("U_Marking").Value);
                            oChild.SetProperty("U_Quantity", oRs.Fields.Item("U_Quantity").Value);
                            oChild.SetProperty("U_OpenQty", oRs.Fields.Item("U_Quantity").Value);
                            oChild.SetProperty("U_BCOQty", oRs.Fields.Item("U_Quantity").Value);

                            oChild.SetProperty("U_OnHand", oRs.Fields.Item("U_OnHand").Value);
                            oChild.SetProperty("U_Rate", oRs.Fields.Item("U_Rate").Value);
                            oChild.SetProperty("U_NoPack", oRs.Fields.Item("U_NoPack").Value);
                            oChild.SetProperty("U_Netwt", oRs.Fields.Item("U_Netwt").Value);
                            oChild.SetProperty("U_GrsWt", oRs.Fields.Item("U_GrsWt").Value);
                            oChild.SetProperty("U_NoCrat", oRs.Fields.Item("U_NoCrat").Value);
                            oChild.SetProperty("U_PCCrate", oRs.Fields.Item("U_PCCrate").Value);
                            oChild.SetProperty("U_WtPack", oRs.Fields.Item("U_WtPack").Value);
                            oChild.SetProperty("U_StWt", oRs.Fields.Item("U_StWt").Value);
                            oChild.SetProperty("U_Amount", oRs.Fields.Item("U_Amount").Value);
                            oChild.SetProperty("U_BaseRef", oRs.Fields.Item("U_BaseRef").Value);
                            oChild.SetProperty("U_BaseKey", oRs.Fields.Item("U_BaseKey").Value);
                            oChild.SetProperty("U_BaseLine", oRs.Fields.Item("U_BaseLine").Value);
                            oChild.SetProperty("U_BaseType", "17");
                            oChild.SetProperty("U_WhsCode", oRs.Fields.Item("U_WhsCode").Value);
                            oChild.SetProperty("U_Combine", oRs.Fields.Item("U_Combine").Value);
                            oChild.SetProperty("U_SkipRow", oRs.Fields.Item("U_SkipRow").Value);
                            oChild.SetProperty("U_NumAtCar", oRs.Fields.Item("NUMATCARD").Value);
                            oRs.MoveNext();
                        }

                        oGeneralParams = oGeneralService.Add(oGeneralData);
                        string NewDocEntry = oGeneralParams.GetProperty("DocEntry").ToString();

                        if (NewDocEntry != string.Empty)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_TrEn=T1.DOCENTRY,T0.U_TrLine=T1.LINEID ");
                            sbQuery.Append(" FROM [@DISP_PLAN_UPLOAD1] T0 ");
                            sbQuery.Append(" INNER JOIN [@DISP_PLAN1] T1 ON T0.U_BASEKEY=T1.U_BASEKEY AND T0.U_BASELINE=T1.U_BASELINE ");
                            sbQuery.Append("  WHERE T0.DOCENTRY='" + DocEntry + "' AND T0.U_DispNo='" + DispNo + "'");
                            SelectRecord(sbQuery.ToString());

                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_DispQty= ISNULL(T0.U_DispQty,0) + ISNULL(T1.U_Quantity,0)    ");
                            sbQuery.Append(" FROM RDR1 T0 ");
                            sbQuery.Append(" INNER JOIN [@DISP_PLAN_UPLOAD1] T1 ON T1.DocEntry =T1.U_BASEKEY AND T0.LineNum =T1.U_BASELINE ");
                            sbQuery.Append("  WHERE T1.DOCENTRY='" + DocEntry + "' AND T1.U_DispNo='" + DispNo + "' ");
                            SelectRecord(sbQuery.ToString());
                        }

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        //oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription(),SAPbouiCOM.BoMessageTime.bmt_Short,SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    #endregion

                    oRs_DispNo.MoveNext();
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs_DispNo);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }


        }

        #endregion

        public void ReleaseObject(Object obj)
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        #endregion
    }
}

