using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Sales
{
    class clsSO : Connection
    {
        #region Variables

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1" && (pVal.FormMode == 2 || pVal.FormMode == 3))
                            {
                                Calc(FormUID);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Sales Order Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            try
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string TableName = string.Empty;
                                SAPbouiCOM.Button oButton;
                                SAPbouiCOM.Item oNewItem;
                                SAPbouiCOM.Item oItem;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                                TableName = "ORDR";


                                oNewItem = oForm.Items.Add("btnCalc", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                                oItem = oForm.Items.Item("2");
                                oNewItem.Top = oItem.Top;
                                oNewItem.Left = oItem.Left + oItem.Width;
                                oNewItem.Width = oItem.Width;
                                oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                                oButton.Caption = "Calculate";


                                oNewItem = oForm.Items.Add("lbl", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("30");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                SAPbouiCOM.StaticText oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStatic.Caption = "Total Net Weight";

                                oNewItem = oForm.Items.Add("TotNwt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("29");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Enabled = false;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, TableName, "U_TotNwt");


                                oNewItem = oForm.Items.Add("lbl1", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lbl");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStatic.Caption = "Total Gross Weight";

                                oNewItem = oForm.Items.Add("TotGrWt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("TotNwt");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Enabled = false;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, TableName, "U_TotGrWt");

                                oNewItem = oForm.Items.Add("lbl2", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                                oItem = oForm.Items.Item("lbl1");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                                oStatic.Caption = "Total Crates";

                                oNewItem = oForm.Items.Add("TotCrat", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                                oItem = oForm.Items.Item("TotGrWt");
                                oNewItem.Top = oItem.Top + 15;
                                oNewItem.Left = oItem.Left;
                                oNewItem.Width = oItem.Width;
                                oNewItem.Enabled = false;
                                oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                                oEdit.DataBind.SetBound(true, TableName, "U_TotCrat");
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText("Sales Order Item Event F_et_Form_Load : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }


                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            try
                            {
                                if (pVal.ItemUID == "btnCalc")
                                {
                                    Calc(FormUID);
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText("Sales Order Item Event F_et_ItemPressed : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged==true
                        if (pVal.ItemChanged == true)
                        {
                            try
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.ColUID == "U_NETWT")
                                {
                                    Calc(FormUID);
                                    //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                    //double NetWt = 0;
                                    //double TotalNetWt = 0;
                                    //double NoCrate = 0;


                                    //for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                    //{
                                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    //    NetWt = double.Parse(oEdit.String);
                                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    //    NoCrate = double.Parse(oEdit.String);
                                    //    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                    //}
                                    //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                    //oEdit.String = TotalNetWt.ToString();
                                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                                }
                                if (pVal.ColUID == "U_GRSWT")
                                {
                                    Calc(FormUID);
                                    //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                    //double NetWt = 0;
                                    //double TotalNetWt = 0;
                                    //double NoCrate = 0;

                                    //for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                    //{
                                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    //    NetWt = double.Parse(oEdit.String);
                                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    //    NoCrate = double.Parse(oEdit.String);
                                    //    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                    //}
                                    //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                    //oEdit.String = TotalNetWt.ToString();
                                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                                }
                                if (pVal.ColUID == "13")
                                {
                                    Calc(FormUID);
                                    //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                    //double NetWt = 0;
                                    //double TotalNetWt = 0;

                                    //for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                    //{
                                    //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    //    NetWt = double.Parse(oEdit.String);
                                    //    TotalNetWt = TotalNetWt + NetWt;
                                    //}
                                    //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                    //oEdit.String = TotalNetWt.ToString();
                                    //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText("Sales Order Item Event F_ItemChanged=false : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Sales Order Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Sales Order Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {


                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Methods

        #region Calc

        private void Calc(string FormUID)
        {
            try
            {
                oApplication.StatusBar.SetText("Calculating data.... ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

                oForm = oApplication.Forms.Item(FormUID);
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                double NetWt = 0;
                double GrsWt = 0;
                double NoCrate = 0;
                double STWeight = 0;
                double Quantity = 0;

                double CRTWeight = 0;
                double TotalNoCrate = 0;
                double TotalGrsWt = 0;
                double TotalNetWt = 0;

                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i)).String);
                    TotalNoCrate = TotalNoCrate + NoCrate;

                    STWeight = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_STWT", i)).String);
                    Quantity = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).String);
                    CRTWeight = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TOTCRTWT", i)).String);


                    NetWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);
                    NetWt = STWeight * Quantity;
                    //TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                    TotalNetWt = TotalNetWt + NetWt;

                    GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String);
                    //TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);
                    TotalGrsWt = TotalGrsWt + (NetWt + CRTWeight);




                }
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                oEdit.String = TotalNoCrate.ToString();

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                oEdit.String = TotalNetWt.ToString();

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                oEdit.String = TotalGrsWt.ToString();
                oApplication.StatusBar.SetText("Done.... ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calc: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }

        }

        #endregion

        #endregion


    }
}
