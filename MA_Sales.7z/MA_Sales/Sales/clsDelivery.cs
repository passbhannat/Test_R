using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace Sales
{
    class clsDelivery : Connection
    {
        #region Variables
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        SAPbobsCOM.Recordset oRs;
        SAPbouiCOM.DataTable oDataTable = null;
        bool boolStuffSelected = false;
        ArrayList alSelectedDoc = null;
        SAPbouiCOM.Column oColumn;

        const string branchUDF = "BPLId";

        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            clsVariables.BaseForm = oApplication.Forms.Item(pVal.FormUID);
                        }
                        #endregion

                        #region T_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btnStuff")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).Trim();
                                if (CardCode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please Select the customer code.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    BubbleEvent = false;
                                    return;
                                }
                                string Port = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PRTOFDSHG", 0).Trim();
                                if (Port == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please Select the port of discharge.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    BubbleEvent = false;
                                    return;
                                }
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            #region btnStuff
                            if (pVal.ItemUID == "btnStuff")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string CardCode = string.Empty;
                                CardCode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).ToString();
                                string Port = oForm.DataSources.DBDataSources.Item(0).GetValue("U_PRTOFDSHG", 0).ToString();
                                string branch = oForm.DataSources.DBDataSources.Item(0).GetValue(branchUDF, 0).ToString();

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_CardCode"); //Condition Alias             
                                temp.Add(CardCode); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("Status"); //Condition Alias             
                                temp.Add("O"); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_PORT"); //Condition Alias             
                                temp.Add(Port); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);


                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add("U_Approved"); //Condition Alias             
                                temp.Add("Y"); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);

                                if (branch != string.Empty)
                                {
                                    temp = new ArrayList();
                                    temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    temp.Add("U_BPLId"); //Condition Alias             
                                    temp.Add(branch); //Condition Value
                                    temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    alCondVal.Add(temp);
                                }

                                objclsComman.AddChooseFromList_WithCond(oForm, "CFL_STUFF", "STUFF", "", "", alCondVal);
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Delivery Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            clsVariables.BaseForm = oApplication.Forms.Item(pVal.FormUID);

                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.Button oButton;
                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                            oNewItem = oForm.Items.Add("btnCalc", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            oNewItem.Top = oItem.Top;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.Width = oItem.Width;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Calculate";

                            objclsComman.AddChooseFromList_NoCond(oForm, "CFL_STUFF", "STUFF");
                            oNewItem = oForm.Items.Add("btnStuff", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("btnCalc");
                            oNewItem.Top = oItem.Top;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.Width = oItem.Width * 2;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.ChooseFromListUID = "CFL_STUFF";
                            oButton.Caption = "Copy From Stuffing";


                            oNewItem = oForm.Items.Add("lbl", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("30");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.StaticText oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Net Weight";

                            oNewItem = oForm.Items.Add("TotNwt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("29");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, "ODLN", "U_TotNwt");


                            oNewItem = oForm.Items.Add("lbl1", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("lbl");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Gross Weight";

                            oNewItem = oForm.Items.Add("TotGrWt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("TotNwt");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, "ODLN", "U_TotGrWt");

                            oNewItem = oForm.Items.Add("lbl2", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("lbl1");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Crates";

                            oNewItem = oForm.Items.Add("TotCrat", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("TotGrWt");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, "ODLN", "U_TotCrat");

                            try
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                oColumn = oMatrix.Columns.Item("U_BaseLine");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_BaseType");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_SODocEn");
                                oColumn.Editable = false;
                                oColumn = oMatrix.Columns.Item("U_SOLine");
                                oColumn.Editable = false;
                            }
                            catch { }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region pVal.ItemUID == "btnCalc"
                            if (pVal.ItemUID == "btnCalc")
                            {


                                Calc_Gross(oForm);

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double GrsWt = 0;

                                double TotalNoCrat = 0;
                                double NoCrate = 0;
                                double TotalGrsWt = 0;
                                double TotalNetWt = 0;
                                string Combine = string.Empty;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        oApplication.StatusBar.SetText("Calculating ..." + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                                        NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i)).String);
                                        Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String.Trim();
                                        if (Combine == string.Empty)
                                        {
                                            TotalNoCrat = TotalNoCrat + NoCrate;
                                        }
                                        else
                                        {
                                            if (((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i)).String.Trim() == "N")
                                            {
                                                TotalNoCrat = TotalNoCrat + NoCrate;
                                            }
                                        }


                                        GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String);
                                        TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);

                                        NetWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);
                                        TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                    }
                                    catch { }
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                oEdit.String = TotalNoCrat.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                oEdit.String = TotalNetWt.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                oEdit.String = TotalGrsWt.ToString();
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;

                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            #region oCFLEvento.ChooseFromListUID == "CFL_STUFF"

                            if (oCFLEvento.ChooseFromListUID == "CFL_STUFF")
                            {
                                oDataTable = oCFLEvento.SelectedObjects;
                                if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                {
                                    return;
                                }
                                alSelectedDoc = new ArrayList();
                                string StuffDocEntry = "";
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    boolStuffSelected = true;
                                    StuffDocEntry = oDataTable.GetValue("DocEntry", i).ToString();
                                    alSelectedDoc.Add(StuffDocEntry);

                                }
                            }
                            #endregion

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            oForm = oApplication.Forms.Item(FormUID);
                            SAPbouiCOM.Form oUDFForm = oApplication.Forms.Item(oForm.UDFFormUID);


                            if (boolStuffSelected == true)
                            {
                                boolStuffSelected = false;

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                if (oMatrix.VisualRowCount > 1)
                                {
                                    oMatrix.Clear();
                                }
                                if (oMatrix.VisualRowCount == 0)
                                {
                                    try
                                    {
                                        oMatrix.AddRow(1, 1);
                                    }
                                    catch { }
                                }
                                //oMatrix.FlushToDataSource();

                                int Row = 1;
                                string SODocEntry = string.Empty;
                                string TotalExpns = string.Empty;
                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_BaseLine");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_BaseType");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_SODocEn");
                                    oColumn.Editable = true;
                                    oColumn = oMatrix.Columns.Item("U_SOLine");
                                    oColumn.Editable = true;
                                }
                                catch { }
                                for (int i = 0; i < alSelectedDoc.Count; i++)
                                {
                                    SODocEntry = alSelectedDoc[i].ToString();
                                    oRs = objclsComman.returnRecord(" SELECT T0.U_OthChg,T0.U_ContNo,T0.U_VesName,T0.U_FinDest,T0.U_PlaceRec,T0.U_ShpMarks,T0.U_PreCarBy,T0.U_PortLoad,T0.U_SealNo,T0.U_ESealNo,T0.U_VehNo " +
                                        " ,T1.U_ItemCode,T1.U_ItemName,T1.U_MARKING" +
                                        " ,T1.U_OpenQty,T1.U_Rate,T1.U_Amount,T1.U_Netwt,T1.U_GrsWt" +
                                        " ,T1.U_NoCrat,T1.U_NoPack,T1.U_PCCrate,T1.U_WtPack,T1.DOCENTRY [Disp_DocEntry],T1.LineId AS LINENUM,T1.Object" +
                                        " ,U_SONo,U_SODocEn,U_SOLine,T0.U_NumAtCar,U_TotCrat,U_TotNwt,U_TotGrWt,U_Total,U_FOBValue,U_InrRate" +
                                        " ,T0.DocEntry,T1.LineId,T0.Object,U_WhsCode,U_GRExch" +
                                        " ,(SELECT MAX(TAXCODE) FROM RDR1 A WHERE A.ITEMCODE=T1.U_ITEMCODE AND A.DOCENTRY=T1.U_SODocEn) TaxCode" +
                                        " ,T1.U_Combine,T1.U_SkipRow" +
                                        " FROM [@STUFF] T0 " +
                                        " INNER JOIN [@STUFF1] T1 ON T0.DOCENTRY= T1.DOCENTRY " +
                                        " WHERE T0.DOCENTRY='" + SODocEntry + "' AND U_OpenQty>0");
                                    if (oRs.RecordCount > 0)
                                    {
                                        // Port of Loading
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_PRTOFLDG").Specific;
                                            oEdit.String = oRs.Fields.Item("U_PortLoad").Value.ToString();
                                        }
                                        catch { }
                                        // Seal No
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_AGENTSEALNO").Specific;
                                            oEdit.String = oRs.Fields.Item("U_SealNo").Value.ToString();
                                        }
                                        catch { }
                                        // E Seal No
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_E_Seal").Specific;
                                            oEdit.String = oRs.Fields.Item("U_ESealNo").Value.ToString();
                                        }
                                        catch { }
                                        // Vehile No
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_VEHICLENO").Specific;
                                            oEdit.String = oRs.Fields.Item("U_VehNo").Value.ToString();
                                        }
                                        catch { }

                                        //Shipping Mark Details
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_SHPINGMARK").Specific;
                                            oEdit.String = oRs.Fields.Item("U_ShpMarks").Value.ToString();
                                        }
                                        catch { }
                                        //Final Destination 
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_FNLCNTY").Specific;
                                            oEdit.String = oRs.Fields.Item("U_FinDest").Value.ToString();
                                        }
                                        catch { }


                                        ////Pre Carriage By
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_PRECRGBY").Specific;
                                            string precarBy = oRs.Fields.Item("U_PreCarBy").Value.ToString();
                                            string precarByName = objclsComman.SelectRecord("SELECT  T0.[TrnspName] FROM OSHP T0 WHERE T0.[TrnspCode] = '" + precarBy + "'");
                                            oEdit.String = precarByName;
                                        }
                                        catch { }

                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_CONTERNO").Specific;
                                            oEdit.String = oRs.Fields.Item("U_ContNo").Value.ToString();
                                        }
                                        catch { }
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_VESSEL").Specific;
                                            oEdit.String = oRs.Fields.Item("U_VesName").Value.ToString();
                                        }
                                        catch { }
                                        try
                                        {
                                            oEdit = (SAPbouiCOM.EditText)oUDFForm.Items.Item("U_PLCOFRCT").Specific;
                                            oEdit.String = oRs.Fields.Item("U_PlaceRec").Value.ToString();
                                        }
                                        catch { }
                                    }

                                    oApplication.StatusBar.SetText("Total Rows: " + oRs.RecordCount.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                                    while (!oRs.EoF)
                                    {
                                        try
                                        {
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", Row)).String = oRs.Fields.Item("U_ItemCode").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", Row)).String = oRs.Fields.Item("U_WhsCode").Value.ToString();
                                            try
                                            {
                                                string TaxCode = oRs.Fields.Item("TaxCode").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", Row)).String = TaxCode;

                                            }
                                            catch (Exception ex)
                                            {
                                                oApplication.StatusBar.SetText("Setting TaxCode Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", Row)).String = oRs.Fields.Item("U_Netwt").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", Row)).String = oRs.Fields.Item("U_GrsWt").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NOPACKING", Row)).String = oRs.Fields.Item("U_NoPack").Value.ToString();

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CRTWT", Row)).String = oRs.Fields.Item("U_PCCrate").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TOTCRTWT", Row)).String = oRs.Fields.Item("U_WtPack").Value.ToString();

                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", Row)).String = oRs.Fields.Item("DocEntry").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseLine", Row)).String = oRs.Fields.Item("LineId").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SODocEn", Row)).String = oRs.Fields.Item("U_SODocEn").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SOLine", Row)).String = oRs.Fields.Item("U_SOLine").Value.ToString();

                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", Row)).String = oRs.Fields.Item("Object").Value.ToString();
                                            }
                                            catch
                                            {
                                                oApplication.StatusBar.SetText("Can't Copy data from stuffing. Active BaseEntry, BaseLine ,SO DocEntry and Base Type column from form setting", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                                return;
                                            }

                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", Row)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                            ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", Row)).String = oRs.Fields.Item("U_NoCrat").Value.ToString();

                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FOBVALUE", Row)).String = oRs.Fields.Item("U_FOBValue").Value.ToString();
                                            }
                                            catch (Exception ex)
                                            {
                                                oApplication.StatusBar.SetText("Setting FOB Value Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }
                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RATEININR", Row)).String = oRs.Fields.Item("U_InrRate").Value.ToString();
                                            }
                                            catch (Exception ex)
                                            {
                                                oApplication.StatusBar.SetText("Setting Rate In INR Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }
                                            //try
                                            //{

                                            //    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("140002027", Row)).String = oRs.Fields.Item("U_InrRate").Value.ToString();

                                            //}
                                            //catch (Exception ex)
                                            //{
                                            //    oApplication.StatusBar.SetText("Setting 140002027 (Assesible Value) Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            //}

                                            try
                                            {
                                                string GRExc = oRs.Fields.Item("U_GRExch").Value.ToString();
                                                ((SAPbouiCOM.EditText)oForm.Items.Item("64").Specific).String = GRExc;
                                            }
                                            catch
                                            {
                                                oApplication.StatusBar.SetText("You can't edit Rate (System Defined field)", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }

                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", Row)).String = oRs.Fields.Item("U_Rate").Value.ToString();
                                            }
                                            catch (Exception ex)
                                            {
                                                oApplication.StatusBar.SetText("Setting Unit Price Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }
                                            try
                                            {
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", Row)).String = oRs.Fields.Item("U_Combine").Value.ToString();
                                                ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", Row)).String = oRs.Fields.Item("U_SkipRow").Value.ToString();
                                            }
                                            catch (Exception ex)
                                            {
                                                oApplication.StatusBar.SetText("Setting Combine Error : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            oApplication.StatusBar.SetText("Setting Matrix: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        }
                                        Row++;
                                        oRs.MoveNext();
                                    }


                                }
                                try
                                {
                                    oColumn = oMatrix.Columns.Item("U_BaseEntry");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseLine");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_BaseType");
                                    oColumn.Editable = false;
                                    oColumn = oMatrix.Columns.Item("U_SODocEn");
                                    oColumn.Editable = false;
                                }
                                catch { }

                            }

                        }
                        #endregion

                        #region F_pVal.ItemChanged==true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            /*if (pVal.ColUID == "U_NETWT")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;
                                double NoCrate = 0;


                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    NoCrate = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }
                            if (pVal.ColUID == "U_GRSWT")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;
                                double NoCrate = 0;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                    NoCrate = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }
                            if (pVal.ColUID == "13")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                double NetWt = 0;
                                double TotalNetWt = 0;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                    NetWt = double.Parse(oEdit.String);
                                    TotalNetWt = TotalNetWt + NetWt;
                                }
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                oEdit.String = TotalNetWt.ToString();
                                //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                            }*/
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Delivery Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Delivery Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        System.Xml.XmlDocument oXml = null;
                        oXml = new System.Xml.XmlDocument();
                        oXml.LoadXml(BusinessObjectInfo.ObjectKey);
                        string DocEntry = oXml.SelectSingleNode("/DocumentParams/DocEntry").InnerText;
                        string canceled = objclsComman.SelectRecord("SELECT CANCELED FROM ODLN WHERE DocEntry ='" + DocEntry + "'");

                        StringBuilder sbQuery = new StringBuilder();
                        if (canceled == "N")
                        {
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_OpenQty= T0.U_OpenQty-T1.Quantity ");
                            sbQuery.Append(" FROM [@STUFF1] T0 ");
                            sbQuery.Append(" INNER JOIN DLN1 T1 ON T0.DocEntry=T1.U_BaseEntry AND T0.LineId=T1.U_BaseLine ");
                            sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                            objclsComman.SelectRecord(sbQuery.ToString());

                            string stuffDocEntry = objclsComman.SelectRecord("SELECT U_BaseEntry FROM DLN1 WHERE DOCENTRY='" + DocEntry + "' AND U_BaseEntry IS NOT NULL");
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" IF NOT EXISTS(SELECT DOCENTRY FROM [@STUFF1] WHERE DocEntry='" + stuffDocEntry + "' AND ISNULL(U_OpenQty,0)!=0) ");
                            sbQuery.Append(" BEGIN ");
                            sbQuery.Append(" UPDATE [@STUFF] SET STATUS='C' WHERE DOCENTRY='" + stuffDocEntry + "'");
                            sbQuery.Append(" END");
                            objclsComman.SelectRecord(sbQuery.ToString());

                            bool isClosed = false;

                            #region Close SO

                            oRs = objclsComman.returnRecord("SELECT T0.U_SODocEn FROM DLN1 T0 " +
                                " WHERE T0.DOCENTRY='" + DocEntry + "' AND ISNULL(U_SODocEn,'')!='' GROUP BY T0.U_SODocEn");
                            while (!oRs.EoF)
                            {
                                Int32 SODocEntry = Int32.Parse(oRs.Fields.Item("U_SODocEn").Value.ToString());
                                string Record = objclsComman.SelectRecord("EXEC STUFF_GET_SO_ALL_OPEN_ITEMS '" + SODocEntry + "'");
                                if (Record == string.Empty)
                                {
                                    SAPbobsCOM.Documents oSalesOrder = (SAPbobsCOM.Documents)(SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders));
                                    if (oSalesOrder.GetByKey(SODocEntry) == true)
                                    {
                                        oSalesOrder.Close();
                                        isClosed = true;
                                    }
                                }
                                oRs.MoveNext();
                            }
                            #endregion


                            try
                            {
                                oRs = objclsComman.returnRecord("SELECT T0.U_SODocEn,T0.U_SOLine  FROM DLN1 T0 " +
                                    " WHERE T0.DOCENTRY='" + DocEntry + "' AND ISNULL(U_SODocEn,'')!='' GROUP BY T0.U_SODocEn,T0.U_SOLine");
                                SAPbobsCOM.Recordset oRsSOLines = null;
                                while (!oRs.EoF)
                                {
                                    Int32 SODocEntry = Int32.Parse(oRs.Fields.Item("U_SODocEn").Value.ToString());
                                    int SOLineId = Int32.Parse(oRs.Fields.Item("U_SOLine").Value.ToString());

                                    SAPbobsCOM.Documents oSalesOrder = (SAPbobsCOM.Documents)(SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders));
                                    if (oSalesOrder.GetByKey(SODocEntry) == true)
                                    {
                                        oRsSOLines = objclsComman.returnRecord("EXEC STUFF_GET_SO_COMPLETED_QUNATITY_ITEMS '" + SODocEntry + "','" + SOLineId + "'");
                                        while (!oRsSOLines.EoF)
                                        {
                                            int i = int.Parse(oRsSOLines.Fields.Item("VisOrder").Value.ToString());
                                            oSalesOrder.Lines.SetCurrentLine(i);
                                            oSalesOrder.Lines.LineStatus = SAPbobsCOM.BoStatus.bost_Close;
                                            oRsSOLines.MoveNext();
                                        }
                                        int iResult = oSalesOrder.Update();
                                        if (iResult != 0)
                                        {
                                            oApplication.StatusBar.SetText("Update SO DocEntry: " + SODocEntry.ToString() + " LineNum: " + SOLineId.ToString() + " : " + oCompany.GetLastErrorCode() + oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                        }
                                    }
                                    oRs.MoveNext();
                                }
                                objclsComman.ReleaseObject(oRs);
                                objclsComman.ReleaseObject(oRsSOLines);

                            }
                            catch (Exception ex)
                            {

                            }
                        }
                        else
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET T0.U_OpenQty= T0.U_OpenQty+T1.Quantity,T2.STATUS='O',T2.CANCELED='N' ");
                            sbQuery.Append(" FROM [@STUFF1] T0 ");
                            sbQuery.Append(" INNER JOIN DLN1 T1 ON T0.DocEntry=T1.U_BaseEntry AND T0.LineId=T1.U_BaseLine ");
                            sbQuery.Append(" INNER JOIN [@STUFF] T2 ON T0.DocEntry=T2.DocEntry ");
                            sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                            objclsComman.SelectRecord(sbQuery.ToString());

                            //sbQuery = new StringBuilder();
                            //sbQuery.Append(" UPDATE T2 ");
                            //sbQuery.Append(" SET T2.STATUS='O',T2.CANCELED='N' ");
                            //sbQuery.Append(" FROM [@STUFF1] T0 ");
                            //sbQuery.Append(" INNER JOIN DLN1 T1 ON T0.DocEntry=T1.U_BaseEntry AND T0.LineId=T1.U_BaseLine ");
                            //sbQuery.Append(" INNER JOIN [@STUFF] T2 ON T0.DocEntry=T2.DocEntry ");
                            //sbQuery.Append(" WHERE T1.DocEntry='" + DocEntry + "'");
                            //objclsComman.SelectRecord(sbQuery.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region Methods

        private void Calc_Gross(SAPbouiCOM.Form oForm)
        {
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                double Netwt = 0;
                double GrsWt = 0;
                double CrWeight = 0;
                string Combine = string.Empty;
                string InnerLoop_Combine = string.Empty;

                ArrayList ALCombine = new ArrayList();
                ArrayList temp = new ArrayList();


                #region Set Skip Row to Blank
                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    try
                    {
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i);
                        oEdit.String = string.Empty;
                    }
                    catch
                    { }
                    //oForm.DataSources.DBDataSources.Item("RDR1").SetValue("U_SkipRow", i - 1, "");//Pravin
                }
                #endregion

                #region Checking Matching Combine Rows


                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    try
                    {
                        Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String.Trim();

                        if (Combine != string.Empty)
                        {
                            for (int j = i + 1; j <= oMatrix.VisualRowCount; j++)
                            {
                                InnerLoop_Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", j)).String.Trim();
                                if (Combine == InnerLoop_Combine)
                                {
                                    if (temp.Contains(Combine) == false)
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i)).String = "N";
                                    }
                                    ALCombine.Add(i.ToString());
                                    temp.Add(Combine);
                                    break;
                                }
                            }
                        }
                    }
                    catch
                    { }
                }
                #endregion

                #region If No Matching Record (Combine) Found

                if (ALCombine.Count == 0)
                {
                    for (int i = 1; i < oMatrix.VisualRowCount; i++)
                    {
                        oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        CrWeight = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CRTWT", i)).String);
                        Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);

                        GrsWt = Netwt + CrWeight;
                        GrsWt = Math.Round(GrsWt, 2);
                    }
                    oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    return;
                }
                #endregion

                #region Setting Gross Weight
                for (int Row = 1; Row <= ALCombine.Count; Row++)
                {
                    try
                    {

                        oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + Row.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        int i = int.Parse(ALCombine[Row - 1].ToString());
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String = oEdit.String;
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    }

                }
                #endregion

                oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calc_Gross: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }


        #endregion
    }
}
