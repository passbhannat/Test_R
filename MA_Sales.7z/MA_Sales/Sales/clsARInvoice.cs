using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Linq;

namespace Sales
{
    class clsARInvoice : Connection
    {
        #region Variables
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        string randomUID = "UID";
        #endregion

        #region Events

        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    #region T_et_ITEM_PRESSED
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "1")
                        {
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                

                            }
                        }
                    }
                    #endregion
                }
                #endregion


                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string TableName = string.Empty;
                            SAPbouiCOM.Button oButton;
                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);

                            oForm.DataSources.UserDataSources.Add(randomUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
                            oForm.DataSources.UserDataSources.Item(randomUID).Value = "N";

                            TableName = "OINV";


                            oNewItem = oForm.Items.Add("btnCalc", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            oNewItem.Top = oItem.Top;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.Width = oItem.Width;
                            oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Calculate";


                            oNewItem = oForm.Items.Add("lbl", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("30");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.StaticText oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Net Weight";

                            oNewItem = oForm.Items.Add("TotNwt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("29");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, TableName, "U_TotNwt");


                            oNewItem = oForm.Items.Add("lbl1", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("lbl");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Gross Weight";

                            oNewItem = oForm.Items.Add("TotGrWt", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("TotNwt");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, TableName, "U_TotGrWt");

                            oNewItem = oForm.Items.Add("lbl2", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("lbl1");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Total Crates";

                            oNewItem = oForm.Items.Add("TotCrat", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("TotGrWt");
                            oNewItem.Top = oItem.Top + 15;
                            oNewItem.Left = oItem.Left;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Enabled = false;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, TableName, "U_TotCrat");


                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region pVal.ItemUID == "btnCalc"
                            if (pVal.ItemUID == "btnCalc")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;

                                string baseType = "";
                                string baseEntry = "";
                                string baseLine = "";
                                string packQty = "";
                                oForm.DataSources.UserDataSources.Item(randomUID).ValueEx = "Y";

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    oApplication.StatusBar.SetText("Setting No of Crate ..." + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                                    baseEntry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("45", i)).String;

                                    if (baseEntry == string.Empty)
                                    {
                                        continue;
                                    }
                                    baseLine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("46", i)).String;


                                    baseType = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("43", i)).String;

                                    if (baseType == Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oOrders))
                                    {
                                        packQty = objclsComman.SelectRecord("SELECT PackQty FROM RDR1 WHERE DocEntry = '" + baseEntry + "' AND LineNum = '" + baseLine + "'");
                                    }
                                    else
                                    {
                                        packQty = objclsComman.SelectRecord("SELECT PackQty FROM DLN1 WHERE DocEntry = '" + baseEntry + "' AND LineNum = '" + baseLine + "'");
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i)).String = packQty;
                                    }
                                    catch { }

                                }
                                Calc_Gross(oForm);

                                double NetWt = 0;
                                double GrsWt = 0;

                                double TotalNoCrat = 0;
                                double NoCrate = 0;
                                double TotalGrsWt = 0;
                                double TotalNetWt = 0;
                                string Combine = string.Empty;

                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        oApplication.StatusBar.SetText("Calculating ..." + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                                        NoCrate = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i)).String);
                                        Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String.Trim();
                                        if (Combine == string.Empty)
                                        {
                                            TotalNoCrat = TotalNoCrat + NoCrate;
                                        }
                                        else
                                        {

                                            if (((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i)).String.Trim() == "N")
                                            {
                                                TotalNoCrat = TotalNoCrat + NoCrate;
                                            }
                                        }

                                        GrsWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String);
                                        TotalGrsWt = TotalGrsWt + (GrsWt * NoCrate);

                                        NetWt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);
                                        TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                    }
                                    catch { }
                                }

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                oEdit.String = TotalNoCrat.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                oEdit.String = TotalNetWt.ToString();

                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                oEdit.String = TotalGrsWt.ToString();
                            }
                            #endregion

                        }
                        #endregion

                        #region F_pVal.ItemChanged==true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            /* if (pVal.ColUID == "U_NETWT")
                             {
                                 oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                 double NetWt = 0;
                                 double TotalNetWt = 0;
                                 double NoCrate = 0;


                                 for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                 {
                                     oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                     NetWt = double.Parse(oEdit.String);
                                     oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                     NoCrate = double.Parse(oEdit.String);
                                     TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                 }
                                 oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotNwt").Specific;
                                 oEdit.String = TotalNetWt.ToString();
                                 //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                             }
                             if (pVal.ColUID == "U_GRSWT")
                             {
                                 oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                 double NetWt = 0;
                                 double TotalNetWt = 0;
                                 double NoCrate = 0;

                                 for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                 {
                                     oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                     NetWt = double.Parse(oEdit.String);
                                     oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("13", i);
                                     NoCrate = double.Parse(oEdit.String);
                                     TotalNetWt = TotalNetWt + (NetWt * NoCrate);
                                 }
                                 oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotGrWt").Specific;
                                 oEdit.String = TotalNetWt.ToString();
                                 //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                             }
                             if (pVal.ColUID == "13")
                             {
                                 oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                 double NetWt = 0;
                                 double TotalNetWt = 0;

                                 for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                 {
                                     oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, i);
                                     NetWt = double.Parse(oEdit.String);
                                     TotalNetWt = TotalNetWt + NetWt;
                                 }
                                 oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("TotCrat").Specific;
                                 oEdit.String = TotalNetWt.ToString();
                                 //oForm.DataSources.DBDataSources.Item(0).SetValue("U_TotNwt", 0, TotalNetWt.ToString());

                             }*/
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("AR Invoice Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("AR Invoice Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        oForm.DataSources.UserDataSources.Item(randomUID).Value = "N";
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }



        #endregion

        #region Methods

        private void Calc_Gross_2(SAPbouiCOM.Form oForm)
        {
            try
            {
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                double Netwt = 0;
                double GrsWt = 0;
                double CrWeight = 0;
                string Combine = string.Empty;
                string InnerLoop_Combine = string.Empty;

                ArrayList ALCombine = new ArrayList();
                ArrayList temp = new ArrayList();


                #region Set Skip Row to Blank
                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                {
                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i);
                    oEdit.String = string.Empty;
                    //oForm.DataSources.DBDataSources.Item("RDR1").SetValue("U_SkipRow", i - 1, "");//Pravin
                }
                #endregion

                #region Checking Matching Combine Rows


                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                {
                    Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String.Trim();

                    if (Combine != string.Empty)
                    {
                        for (int j = i + 1; j < oMatrix.VisualRowCount; j++)
                        {
                            InnerLoop_Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", j)).String.Trim();
                            if (Combine == InnerLoop_Combine)
                            {
                                if (temp.Contains(Combine) == false)
                                {
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i)).String = "N";
                                }
                                ALCombine.Add(i.ToString());
                                temp.Add(Combine);
                                break;
                            }
                        }
                    }
                }
                #endregion

                #region If No Matching Record (Combine) Found

                if (ALCombine.Count == 0)
                {
                    for (int i = 1; i < oMatrix.VisualRowCount; i++)
                    {
                        oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        CrWeight = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CRTWT", i)).String);
                        Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);

                        GrsWt = Netwt + CrWeight;
                        GrsWt = Math.Round(GrsWt, 2);
                    }
                    oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    return;
                }
                #endregion

                #region Setting Gross Weight
                for (int Row = 1; Row <= ALCombine.Count; Row++)
                {
                    try
                    {

                        oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + Row.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        int i = int.Parse(ALCombine[Row - 1].ToString());
                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i);
                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String = oEdit.String;
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                    }

                }
                #endregion

                oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Calc_Gross: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        private void Calc_Gross(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
            double Netwt = 0;
            double GrsWt = 0;
            double CrWeight = 0;
            string Combine = string.Empty;
            string InnerLoop_Combine = string.Empty;
            string baseKey = string.Empty;
            string InnerLoop_baseKey = string.Empty;

            ArrayList ALCombine = new ArrayList();
            ArrayList temp = new ArrayList();


            #region Set Skip Row to Blank
            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                try
                {
                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i);
                    oEdit.String = string.Empty;
                }
                catch { }
                //oForm.DataSources.DBDataSources.Item("RDR1").SetValue("U_SkipRow", i - 1, "");//Pravin
            }
            #endregion

            #region Checking Matching Combine Rows


            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                try
                {
                    Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String.Trim();
                    baseKey = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", i)).String.Trim();

                    if (Combine != string.Empty)
                    {
                        for (int j = i + 1; j <= oMatrix.VisualRowCount; j++)
                        {
                            try
                            {
                                InnerLoop_Combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", j)).String.Trim();
                                InnerLoop_baseKey = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", j)).String.Trim();

                                if (Combine == InnerLoop_Combine && baseKey == InnerLoop_baseKey)
                                {
                                    if (temp.Contains(Combine) == false)
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SkipRow", i)).String = "N";
                                    }
                                    ALCombine.Add(i.ToString());
                                    temp.Add(Combine);
                                    break;
                                }
                            }
                            catch { }
                        }
                    }
                }
                catch { }
            }
            #endregion

            #region If No Matching Record (Combine) Found

            if (ALCombine.Count == 0)
            {
                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    try
                    {
                        oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + i.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        CrWeight = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CRTWT", i)).String);
                        Netwt = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i)).String);

                        GrsWt = Netwt + CrWeight;
                        GrsWt = Math.Round(GrsWt, 2);
                    }
                    catch { }
                }
                oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                return;
            }
            #endregion

            #region Setting Gross Weight
            for (int Row = 1; Row <= ALCombine.Count; Row++)
            {
                try
                {

                    oApplication.StatusBar.SetText("Calculating Gross Weight for Line: " + Row.ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    int i = int.Parse(ALCombine[Row - 1].ToString());
                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", i);
                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRSWT", i)).String = oEdit.String;
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                }

            }
            #endregion

            oApplication.StatusBar.SetText("Gross Weight Calculation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

        }


        private bool Validation(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
            List<clsItemEntity> list = new List<clsItemEntity>();
            for (int i = 1; i < oMatrix.VisualRowCount; i++)
            {
                string baseEntry = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", i)).String;
                string combine = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Combine", i)).String;
                if (baseEntry != string.Empty && combine != string.Empty)
                {
                    //list.Add(new clsItemEntity { BaseEntry = baseEntry + "_" + combine });
                    list.Add(new clsItemEntity { BaseEntry = baseEntry, Combine = combine });
                }
            }
            var groupedList = list.GroupBy(d => new { d.BaseEntry, d.Combine })
                            // .Where(g => g.Count() > 1)
                            .Select(
                                g => new
                                {
                                    BaseEntry = g.Key.BaseEntry,
                                    Combine = g.Key.Combine,
                                }).ToList();
            if (groupedList.Count > 1)
            {
                var duplicatedList = groupedList.GroupBy(d => new { d.Combine })
                             .Where(g => g.Count() > 1)
                            .Select(
                                g => new
                                {
                                    Combine = g.Key.Combine,
                                }).ToList();
                if (duplicatedList.Count > 0)
                {
                    oApplication.StatusBar.SetText("Baseentry and combine can't duplicate.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    return false;
                }
            }
            return true;
        }

        #endregion

    }
}
